package com.example.joelcrawford.starbuzz;

import android.os.Bundle;
import android.app.Activity;
import android.widget.TextView;

public class TenMajorActivity extends Activity {

    //public static final String EXTRA_TEN_NO = "ten_No";
    public static final String EXTRA_TEN_No ="ten_No" ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_ten_major );

        //get the lyrics from the intent
        String tenName = (String) getIntent().getExtras().get( EXTRA_TEN_No );
        TenMajor tenMajor= TenMajor.tenMajors[getTenMajorPosition(tenName)];

        //populate the lyrics
        TextView lyrics = findViewById( R.id.lyrics );
        lyrics.setText( tenMajor.getLyrics() );


    }

    int getTenMajorPosition(String name){
        int position = 0;
        for(int i=0; i<TenMajor.tenMajors.length; i++){
            if(TenMajor.tenMajors[i].getTitle().equals(name)){
                position = i;
                break;
            }
        }
        return position;
    }

}
