package com.example.joelcrawford.starbuzz;

import android.os.Bundle;
import android.app.Activity;
import android.widget.TextView;

public class DrinkActivity extends Activity {

    public static final String EXTRA_DRINKNO = "drinkNo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_drink );

        //Get the drink from the intent
        String  drinkName =  (String) getIntent().getExtras().get(EXTRA_DRINKNO);
        Drink drink = Drink.drinks[getDrinkPosition(drinkName)];

        //populate the drink image
        //ImageView photo = (ImageView) findViewById( R.id.photo );
        //photo.setImageResource( drink.getImageResourceId() );
       // photo.setContentDescription( drink.getName() );

        //populate drink with name

        TextView name = (TextView) findViewById( R.id.name );
        name.setText( drink.getName() );

        //populate the drink description
        TextView description = (TextView) findViewById( R.id.description );
        description.setText( drink.getDescription() );
    }

    int getDrinkPosition(String name){
        int position = 0;
        for(int i=0; i<Drink.drinks.length; i++){
            if(Drink.drinks[i].getName().equals(name)){
                position = i;
                break;
            }
        }
        return position;
    }

}
