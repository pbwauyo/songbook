package com.example.joelcrawford.starbuzz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;

import java.util.ArrayList;
import java.util.Locale;


public class TopLevelActivity extends Activity {
//    EditText editText;
    ListView listView;
    ListViewAdapter adapter;
    String [] description;


    //custme adapter
    ArrayList<Drink> drinkArrayList = new ArrayList<Drink>(  );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_top_level );

        //creating filter or search for listview

        description = new String[]{"jjjj","jjjjx","jjjj"};
        listView = findViewById( R.id.showdata ) ;

        for (int i=0;i<=description.length;i++){
           // Drink  DN = new Drink(description[i]);

            //drinkArrayList.add(DN );

        }

        adapter = new ListViewAdapter( this, drinkArrayList );
        listView.setAdapter( adapter );

//        editText = findViewById( R.id.searchdata );
//        editText.addTextChangedListener( new TextWatcher() {
//            @Override
//
//            //search or filter
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//                String who = editText.getText().toString().toLowerCase(Locale.getDefault() );
//
//                adapter.desFilter( who );
//            }
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) {
//
//            }
//        } );

        //create an on item click listener
        AdapterView.OnItemClickListener onItemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listView,
                                    View v,
                                    int position,
                                    long id) {
                if (position == 0) {
                    Intent intent= new Intent( TopLevelActivity.this, DrinkCategoryActivity.class );
                    startActivity( intent );
                }
                if(position==1){
                    Intent intent= new Intent( TopLevelActivity.this,TenMajorCategoryActivity.class );
                    startActivity( intent );
                }
                if(position==2){
                    Intent intent = new Intent( TopLevelActivity.this,PresentTenseCategoryActivity.class );
                    startActivity( intent );
                }
                if (position==3){
                    Intent intent= new Intent( TopLevelActivity.this,EagleCategoryActivity.class );
                    startActivity( intent );
                }

            }
        };

        //add the listener to the listview
        ListView listView= (ListView)findViewById( R.id.list_options );

        listView.setOnItemClickListener( onItemClickListener );








    }
}
