package com.example.joelcrawford.starbuzz;

public class Eagle {

    private String eagle_title;
    private String eagle_lyrics;

    public static final Eagle[] eagles ={

            new Eagle( "1. DRIFTING TOO FAR FROM THE SHORE\n",
                    "Out on the perilous deep,\n" +
                    "where danger silently creeps,\n" +
                    "and storm's so violently sweeping,\n" +
                    "You're drifting too far from shore.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tDrifting too far from shore,\n" +
                    "\tYou're drifting too far from shore,\n" +
                    "\tCome to Jesus today,\n" +
                    "\tLet Him show you the way.\n" +
                    "\tYou're drifting too far from shore,\n" +
                    "\n" +

                    "Today, the Tempest rose high,\n" +
                    "and clouds o'ershadow the sky.\n" +
                    "Sure death is hovering nigh,\n" +
                    "You're drifting too far from shore.\n" +
                    "\n" +

                    "Why meet a terrible fate?\n" +
                    "Mercies abundantly wait.\n" +
                    "Turn back before it's too late\n" +
                    "You're drifting too far from shore." ),

            new Eagle( "2. BUILDING ON THE SAND\n",
                    "See that man in a mottle castle\n" +
                    "Holds a firm\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tBuilding, building on the sand\n" +
                    "\tBuilding houses that won’t stand\n" +
                    "\tOh! Weak in faith and hope is man\n" +
                    "\tFor he is building on the sand\n" +
                    "\n" +

                    "See that drunkard over yonder\n" +
                    "Getting all the drink he can\n" +
                    "O’er his past life he does ponder\n" +
                    "For he is building on the sand\n" +
                    "\n" +

                    "Let’s humbly pray to God in heaven\n" +
                    "Heed the truth and truth shall stand\n" +
                    "Build for that mansion He has promised\n" +
                    "Let’s stop building on the sand\n" ),

            new Eagle( "3. BE CAREFUL OF STONES THAT YOU THROW\n","\tCHORUS:\n" +
                    "\tA tongue can accuse\n" +
                    "\tAnd carry bad news,\n" +
                    "\tThe seeds of distrust it will sow\n" +
                    "\tBut unless you’ve made\n" +
                    "\tNo mistake in your life,\n" +
                    "\tBe careful of the stones that you throw.\n" +
                    "\n" +

                    "A neighbor was passing by my garden on time,\n" +
                    "She stopped and I knew right of way\n" +
                    "That it was gossip, not flowers, she had on her mind,\n" +
                    "And this is what I heard my neighbor say\n" +
                    "“That girl down the street should be run from our midst,\n" +
                    "She drinks and she talks quite a lot”\n" +
                    "She knows not to speak to my child or to me,\n" +
                    "My neighbor then smiled and I thought.\n" +
                    "\n" +


                    "A car speeded by and a screaming of brakes,\n" +
                    "A sound that makes my blood chill,\n" +
                    "For my neighbour’s one child had been pulled,\n" +
                    "From the path and saved by a girl lying still\n" +
                    "The child was unhurt and my neighbor cried out,\n" +
                    "“Oh, who was that brave girl so sweet?”\n" +
                    "I covered the crushed broken body and said\n" +
                    "“That bad girl who lives down the street\n" ),

            new Eagle( "4. BEHOLD I COME QUICKLY\n","Christ is coming back to claim His own someday\n" +
                    "And al tears from our eyes, he will wipe away\n" +
                    "In the new world tomorrow\n" +
                    "And the former things on earth, it shall pass away\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tAnd behold, I come quickly\n" +
                    "\tAnd my reward is with me\n" +
                    "\tTo give to every man according to his works shall be\n" +
                    "\tThis is the holly word of God and so shall it be\n" +
                    "\tSo let your work be good works till His blessed face we see\n" +
                    "\n" +

                    "Jesus Christ is the beginning and the end\n" +
                    "Blessed are they that do His command\n" +
                    "For they shall have the right to the tree of life\n" +
                    "When their work on earth is done\n" +
                    "And they shall enter through the gates of the New Jerusalem\n" ),

            new Eagle( "5. DO YOU EXPECT A REWARD FROM GOD?\n","If through this world of sin you travel,\n" +
                    "The straight and narrow way you do not trod,\n" +
                    "In the end when everything has been unraveled\n" +
                    "Do you expect a reward form God?\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tGod will give us everything He promised\n" +
                    "\tIf we live for Him, He’ll give us that reward\n" +
                    "\tBut if in sin you daily wonder,\n" +
                    "\tDo you expect a reward form God?\n" +
                    "\n" +

                    "If you always seek for worldly pleasure,\n" +
                    "And the titles of the earth you choose to win,\n" +
                    "Then you’ll never gain that heaven’s treasures\n" +
                    "Do you expect a reward form God?" ),

            new Eagle( "6. I HAVE DUSTED OFF THE BIBLE.\n",
                    "I have dusted off the Bible\n" +
                    "And I’ve read it through and through\n" +
                    "I have asked my blessed savior\n" +
                    "He has shown me what to do\n" +
                    "Every day He brings me nearer\n" +
                    "To the home that is my goal\n" +
                    "Hence I’ve dusted of the Bible\n" +
                    "Heavens’ glory filled my soul\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI have dusted off the Bible\n" +
                    "\tAnd the victory has been won\n" +
                    "\tI now have the keeping power by trusting in His son\n" +
                    "\tWhat God has sent into the world His glory to unf-----\n" +
                    "\tWhen death will claim body here,\n" +
                    "\tThe Lord will claim my soul\n" +
                    "\n" +

                    "Now every day I sing His praise glad tidings I can tell\n" +
                    "How every soul He wants to save\n" +
                    "This Christ I love so well\n" +
                    "He also opened up the book that angels could not do\n" +
                    "He fills my soul with glory and he safely leads me through" ),

            new Eagle( "7. JESUS IS THE ONE.\n","When the way is dark before you\n" +
                    "And the clouds are hanging low\n" +
                    "There is one who watches o’er you\n" +
                    "Everywhere you may go\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tJesus is the one, yes, He’s the only one\n" +
                    "\tLet Him have His way until the day is done\n" +
                    "\tAnd when He speaks, you know, the clouds will have to go\n" +
                    "\tOnly because he loves you so\n" +
                    "\n" +

                    "Oh! When you are sad and lonely,\n" +
                    "Life is but an empty tomb\n" +
                    "Breathe a prayer to Jesus only\n" +
                    "He will drive away your gloom\n" +
                    "\n" +

                    "When you come to cross the river\n" +
                    "He will be your friend and guide\n" +
                    "You can live with Him forever\n" +
                    "Over on the other shore\n" ),

            new Eagle( "8. WATCH AND PRAY.\n","Don’t you want to go with me to the glory land?\n" +
                    "Don’t you want to be part of that heavenly band?\n" +
                    "Don’t you want to see Jesus some wonderful day?\n" +
                    "Sharing His glory?\n" +
                    "Then, watch and pray\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tWatch and pray if you would enter in\n" +
                    "\tWatch and pray so that you’ll be free from sin\n" +
                    "\tThe lord is coming to catch his bride away\n" +
                    "\tIf you want to go with Him, the, watch and pray\n" +
                    "\n" +

                    "Now you’d better be repenting\n" +
                    "Of all your sin\n" +
                    "Have the Holy Spirit dwelling within\n" +
                    "Live a holy life from day to day\n" +
                    "Wait for His coming and watch and pray" ),

            new Eagle( "9. AVENUE OF PRAYER.\n","Oh dear friend, this sinful world is lost and dying\n" +
                    "Every Christian heart is burden down with care\n" +
                    "Tell me are you doing all you can for Jesus?\n" +
                    "Are you travelling down the Avenue of prayer?\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tKeeping faith in your heart and concentrating,\n" +
                    "\tEvery hour of every day do you prepare?\n" +
                    "\tAre you ready should your master call at mid night?\n" +
                    "\tAre you travelling down the Avenue of prayer?\n" +
                    "\n" +

                    "Are you praying for the ones who know not Jesus?\n" +
                    "As they are being led into the tempter’s snare?\n" +
                    "Would you stand aside and see a losing battle?\n" +
                    "Are you travelling down the Avenue of prayer?" ),

            new Eagle( "10. WRECK ON THE HIGH WAY.\n","Who did you say it was, brother?\n" +
                    "Who was it fell by the way?\n" +
                    "When whiskey and blood run together\n" +
                    "Did you hear anyone pray?\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI didn’t hear nobody pray, dear brother\n" +
                    "\tI didn’t hear nobody pray\n" +
                    "\tI heard the crash on the highway\n" +
                    "\tBut I didn’t hear nobody pray\n" +
                    "\n" +

                    "When I heard the crash on the highway,\n" +
                    "I knew what it was from the start\n" +
                    "I went to the scene of destruction\n" +
                    "And the picture was stamped on my heart\n" +
                    "There was whiskey and blood altogether\n" +
                    "Mixed with glass when they lay\n" +
                    "Death played a hand in destruction,\n" +
                    "But I didn’t hear nobody pray\n" +
                    "\n" +

                    "I wish I could change this sad story\n" +
                    "That I am now telling you\n" +
                    "But there is no way I can change it\n" +
                    "For somebody’s life is now through\n" +
                    "Their soul has been called by the master\n" +
                    "They died in a crash on the highway\n" +
                    "And I heard the groans of the dying but hear nobody pray" ),

            new Eagle( "11. GOD BLESS HER CAUSE SHE’S MY MOTHER.\n","I’m thinking of a little lady\n" +
                    "She bears her load without a fret\n" +
                    "The one who rocked me in my cradle\n" +
                    "And through the years she loves me yet\n" +
                    "The roses on her cheeks are faded\n" +
                    "And when they pass her on the streets\n" +
                    "Would break my heart to see them mock her\n" +
                    "Although she may not dress so neat\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tShe was the first to ever love me\n" +
                    "\tThe first to hold me to her breast\n" +
                    "\tGod bless her cause she is my mother\n" +
                    "\tAnd she’ll be the last one I’ll forget\n" +
                    "\n" +

                    "Her ways may seem a bit old fashion\n" +
                    "And some may laugh when passing by\n" +
                    "I’m not ashamed to call her mother\n" +
                    "My love for her I’ll never deny\n" +
                    "Each lock of grey tells of her sorrow\n" +
                    "As day by day she growing old\n" +
                    "Her tender smile each day grows sweeter\n" +
                    "Each day she’s closer to God’s fold" ),

            new Eagle( "12. HE’LL STRIKE YOU DOWN.\n","Oh, wayward soul, you’d better be a praying\n" +
                    "You surely know where you are bound\n" +
                    "You have heard God’s voice, but still you keep on straying\n" +
                    "And He’ll surely strike you down\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThe spirit of God will not strike with man always\n" +
                    "\tAccept Him while He may be found\n" +
                    "\tFor He holds all power in His hands so precious,\n" +
                    "\tAnd He’ll surely strike you down\n" +
                    "\n" +

                    "You may think that you’ll get by forever,\n" +
                    "But some things you can’t get around\n" +
                    "You better change and do God’s blessed favor\n" +
                    "Or He’ll surely strike you down" ),

            new Eagle( "13. HIDE YOU IN THE BLOOD.\n","Come, oh sinner, heed His call\n" +
                    "Hide you in the blood of Jesus\n" +
                    "He gave His life to save us all\n" +
                    "Hide you in the blood of Jesus\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOh, hide (oh, hide) you in the blood (hide you in the blood)\n" +
                    "\tFor the storm’s (For the storm’s) a raging power (storm’s a raging power)\n" +
                    "\tOh, hide (oh, hide) you in the blood (hide you in the blood)\n" +
                    "\tTill the dangers pass you by\n" +
                    "\n" +

                    "Many loved ones are passing each day\n" +
                    "Hide you in the blood of Jesus\n" +
                    "Straight is the gate and narrow is the way\n" +
                    "Hide you in the blood of Jesus\n" +
                    "\n" +

                    "He is calling you and He is calling me\n" +
                    "Hide you in the blood of Jesus\n" +
                    "There’s a shelter for the free\n" +
                    "Hide you in the blood of Jesus." ),

            new Eagle( "14. GOOD BYE! HALLELUJAH! I’M GONE.\n","When a man with His hand raised toward heaven,\n" +
                    "With His feet on the land and sea\n" +
                    "Shall swear by Him and that lives forever\n" +
                    "That time shall no longer be;\n" +
                    "When the rich and the free and the poor man\n" +
                    "Cries to rocks and the mountains to hide\n" +
                    "Then you’ll hear me shout “Hallelujah! Good-Bye!\n" +
                    "I’ve gone up with the bride”\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tGood-bye! Good-bye!\n" +
                    "\tGood-bye! Hallelujah! I’m gone\n" +
                    "\tWhen we see Jesus coming in the sky\n" +
                    "\tGood-bye! Hallelujah! I’m gone\n" +
                    "\n" +

                    "Jesus spoke about some signs before His coming\n" +
                    "He said the sea and the waves would roar\n" +
                    "Men’s heart would fail them as they wonder\n" +
                    "And the heavens depart as a scroll\n" +
                    "When seven thunders utter their voices,\n" +
                    "And this old world is just about gone\n" +
                    "Then you’ll hear me shout “Hallelujah”\n" +
                    "Good-bye! Hallelujah! I’m Gone!" ),

            new Eagle( "15. HE SET ME FREE.\n","Once like a bird in freedom I dwelt\n" +
                    "No freedom from my sorrow I felt\n" +
                    "But Jesus came and listened to me\n" +
                    "And Glory to God, He set me free\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tHe set me free\n" +
                    "\tYes, he set me free\n" +
                    "\tAnd He broke the bonds of prison for me\n" +
                    "\tI’m glory bound my Jesus to see\n" +
                    "\tFor Glory to God, He set me free\n" +
                    "\n" +

                    "Now I am climbing higher each day\n" +
                    "Darkness of night has drifted away\n" +
                    "My feet are planted on higher ground\n" +
                    "And Glory to God, I’m onward bound\n" +
                    "\n" +

                    "Good-by to sin and things that confound,\n" +
                    "Naught of the worlds shall turn me around\n" +
                    "Daily I’m working, I’m praying too,\n" +
                    "And Glory to God, I’m going thru" ),

            new Eagle( "16. THE MINER’S FATE.\n","The hard working miner whose dangers are great\n" +
                    "For many, while mining, have met their sad fate\n" +
                    "Doing their duty as all miner’s do\n" +
                    "Shut out from the daylight and their loved ones too\n" +
                    " \n" +

                    "He leaves dear wife and little ones too\n" +
                    "To earn the living as all miner’s do\n" +
                    "While he is working for those he loves\n" +
                    "He met his sad fate from a boulder above\n" +
                    " \n" +

                    "Only a miner under the ground\n" +
                    "Only miner eternity bound\n" +
                    "Killed by a boulder, there‘s no one can tell\n" +
                    "Good-bye! Hallelujah! I’m gone\n" +
                    " \n" +

                    "Death came to call him so quick was the fall\n" +
                    "Have mercy upon me, the poor miner called\n" +
                    "They came to help him, but no could save\n" +
                    "They could only prepare him to rest in his grave\n" +
                    " \n" +

                    "Good-bye! Hallelujah! I’m gone\n" +
                    "His loved ones are mourning, their heartache can tell\n" +
                    "His little children so sad and lone\n" +
                    "Their home is so lonely, their daddy is gone\n"),

            new Eagle( "17. LOVE THY NEIGHBOR AS THYSELF.\n","\tCHORUS:\n" +
                    "\tLove thy neighbor as thyself\n" +
                    "\tDo unto him as you’d have him do to you\n" +
                    "\tGive him things that you can do without to help him live\n" +
                    "\tLove thy neighbor as thyself and he will love you too\n" +
                    "\n" +

                    "Now this old world could be a lonesome place without a friend\n" +
                    "We need each other every day together we can win\n" +
                    "There’s a little good in every man\n" +
                    "Though countless be faults\n" +
                    "And a word of kindness you may speak\n" +
                    "To change his inward thoughts\n" +
                    "\n" +

                    "I once knew a couple of fellows near my old homestead\n" +
                    "And I just wish that all the world would live the way they did\n" +
                    "They’d swap out work and lend each other money, mules and plows\n" +
                    "And I’ve seen them many times dividing milk from one old cow\n" +
                    "\n" +

                    "There’s good old fashioned folks who’ll be a friend in need\n" +
                    "If you want a friend, then be a friend\n" +
                    "Do not from charity slack\n" +
                    "Do your deeds without a gripe,\n" +
                    "Someone will pay you back" ),

            new Eagle( "18. WHERE WE’LL NEVER DIE.\n","Sinner, why not heed today?\n" +
                    "Won’t you come and go this way?\n" +
                    "Where Jesus lives and we’ll never say good bye\n" +
                    "To a home that’s fair and bright\n" +
                    "And there never is no light\n" +
                    "In a land where we never shall die\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI have a home way up on high\n" +
                    "\tWhere we shall live and never die\n" +
                    "\tWon’t you come and cross this river so wide?\n" +
                    "\tThere with Jesus we shall dwell\n" +
                    "\tNever more to say farewell\n" +
                    "\tIn a land where we never shall die\n" +


                    "Walk the straight and narrow way\n" +
                    "Fall down on your knees and pray\n" +
                    "God will help you cross the mountain top so high\n" +
                    "He will take you by the hand, lead you to that Promised Land\n" +
                    "To a home where we never shall die\n" ),

            new Eagle( "19. THE POPLAR LOG HOUSE ON THE HILL.\n","Now fine friends, I want to tell you of our little country home\n" +
                    "It is made of poplar logs upon a hill\n" +
                    "There’s where daddy died and left us when we all were very young\n" +
                    "But our mother kept us settled on the hill\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tWhen our day’s work on the farm was done,\n" +
                    "\tShe would gather us around\n" +
                    "\tShe would have us get down on our little knees\n" +
                    "\tShe would pray for God to keep us through the night until next day\n" +
                    "\tIn our little poplar log house on the hill\n" +
                    "\n" +

                    "Now my daddy was a good man, which we all would like to be\n" +
                    "When I get to heaven, there his face I’ll see\n" +
                    "When I get through with my singing, I will bid this world “A’Dieu”\n" +
                    "And my little poplar log house on the hill\n" ),

            new Eagle( "20. A BRAND NEW TOUCH.\n","\tCHORUS:\n" +
                    "\tLord, you know I need a brand new touch\n" +
                    "\tMy strength from yesterday is gone\n" +
                    "\tBut if you’ll give me, Lord, another touch,\n" +
                    "\tI’ll have the strength to carry on\n" +
                    "\n" +

                    "I thought the sun had come to stay\n" +
                    "But all too soon it went away\n" +
                    "And in its place the storm clouds came\n" +
                    "And with the clouds, there came the rain\n" +
                    "\n" +

                    "It rained so hard and oh so long\n" +
                    "But midst the storm, I felt a calm\n" +
                    "It was your touch that brought me through it all\n" +
                    "Without your help I’d surely fall\n" +
                    "\n" +

                    "Yesterday has come and gone\n" +
                    "And now the new day’s coming on\n" +
                    "I do not know what it may bring\n" +
                    "My heart may cry instead of sing\n" +
                    "\n" +

                    "But it matters not what comes my way, Lord\n" +
                    "If you’ll just touch me new each day\n" +
                    "Your loving touch dries all my tears way\n" +
                    "Close by your side I want to stay\n" +
                    "\n" +

                    "Lord you know how weak I really am,\n" +
                    "Even better than myself\n" +
                    "But with your help I know I really can\n" +
                    "Everything’s gonna be alright\n" ),

            new Eagle( "21. OH, HE MUST HAVE LOVED ME A LOT.\n","He left the splendors of heaven for me\n" +
                    "And He took on the likeness of man\n" +
                    "He came to live an ungodly world\n" +
                    "Though spotless, the Lamb knew no sin\n" +
                    "All heaven’s foundation were shaken that day\n" +
                    "But for changing His mind, He could not\n" +
                    "Though He knew what He would exactly go through\n" +
                    "Oh! He must have loved me a lot\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tAnd how many tears have I brought to His eyes\n" +
                    "\tI’ve hurt Him more often than not\n" +
                    "\tStill infinite mercy responds to my cry\n" +
                    "\tOh! He must have loved me a lot\n" +
                    "\n" +

                    "He went through the shame of a trial alone\n" +
                    "Through the darkness of death and the grave\n" +
                    "He went through the pain of denial and scorn\n" +
                    "The outcast and beggar to save\n" +
                    "If I have the power to turn back the time,\n" +
                    "Make amends for the things I forgot\n" +
                    "A life time of goodness could never atone\n" +
                    "Oh! He must have loved me a lot\n" ),

            new Eagle( "22. LAST TRAIN TO HEAVEN.\n","You might think it’s foolish saying what I’ve said\n" +
                    "But I just want to tell you I’m not out of my head\n" +
                    "The minutes are so precious\n" +
                    "There’s such a precious few\n" +
                    "And I just want to testify the love God has for you\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tSo I’m taking the last train to heaven\n" +
                    "\tI hope you’ll climb aboard\n" +
                    "\tBefore the whistle blow\n" +
                    "\tTaking the last train to heaven\n" +
                    "\tPlease don’t turn your back and say,\n" +
                    "\t“That’s the way it goes”\n" +
                    "\n" +

                    "Now you might think it’s silly\n" +
                    "Believing what I do\n" +
                    "This is not a story\n" +
                    "That never will come true\n" +
                    "The words are so simple\n" +
                    "So simple but true\n" +
                    "And they just want to testify\n" +
                    "The love God has for you\n" +
                    "\n" +

                    "Now you might think it’s funny\n" +
                    "That we’re the way we are\n" +
                    "Oh, to get a point across\n" +
                    "We’ve gone a bit too far\n" +
                    "The minutes are so precious\n" +
                    "And it’s such a precious few\n" +
                    "That we just want to testify\n" +
                    "The love God has for you\n" ),

            new Eagle( "23. HOW COULD YOU SAY NO.\n","Thorns on His head, spear in His side\n" +
                    "Yet it was a heartache that made Him cry\n" +
                    "He gave His life so you would understand\n" +
                    "Is there any way you could say no to this man?\n" +
                    "\n" +
                    "\n" +

                    "If Christ Himself were standing here,\n" +
                    "Face full of glory and eyes full of tears,\n" +
                    "And He held out His arms and His nail-printed hands,\n" +
                    "Is there any way you could say no to this man.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tHow could you look in His tear-stained eyes?\n" +
                    "\tKnowing it’s you He’s thinking of\n" +
                    "\tCould you tell Him you’re not ready?\n" +
                    "\tTo give Him your life?\n" +
                    "\tCould you say you don’t think you need His love?\n" +
                    "\n" +

                    "Jesus is here with His hands open wide\n" +
                    "You can see Him with your heart\n" +
                    "If you’ll stop looking with your eyes\n" +
                    "He’s left it up to you, He has done all that He can\n" +
                    "Is there any way you could say no to this man?\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThorns on His head, your life in His hand\n" +
                    "\tIs there any way you could say no to this man?\n" +
                    "\tOh! Is there any way you could say no to this man?\n" ),

            new Eagle( "24. LONELY MOUND OF CLAY.\n","Beside a new made grave, heart broken\n" +
                    "My love for her won’t let me go away\n" +
                    "And leave her there to sleep forever\n" +
                    "All alone, beneath that lonely mound of clay\n" +
                    "\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOh, Lord why did you take her from me?\n" +
                    "\tWhy didn’t you take me away?\n" +
                    "\tSo I could have been there beside her\n" +
                    "\tAll alone beneath that lonely mound of clay\n" +
                    "\n" +
                    "\n" +

                    "Many times I’ve looked towards heaven\n" +
                    "And prayed she won’t be taken away\n" +
                    "But a sinner’s prayer was never answered\n" +
                    "So she’s sleeping now beneath the clay\n" +
                    "\n" +
                    "\n" +

                    "I’ll stay here beside you little darling\n" +
                    "And I promise I’ll never go away\n" +
                    "Until my life here is over\n" +
                    "Then I’ll be with you beneath the clay\n" ),

            new Eagle( "25. SORRY I NEVER KNEW YOU.\n","Last night as I lay sleeping, a dream came to me\n" +
                    "I dreamed about the end of time, about eternity\n" +
                    "I saw a million sinners fall on their knees to pray\n" +
                    "The Lord He sadly shook His head, and this I heard him say\n" +
                    "Sorry, I never knew you, Depart from me forever more\n" +
                    "Sorry, I never knew you, go and serve the one that you have served before\n" +
                    "\n" +
                    "\n" +

                    "I thought the time had fully come that I must stand the trial\n" +
                    "I told the Lord that I had been a Christian all the while\n" +
                    "But through His book, He took a look and sadly shook His head;\n" +
                    "Then placed me over on His left, and this I heard Him say\n" +
                    "Sorry, I never knew you, I find no record of your birth\n" +
                    "Sorry, I never knew you, go and serve the one that you served down on earth\n" +
                    "\n" +
                    "\n" +

                    "There were many wife and children, I heard their loving voice\n" +
                    "They must have been so happy, oh how they did rejoice\n" +
                    "Their robes of white around them, their faces all glow\n" +
                    "My little girl looked over at me, and this I heard her say\n" +
                    "Daddy, we can’t go with you, we must dwell in the joys of our Lord\n" +
                    "Sorry, for we still love you, but you’ll never be our daddy any more\n" +
                    "\n" +
                    "\n" +

                    "Now when I had awakened, the tears were in my eyes\n" +
                    "And looking all around me and there to my surprise,\n" +
                    "There were my little babies; I knew it was a dream\n" +
                    "Down beside that bed of mine, you should have heard me scream\n" +
                    "Father, who art in glory, I know thou gave thine only son\n" +
                    "Father, please forgive me, for I want to be ready when you come.\n" ),

            new Eagle( "26. CRUMBS FROM THE TABLE.\n","Lord, bless your children\n" +
                    "Who walk in perfection\n" +
                    "Who manage to master your will\n" +
                    "Give them their share\n" +
                    "Sweet milk and wild honey\n" +
                    "Provide bread of life till they’re filled\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tFeed your children\n" +
                    "\tBut give me the crumbs from the table\n" +
                    "\tI’ll wait for them down on my knees\n" +
                    "\tI’d be ever so grateful\n" +
                    "\tFor the crumbs from the table\n" +
                    "\tFor strength needed to follow thee\n" +
                    "\n" +

                    "Lord I’m not worthy\n" +
                    "To eat from the platter\n" +
                    "See, I’m just a beggar in need\n" +
                    "Satisfy others and when you’re all finished,\n" +
                    "Dear Jesus, have mercy on me\n" ),

            new Eagle( "27. IT’S BEGINNING TO RAIN.\n","It’s beginning to rain, rain, rain\n" +
                    "Hear the voice of the father,\n" +
                    "Saying, “whosoever will”\n" +
                    "Come and drink from the water\n" +
                    "I will pour out my spirit on\n" +
                    "My sons and my daughters\n" +
                    "If you’re thirsty and dry,\n" +
                    "Lift your hand to the sky\n" +
                    "It’s beginning to rain\n" +
                    "\n" +
                    "\n" +

                    "It’s beginning to rain\n" +
                    "Let the spirit directs you\n" +
                    "To peace and to love\n" +
                    "Where no hatred can stand\n" +
                    "And the joy of Christ\n" +
                    "Refreshes your soul\n" +
                    "It’s beginning to rain\n" +
                    "\n" +
                    "\n" +

                    "It’s beginning to rain, rain, rain\n" +
                    "Hear the voice of the father,\n" +
                    "Saying, “whosoever will”\n" +
                    "Come and drink from the water\n" +
                    "I will pour out my spirit on\n" +
                    "My sons and my daughters\n" +
                    "If you’re thirsty and dry,\n" +
                    "Lift your hand to the sky\n" +
                    "It’s beginning to rain.\n" ),

            new Eagle( "28. DADDY’S HANDS.\n","I remember daddy’s hands\n" +
                    "Folded silently in prayers\n" +
                    "Reaching out to hold me\n" +
                    "When I had a nightmare\n" +
                    "You could read quite a story\n" +
                    "In the callouses and lines\n" +
                    "Years of work and worry\n" +
                    "Had left a mark behind\n" +
                    "\n" +


                    "I remember daddy’s hands\n" +
                    "How they held my momma tight\n" +
                    "Patted my back for something done right\n" +
                    "There are things that I’ve forgotten\n" +
                    "That I loved about the man\n" +
                    "But I’ll always remember\n" +
                    "The love in daddy’s hand\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tDaddy’s hands were soft and kind when I was crying\n" +
                    "\tDaddy’s hands were hard as steel when I’d done wrong\n" +
                    "\tDaddy’s hands weren’t always gentle\n" +
                    "\tBut I’ve come to understand\n" +
                    "\tThere was always love in daddy’s hands\n" +
                    "\n" +


                    "I remember daddy’s hands worked until they bled\n" +
                    "Sacrificed unselfishly\n" +
                    "Just to keep us all fed\n" +
                    "If I could things over\n" +
                    "I’d live my life again\n" +
                    "And never take for granted\n" +
                    "The love in daddy’s hands.\n" ),

            new Eagle( "29. IN YOUR OWN TIME.\n","Everything works together for\n" +
                    "The good of those who love you\n" +
                    "Though my heart may be breaking today\n" +
                    "I know you have the answers\n" +
                    "And they’ll be revealed to me\n" +
                    "In your own time, Lord\n" +
                    "In your own way\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tTeach me to be patient\n" +
                    "\tLord, teach me to wait\n" +
                    "\tThe answers may not come today\n" +
                    "\tJust work your will in me\n" +
                    "\tYour glory let me see\n" +
                    "\tIn your own time, Lord\n" +
                    "\tIn your own way\n" +
                    "\n" +

                    "I don’t understand it, Lord\n" +
                    "But someday I will,\n" +
                    "That trials make me stronger each day\n" +
                    "But I’ll serve you willingly\n" +
                    "Whatever way you choose for me\n" +
                    "In your own time, Lord\n" +
                    "In your own way\n" ),

            new Eagle( "30. TEARS ARE LANGUAGE.\n","Often you wonder why\n" +
                    "Tears come into your eyes\n" +
                    "And burden seem to be much more than you can stand\n" +
                    "But God is standing near\n" +
                    "He sees each falling tear\n" +
                    "Tears are a language God understand\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tHe sees the tears of a broken heart and soul\n" +
                    "\tHe sees your tears and hears them when they fall\n" +
                    "\tGod weeps along with man\n" +
                    "\tAnd takes him by the hand\n" +
                    "\tTears are a language God understand\n" +
                    "\n" +


                    "When grief has left you low,\n" +
                    "It causes tears to flow\n" +
                    "Things have not turned out the way you have planned,\n" +
                    "But God won’t forget you\n" +
                    "His promises are true\n" +
                    "Tears are a language God understand\n" ),

            new Eagle( "31. A SINNER'S FRIEND.\n","It was for sinners, Jesus came\n" +
                    "To die upon the cross of shame\n" +
                    "He shed His blood to set us free\n" +
                    "And saved the lives of you and me.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tIt was for you, it was for me\n" +
                    "\tHe walked the road to Calvary\n" +
                    "\tSuch love I’ll never comprehend\n" +
                    "\tThat He would be, a sinner’s friend\n" +
                    "\n" +


                    "Such mercies I could ne’er repay\n" +
                    "But I will serve Him every day\n" +
                    "I’ll sing forever of His grace\n" +
                    "And someday thank Him face to face\n" ),

            new Eagle( "32. I’LL HAVE FAITH.\n","Help me to have faith in you, Lord\n" +
                    "When the things of this world tumble down\n" +
                    "Let me feel your presence near\n" +
                    "And know you, Lord, always around\n" +
                    "\n" +
                    "\n" +

                    "Sometimes the load I can’t carry\n" +
                    "But with your help I can be made strong\n" +
                    "Lord, I know without you I’m nothing\n" +
                    "But a helpless child longing for home\n" +
                    "\n" +
                    "\n" +

                    "I’ll have faith in you, Lord, when I’m weary\n" +
                    "I’ll have faith in you, lord, when I’m sad\n" +
                    "I’ll just cling to the rock of ages\n" +
                    "I’ll have faith and for you firmly stand\n" +
                    "\n" +

                    "I’ll just cling to the rock of ages\n" +
                    "I’ll have faith and for you firmly stand\n" ),

            new Eagle( "33. SINNER, YOU BETTER GET READY.\n","\tCHORUS:\n" +
                    "\tOh, sinner, you better get ready\n" +
                    "\tOh, you better get ready, Hallelujah\n" +
                    "\tSinner, you better get ready\n" +
                    "\tThe time is a’ coming when the sinner must die\n" +
                    "\n" +

                    "Oh, god gave Noah the rainbow sign\n" +
                    "Time is a’ coming when the sinner must die\n" +
                    "It won’t be by water, be by fire next time\n" +
                    "Time is a’ coming when the sinner must die\n" +
                    "\n" +
                    "\n" +

                    "I thought I heard all the preachers say\n" +
                    "Time is a’ coming when the sinner must die\n" +
                    "You better get down on your knees and pray\n" +
                    "Time is a’ coming when the sinner must die\n" ),

            new Eagle( "34. THIS SIDE OF HEAVEN.\n","Many tomes in my life there’s disappointments\n" +
                    "Many things to break my heart along the way\n" +
                    "But through your grace, I find great consolation\n" +
                    "For each valley only taught me how to pray\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tLord, let me live my life for you this side of heaven\n" +
                    "\tMay you be the only star to light my way?\n" +
                    "\tSo that I may save some souls for you, Jesus,\n" +
                    "\tOr help to find a little lamb that’s gone astray\n" +
                    "\tLet your spirit lead and guide me every day\n" +
                    "\n" +


                    "As I work in this life for you, Jesus,\n" +
                    "Help my faith to grow stronger everyday\n" +
                    "Let me hear you say “My child, you have made it\n" +
                    "With some souls that you have won along the way”\n" ),

            new Eagle( "35. WITH JESUS WE’LL ALWAYS BE.\n","This time we’ll meet never to part\n" +
                    "With Jesus we’ll always be\n" +
                    "\n" +

                    "I woke up this morning\n" +
                    "Wondering could this be the day\n" +
                    "When those who beneath us are resting\n" +
                    "Would rise to bring on that new day\n" +
                    "Then my heart begins to beat for joy\n" +
                    "Knowing what day that will be\n" +
                    "When the bride will go to meet Jesus\n" +
                    "The bridegroom she so longs to see\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tIt will be the greatest morning ever\n" +
                    "\tWhen our Lord once again we’ll behold\\\n" +
                    "\tThis time we’ll meet never to part\n" +
                    "\tWith Jesus we’ll always be\n" +
                    "\n" +


                    "The signs and times are telling us\n" +
                    "That this is the day He’ll return\n" +
                    "There’s wars and earth quake everywhere\n" +
                    "Hearts failing for the trouble they see\n" +
                    "And the prophet has cried out again\n" +
                    "“Oh, people, return back to God\n" +
                    "For Jesus is coming for the bride\n" +
                    "Whose garments are spotless and white.”\n" ),

            new Eagle( "36. WHO I AM.\n","Oh, glorious victory, the day He set me free\n" +
                    "And He made my heart His very throne\n" +
                    "My life is no longer mine\n" +
                    "I’m a prisoner of love Divine\n" +
                    "And now I live to praise His Name\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tWho I am, Lord\n" +
                    "\tWho I am\n" +
                    "\tI can see now, who I am\n" +
                    "\tA part of my saviour\n" +
                    "\tA part of His word\n" +
                    "\tIt is a revelation (predestination)\n" +
                    "\tOf who I am\n" +
                    "\n" +

                    "On Calvary He died, to redeem His lost bride\n" +
                    "The King of kings became my savior\n" +
                    "This is God great mystery\n" +
                    "Of love expressed to me\n" +
                    "That Christ and I might be made one\n" ),

            new Eagle( "37. I WANT US TO BE TOGETHER IN HEAVEN.\n","You may have a fancy car,\n" +
                    "A brand new house that shines by far\n" +
                    "You may live to be a hundred years old\n" +
                    "And though you give a farming grain,\n" +
                    "It will end in the grave\n" +
                    "But I want us to be together in heaven.\n" +
                    "\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI want us, to be together in heaven,\n" +
                    "\tI want to walk, down the streets of pure gold\n" +
                    "\tI want to run through the fields of green clover\n" +
                    "\tSee the mansions, smell the flowers, hear the singing, it’s all ours\n" +
                    "\tSee river, gently flowing,\n" +
                    "\tFeel the gentle breezes blowing\n" +
                    "\tI want us to be together in heaven.\n" +
                    "\n" +
                    "\n" +

                    "You may be a millionaire,\n" +
                    "Wearing clothes beyond compare\n" +
                    "You may have the best that money can buy\n" +
                    "But if the blood is not applied,\n" +
                    "Then in hell you’ll lift your eyes\n" +
                    "But I want us to be together in heaven.\n" ),

            new Eagle( "38. WAYFARING STRANGER.\n","I’m a poor wayfaring stranger\n" +
                    "Travelling this world of woe\n" +
                    "Yet there’s no sickness, toil or danger\n" +
                    "In that world to which I go\n" +
                    "\n" +

                    "I’m going there to see my father\n" +
                    "I’m going there no more to roam\n" +
                    "I’m only going over Jordan\n" +
                    "I’m only going over home\n" +
                    "\n" +

                    "And though dark clouds will gather round me,\n" +
                    "I know my way is rough and steep\n" +
                    "Yet beauteous fields lie just before me\n" +
                    "Where God’s redeem their vigils keep\n" +
                    "\n" +

                    "I’m going there to see my mother\n" +
                    "She said she’d meet me when I come\n" +
                    "I’m only going over Jordan\n" +
                    "I’m only going over home\n" +
                    "I’m only going over home\n" ),

            new Eagle( "39. I’M USING MY BIBLE FOR A ROAD MAP.\n","I’m using my Bible for a road map\n" +
                    "Ten Commandments tell me what to do\n" +
                    "The twelve disciples are my road signs\n" +
                    "And Jesus will see safely through\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThere’ll be no detours in heaven\n" +
                    "\tNo rough roads along the way\n" +
                    "\tI’m using my Bible for a road map\n" +
                    "\tMy last stop is heaven some sweet day\n" +
                    "\n" +

                    "I’m using my Bible for a road map\n" +
                    "The children of Israel used it too\n" +
                    "They crossed the red sea of destruction\n" +
                    "For God was there to see them through\n"),

            new Eagle( "40. LITTLE WHITE CHURCH.\n","There’s a little white church in the valley\n" +
                    "That stands in my memory each day\n" +
                    "And it seem I can the bell ringing\n" +
                    "Though I am many miles away\n" +
                    "And many times on Sunday morning\n" +
                    "The whole country side would gather there\n" +
                    "They would all kneel down by the alter\n" +
                    "As they lifted up their voices and pray\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOh, that church in the valley\n" +
                    "\tOh, that little white church\n" +
                    "\tIs the place I love so well\n" +
                    "\tNow I’m sad and lonely\n" +
                    "\tYes, I’m sad and lonely\n" +
                    "\tFor that little white church in the dale\n" +
                    "\n" +

                    "They would sing the old songs, Rock of Ages\n" +
                    "Christ, let me hide myself in thee\n" +
                    "And I know some of them are now waiting\n" +
                    "Just o’er\n" +
                    "The dark and stormy sea\n" +
                    "I know their troubles have all ended\n" +
                    "How happy forever they shall be\n" +
                    "They are watching, waiting up yonder\n" +
                    "For the coming home of you and me\n" ),

            new Eagle( "41. TOO MANY SUNSETS.\n","Too many miles behind me,\n" +
                    "Too many trials are through\n" +
                    "Too many tears help me to remember\n" +
                    "There’s too much to gain to lose\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tToo many sunsets lie behind the mountain\n" +
                    "\tToo many rivers my feet I’ve walked through\n" +
                    "\tToo many treasures are waiting over yonder\n" +
                    "\tThere’s too much to gain to lose\n" +
                    "\n" +

                    "I crossed the hot burning desert\n" +
                    "Struggling the right roads to cross\n" +
                    "Somewhere ahead theirs is cool clear water\n" +
                    "And defeat is one word I don’t use\n" ),

            new Eagle( "42. THE UNSEEN HAND.\n","There is an unseen hand to me,\n" +
                    "That leads the way where I cannot see,\n" +
                    "While going through this world of war,\n" +
                    "His hand still leads me as I go.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI’m trusting to, the unseen hand,\n" +
                    "\tThat leads me through, this weary land,\n" +
                    "\tAnd some sweet day, I’ll reach that strand,\n" +
                    "\tStill guided by, the unseen hand.\n" +
                    "\n" +

                    "His hand has led through shadows drear,\n" +
                    "And while it leads I have no fear,\n" +
                    "I know it will lead me to that home,\n" +
                    "Where sin nor sorrow never can come.\n" + "\n" +

                    "I long to see my Saviour’s face,\n" +
                    "And sing the story saved by grace,\n" +
                    "And there upon that golden strand,\n" +
                    "I’ll praise Him for His guiding hand.\n" ),

            new Eagle( "43. THESE ARE THE TREASURES.\n","When driving on day through the quiet countryside,\n" +
                    "An old man was walking, so I offered a ride\n" +
                    "His face was al wrinkled, his hair turned to gray\n" +
                    "And these are the words he had to say\n" +
                    "\n" +

                    "I may like a beggar, but I’m rich as a king\n" +
                    "What I have in my heart gives me a reason to sing\n" +
                    "I’m a joint heir with Jesus, so why should I sigh\n" +
                    "For these are the treasures that money can’t buy\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tWhen is worthless when a soul is at stake\n" +
                    "\tIf gold bought redemption, how much would it take?\n" +
                    "\tBut He loved me and saved me I can’t explain why,\n" +
                    "\tAnd these are the treasures; these are the treasures that money can’t buy\n" +
                    "\n" +

                    "So if you look at my garments and notice they’re torn\n" +
                    "Well, I’ve a new royal garment that’s never been worn\n" +
                    "And the cabin I’ll live in is home till I die\n" +
                    "But I’ve a mansion in glory that money can’t buy\n" ),

            new Eagle( "44. JOY UNSPEAKABLE.\n","I have found His grace is all complete\n" +
                    "He supplied every need;\n" +
                    "While I sit and learn at Jesus’ feet\n" +
                    "I am free, yes, free indeed\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tIt is joy unspeakable and full of glory\n" +
                    "\tFull of glory full of glory\n" +
                    "\tIt is joy unspeakable and full of glory\n" +
                    "\tOh! The half has never yet been told.\n" +
                    "\n" +

                    "I have found the pleasure I once craved\n" +
                    "It is joy and peace within\n" +
                    "What a wondrous blessing! I am saved\n" +
                    "From the awful gulf of sin\n" +
                    "\n" +

                    "I have found that hope so bright and clear\n" +
                    "Living in the realm of grace\n" +
                    "Oh, the Saviours’ presence is so near\n" +
                    "I can see His smiling face\n" +
                    "\n" +

                    "I have found the joy not tongue can tell\n" +
                    "How it’s wave of glory roll!\n" +
                    "It is like a great over-flowing whale\n" +
                    "Springing up within my soul\n" ),

            new Eagle( "45. ROBE OF WHITE.\n","The postman knocked and waited for a sweet face to appear\n" +
                    "A face that showed her heart was full of joy\n" +
                    "In the cottage doorway, smiling through her tears\n" +
                    "Each time he brought a message from her boy\n" +
                    "\n" +

                    "Her calloused hands were trembling\n" +
                    "The postman noticed too\n" +
                    "That her sweet and anxious face was white\n" +
                    "Would this be the letter that she had waited for,\n" +
                    "And would it tell her that he was alright?\n" + "\n" +

                    "“I’m sorry,” said the postman, “I’m must ask you to sign\n" +
                    "This little book that I have brought along.\n" +
                    "You see, this letter’s registered” he slowly bowed His head\n" +
                    "And then she knew that there was something wrong\n" +
                    "\n" +

                    "The address on the corner of this envelope of blue\n" +
                    "Told her that her darling son was dead\n" +
                    "Where Jimmy’s name and number had always been before\n" +
                    "His captain’s name was written there instead\n" +
                    "\n" +

                    "Dear God, they’ve made my darling’s grave\n" +
                    "Thou knowest of his soul\n" +
                    "She prays an humble prayer to God each night\n" +
                    "Place on his a blooming rose so all the world can see\n" +
                    "My soldier boy has won his robe of white\n" ),

            new Eagle( "46. DO YOU KNOW MY JESUS?\n","Have you a heart that’s weary\n" +
                    "Tending a load of care?\n" +
                    "Are you a soul that’s seeking?\n" +
                    "Rest from the burden you bear\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tDo you know (do you know) my Jesus\n" +
                    "\tDo you know (do you know) my friend?\n" +
                    "\tHave you heard (have you heard) He loves you\n" +
                    "\tAnd that He will abide till the end?\n" + "\n" +

                    "Where is your heart, oh, pilgrim?\n" +
                    "What does your life reveal?\n" +
                    "Who hears your call for comfort?\n" +
                    "When naught but sorrow you feel?\n" + "\n" +

                    "Who knows your disappointments?\n" +
                    "Who knows each time you cry?\n" +
                    "Who understands your heartaches?\n" +
                    "Who dries the tears from your eyes?\n" ),

            new Eagle( "47. I CROSS THE RIVER FROM HERE.\n","Someday I’ll go to that far off shore,\n" +
                    "I’ll cross the river from here\n" +
                    "I’ll live in sunshine forever more,\n" +
                    "I’ll cross the river from here.\n" + "\n" +

                    "\tCHORUS:\n" +
                    "\tI’ll cross the river from here I’ll go,\n" +
                    "\tI’ll cross the river from here.\n" +
                    "\tI’ll stand beside Him someday I know,\n" +
                    "\tI’ll cross the river from here.\n" + "\n" +

                    "My home will be in that mansion fair,\n" +
                    "I’ll cross the river from here.\n" +
                    "To reach that gate I must climb the stair,\n" +
                    "I’ll cross the river from here.\n" + "\n" +

                    "I’ll leave my treasures up there behind,\n" +
                    "I’ll cross the river from here.\n" +
                    "I know His treasures up there are mine,\n" +
                    "I’ll cross the river from here.\n" ),

            new Eagle( "48. SEE YOU IN THE RAPTURE.\n","\tCHORUS:\n" +
                    "\tI’ll see you in the rapture, see you in the rapture,\n" +
                    "\tI’ll see you in that meeting in the air,\n" +
                    "\tThere with my blessed Saviour we’ll live and reign forever,\n" +
                    "\tI’ll see you in the rapture some sweet day.\n" + "\n" +


                    "If we never meet again,\n" +
                    "On this earth my precious friend,\n" +
                    "If to God we have been true,\n" +
                    "And lived the Bible scene,\n" +
                    "Then for us there’ll be a greeting,\n" +
                    "For there’s going to be a meeting\n" +
                    "I’ll see you in the rapture some sweet day\n" + "\n" +


                    "To my loved ones let me say,\n" +
                    "That there’ll surely come a day,\n" +
                    "When my Lord will come again, to take His bride away,\n" +
                    "So get ready now to meet Him,\n" +
                    "And with Hallelujahs greet Him,\n" +
                    "Yes, I’ll see you in the rapture some sweet day.\n" + "\n" +

                    "To my brothers let me say, you must see your day,\n" +
                    "And be filled with God’s love, and get that perfect faith,\n" +
                    "So get ready now to meet Him, and with Hallelujah greet Him,\n" +
                    "I’ll see you in the rapture some sweet day.\n" ),

            new Eagle( "49. HALLELUJAH IN MY HEART.\n","O, Lord I stand before you, the past I can’t deny\n" +
                    "A sinner from the old school, repent before I die\n" +
                    "I’ve tried to run, I’ve tried to hide\n" +
                    "I’ve tried so hard to stray\n" +
                    "But your love has found its way around\n" +
                    "And grace has paved the way\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tNo more to roam, I’ve found my home\n" +
                    "\tHallelujah, in my heart\n" +
                    "\tI’m not alone, love walks with me\n" +
                    "\tHallelujah, in my heart\n" + "\n" +

                    "Salvation sweet awaits us, beyond the shining light\n" +
                    "A chance for you and me, we better do it right\n" +
                    "And so it goes, you reap what you sow\n" +
                    "My oats were wild and green\n" +
                    "But faith has found its way around\n" +
                    "And does salvation bring\n" ),

            new Eagle( "50. I HAVE FOUND THE WAY.\n","I have the way that leads to endless land\n" +
                    "Yonder in the glory land\n" +
                    "And the road is bright, for Jesus is the light\n" +
                    "And I hold His guiding hand\n" + "\n" +

                    "\tCHORUS:\n" +
                    "\tI have found the way\n" +
                    "\t(I have found the way, I have found the glory way)\n" +
                    "\tI have found the way\n" +
                    "\t(I have found the way) (I have found the gospel way)\n" +
                    "\tGlory Hallelujah\n" +
                    "\t(Glory Hallelujah, Hallelujah, Hallelujah)\n" +
                    "\tI have found the way\n" +
                    "\t(I have found the way, I have found the way)\n" + "\n" +


                    "I will never fear while Jesus is so near\n" +
                    "I will bravely meet the foe\n" +
                    "Happy songs I’ll sing in honor to the King\n" +
                    "And to glory onward go\n" + "\n" +


                    "To the journey’s end, led by a faithful Friend\n" +
                    "Never more in sin to roam\n" +
                    "By the way called straight, I’ll reach the golden gate\n" +
                    "Of the soul’s eternal home\n" ),

            new Eagle( "51. A BEAUTIFUL CITY.\n","Just over the hill\n" +
                    "Is a beautiful city\n" +
                    "Where my loved ones and friends\n" +
                    "Will welcome me there\n" +
                    "And I know I am bound for the beautiful city\n" +
                    "For I can feel His presence more clear\n" +
                    "\n" +

                    "And I get there\n" +
                    "I’ll never more roam\n" +
                    "But singing and shouting in my new home\n" +
                    "One moment will be a thousand years\n" +
                    "And there will never be no more tears\n" +
                    "\n" +

                    "Just a few more days and I will cross over\n" +
                    "To place without sorrow or fear\n" +
                    "And I’m longing to live in that bright city\n" +
                    "Cause nobody knows what a load I bear\n" ),

            new Eagle( "52. JESUS IS WHISPERING NOW.\n","Life is a gift that we all must lay down\n" +
                    "Whether we be rich or poor\n" +
                    "And Jesus is willing to give us a crown\n" +
                    "And fill us with love that is pure\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tJesus is whispering, whispering now\n" +
                    "\tWhy will you wait? Why will you wait?\n" +
                    "\tJesus is whispering, whispering now\n" +
                    "\tList to His voice, don’t turn Him away\n" +
                    "\n" +

                    "If life seems so hard and seems useless to I’ve\n" +
                    "With trials and troubles to face\n" +
                    "Just ask God to comfort, He’s willing and will\n" +
                    "Let gladness and love take its place\n" +
                    "\n" +

                    "Willing to bow in the presence of God\n" +
                    "Striving to win a reward\n" +
                    "Wondering home on this path that I trod\n" +
                    "Willing to work for the Lord\n" ),

            new Eagle( "53. JUST BEYOND THE RIVER.\n","Just beyond the Jordan River\n" +
                    "There beside the crystal sea\n" +
                    "Lies a city built of mansions\n" +
                    "Will there be one there for me?\n" +
                    "When my work on earth is ended\n" +
                    "And I sleep beneath the sod\n" +
                    "Will my soul sing with the angels?\n" +
                    "Around the blessed throne of God?\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tBlessed Jesus gently guide me\n" +
                    "\tO’er life’s ocean dark and wide\n" +
                    "\tBlessed Jesus gently guide me\n" +
                    "\tSafely to the other side\n" +
                    "\tWhen my work on earth is ended\n" +
                    "\tAnd I sleep beneath the sod\n" +
                    "\tWill my soul sing with the angels?\n" +
                    "\tAround the blessed throne of God?\n" +
                    "\n" +

                    "Oft I see the tempest raging\n" +
                    "Then with strength I pull the oar\n" +
                    "Jesus is the light house keeper\n" +
                    "He will guide me to that shore\n" +
                    "Will I anchor in deep harbor?\n" +
                    "Never more to drift away?\n" +
                    "There I’ll meet with all my loved ones\n" +
                    "There to live eternally\n" ),

            new Eagle( "54. ON THE ROCK WHERE MOSES STOOD.\n","Crying holy unto the lord\n" +
                    "Crying holy unto the lord\n" +
                    "Oh, in that day when the bells all toll\n" +
                    "Crying holy unto the lord\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tCrying holy unto the lord\n" +
                    "\tCrying holy unto the lord\n" +
                    "\tIf I could, I surely would\n" +
                    "\tStand on the rock (praise God) where Moses stood\n" +
                    "\n" +

                    "Sinners, run unto the Lord\n" +
                    "Sinners, run unto the Lord\n" +
                    "Oh, please don’t let this harvest pass\n" +
                    "And lose your soul at last\n" +
                    "\n" +

                    "Crying holy unto the lord\n" +
                    "Crying holy unto the lord\n" +
                    "The four and twenty elders bowing all around the alter\n" +
                    "Crying holy unto the lord\n" ),

            new Eagle( "55. JESUS DIED FOR ME.\n","Jesus died for me long ago, long ago\n" +
                    "On a hillside far away\n" +
                    "He was tortured and slain\n" +
                    "God bless his Holy name\n" +
                    "Jesus died for me long ago\n" +
                    "\n" +
                    "\n" +

                    "When everything goes wrong,\n" +
                    "It seems all hope is gone\n" +
                    "I remember how my savior died\n" +
                    "He died there on the cross, so this world would not be lost\n" +
                    "Jesus died for me long ago\n" +
                    "\n" +

                    "As He hung there all alone\n" +
                    "His lifeblood almost gone\n" +
                    "He never stopped praying for me\n" +
                    "I’ll follow all the way and live with Him someday\n" +
                    "Jesus died for me long ago" ),

            new Eagle( "56. STANDING SOMEWHERE IN THE SHADOWS.\n","When the world is crumbling ‘round you,\n" +
                    "And everything goes wrong,\n" +
                    "And you feel that there’s no use to carry on\n" +
                    "Just remember Jesus loves you\n" +
                    "And careth for His own\n" +
                    "So trust in Him when hope is almost gone\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tStanding somewhere in the shadows you’ll find Jesus\n" +
                    "\tHe’s the only one who cares and understands\n" +
                    "\tStanding somewhere in the shadows you’ll find Him\n" +
                    "\tAnd you’ll know Him by the nail prints in His hands\n" +
                    "\n" +

                    "Though Satan tempts you tries to make you doubt,\n" +
                    "The Lord is near to hold you by His hands\n" +
                    "With His loving arms around you, He’ll gently lead you out\n" +
                    "He’ll strengthen you and give you grace to stand" ),

            new Eagle( "57. GONE AWAY.\n","\tCHORUS:\n" +
                    "\tGone away, gone away\n" +
                    "\tAll troubles in my soul have gone away\n" +
                    "\tI was lost out in the night, but praise God\n" +
                    "\tI saw the light\n" +
                    "\tAnd the troubles in my soul have gone away\n" +
                    "\n" +

                    "I was down, I was discouraged\n" +
                    "Every dream I ever had was gone\n" +
                    "But thru Him, I found the courage\n" +
                    "And now I’ve got the strength I need to carry on\n" +
                    "\n" +

                    "You know that life, it don’t come easy\n" +
                    "And sometimes you feel like giving in\n" +
                    "But there’s a better day a’ coming\n" +
                    "If you get down on your knees and talk with Him\n" + "\n" +

                    "When the days get dark and dreary,\n" +
                    "And it seems there’s more than you can bear\n" +
                    "Just remember there is an answer\n" +
                    "If you will believe and raise your voice in prayer"),

            new Eagle( "58. BEAUTIFUL ISLE.\n",
                    "Somewhere the sun is shining\n" +
                    "Somewhere the song birds dwell\n" +
                    "Hush then my sad repining\n" +
                    "God lives and all is well\n" +
                    "\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tSomewhere, Somewhere\n" +
                    "\tBeautiful Isle of Somewhere\n" +
                    "\tLand of the true\n" +
                    "\tWhere we live a-new\n" +
                    "\tBeautiful Isle of somewhere\n" +
                    "\n" +

                    "Somewhere the day is longer\n" +
                    "Somewhere the task is done\n" +
                    "Somewhere the heart is stronger\n" +
                    "Somewhere the victory’s won\n" +
                    "\n" +

                    "Somewhere the load is lifted\n" +
                    "Close by an open gate\n" +
                    "Somewhere the clouds are rifted\n" +
                    "Somewhere the angels wait\n" ),

            new Eagle( "59. WE ARE GOING DOWN THE VALLEY.\n","We are going down the valley one by one\n" +
                    "With our faces toward the setting of the sun\n" +
                    "Down the valley where the mournful cypress grows\n" +
                    "Where the stream of death in silence onward flows\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tWe are going down the valley, going down the valley\n" +
                    "\tGoing toward the setting of the sun\n" +
                    "\tWe are going down the valley, going down the valley\n" +
                    "\tGoing down the valley one by one\n" +
                    "\n" +

                    "We are going down the valley one by one\n" +
                    "When the labors of the weary day are gone\n" +
                    "One by one, the cares of earth forever past\n" +
                    "We shall stand upon the river bank at last\n" +
                    "\n" +

                    "We are going down the valley one by one\n" +
                    "Human comrade you or I will there have none\n" +
                    "But tender hand will guide us lest we fall\n" +
                    "Christ is going down the valley with us" ),

            new Eagle( "60. YOU HAVE BEEN AN INSPIRATION TO ME.\n","For many years I’ve travelled in this low land\n" +
                    "And always you have shown me loyalty\n" +
                    "Now I would like to tell you as a brother\n" +
                    "You’ve been an inspiration to me\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tYou have been an inspiration\n" +
                    "\tAll through this world below\n" +
                    "\tYou’ve been an inspiration\n" +
                    "\tI’m glad to let you know\n" +
                    "\tYou’ve been a friendly neighbor\n" +
                    "\tI know you’ll always be\n" +
                    "\tAnd I would like to tell you while I may,\n" +
                    "\tYou’ve been an inspiration to me.\n" +
                    "\n" +

                    "I’d like to have you with me when I’m leaving\n" +
                    "To sail away to God eternity.\n" +
                    "I know that you’d be faithful then as always\n" +
                    "You’ve been an inspiration to me.\n" ),

            new Eagle( "61. GONE HOME.\n","All of the friends that I loved yesterday,\n" +
                    "Gone home (they have gone home).\n" +
                    "Gone home (they have gone home).\n" +
                    "The song birds are singing and they seem to say\n" +
                    "Gone home (they have gone home).\n" +
                    "Gone home (they have gone home).\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThey’ve joined the heavenly fold\n" +
                    "\tThey’re walking on the streets of pure gold\n" +
                    "\tThey left one by one\n" +
                    "\tAs their work here was done\n" +
                    "\tGone home (they have gone home).\n" +
                    "\tGone home (they have gone home).\n" +
                    "\n" +

                    "Life here is lonely since they’ve gone before\n" +
                    "Gone home (they have gone home).\n" +
                    "Gone home (they have gone home).\n" +
                    "The old weeping willow that stands by the door\n" +
                    "Sad to say (they’ve gone home)\n" +
                    "Gone home (they have gone home).\n" ),

            new Eagle( "62. JOY BELLS.\n","\tCHORUS:\n" +
                    "\tJoy bells, joy bells, everlasting joy bells\n" +
                    "\tI can hear them ringing while the Hallelujah’s roll\n" +
                    "\tJoy bells, joy bells, heavenly joy bells\n" +
                    "\tHe keeps the joy bells ringing deep down in my soul\n" +
                    "\n" +

                    "One day I fell down on my knees\n" +
                    "And Jesus heard me pray\n" +
                    "He lifted me with His spirit\n" +
                    "And washed my sin away\n" +
                    "And then the bells of glory on me began to toll\n" +
                    "Now Jesus keeps the joy bells ringing in soul" ),

            new Eagle( "63. IT’S ME AGAIN LORD.\n","Troubles come and I can’t find an answer\n" +
                    "Lonely nights I spend in agony\n" +
                    "I have no other friend that I can turn to\n" +
                    "So here I am, Lord, back upon my knees\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tIt’s me again, Lord\n" +
                    "\tI got a prayer that needs an answer\n" +
                    "\tIt’s me again, Lord\n" +
                    "\tO got a problem I can’t solve\n" +
                    "\tWell, I don’t mean to worry you\n" +
                    "\tBut here I am facing something new\n" +
                    "\tAnd I need the help that only comes from you\n" +
                    "\tIt’s me again, Lord\n" +
                    "\n" +

                    "Well, I know you’re mighty busy in your heaven\n" +
                    "Hearing prayers and helping friends of mine\n" +
                    "But you promised if I’d ask that I’d receive it\n" +
                    "So here I am, Lord, asking one more time\n" +
                    "It’s me again, Lord\n" ),

            new Eagle( "64. FAMILY ALTER.\n","Have you ever had your family?\n" +
                    "To all kneel down and pray?\n" +
                    "Asking God to bless you and guide you day by day\n" +
                    "Feeling joy come down from heaven,\n" +
                    "As you gathered there,\n" +
                    "Knowing God was keeping watch with tender loving care\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tFamily altar, the foundation of a home\n" +
                    "\tGod would bless that altar as if it were His throne\n" +
                    "\tIt shows you trust in Jesus, believing in His word\n" +
                    "\tWhen you kneel at your altar, your every prayer is heard\n" +
                    "\n" +

                    "There’s many little children that’s raised in homes today\n" +
                    "That’s never seen a Bible or heard their parents pray\n" +
                    "If they go wrong in later years, we’ll be the ones to blame\n" +
                    "Let’s learn them now to trust in God\n" +
                    "At the family altar, pray" ),

            new Eagle( "65. HELP ME UNDERSTAND.\n","I’m just a weary pilgrim\n" +
                    "Gonna serve Him day by day\n" +
                    "I need to reach that city\n" +
                    "Oh, come what may\n" +
                    "My promise of tomorrow\n" +
                    "I cannot be assured\n" +
                    "But the one thing that I know\n" +
                    "He leads me everywhere\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tO lord, help me, that I understand,\n" +
                    "\tSo I can see the blessed Promised Land\n" +
                    "\tWhen I reach heaven I can see\n" +
                    "\tI’m glad I travelled on this way\n" +
                    "\tOh lord, help me, that I may understand\n" +
                    "\n" +
                    "\n" +

                    "Remember ol’ Jonah\n" +
                    "Seemed not to understand\n" +
                    "When God called him to preach down in Nineveh land\n" +
                    "But he disobeyed and on a ship that sailed away\n" +
                    "He was thrown overboard to a whale that day\n" ),

            new Eagle( "66. THE GOSPEL WAY.\n","There’s a right and a wrong way to press along\n" +
                    "And the right one you one must take\n" +
                    "If you want a friend at the journey’s end\n" +
                    "Not a debt on that great pay day\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tNever stop or wait lest you be too late\n" +
                    "\tTo inherit the golden crown\n" +
                    "\tYou must work each day in the gospel way\n" +
                    "\tIf your works of God be found\n" +
                    "\n" +

                    "Do you love your neighbor as yourself?\n" +
                    "Do you cheat him not in trade?\n" +
                    "Would your conscience groan on tomorrow’s dawn\n" +
                    "Should you meet him on the way?\n" +
                    "\n" +

                    "Never do good deeds for the praise of man\n" +
                    "Even though that they might see\n" +
                    "But in secret give and in secret pray\n" +
                    "He’ll reward you openly" ),

            new Eagle( "67. WIIL THERE BE ANY STARS?\n","I am thinking today of that beautiful land,\n" +
                    "I shall reach when the sun goeth down\n" +
                    "When through wonderful grace by my savior I stand\n" +
                    "Will there be any stars in my crown?\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tWill there be any stars, any stars in my crown,\n" +
                    "\tWhen at evening the sun goeth down? (Goeth down)\n" +
                    "\tWhen I wake with the blest, in the mansion of rest,\n" +
                    "\tWill there be any stars, any stars in my crown,\n" +
                    "\n" +

                    "In the strength of the Lord let me lab our and pray,\n" +
                    "Let me watch as a winner of soul\n" +
                    "That bright stars may be mine in the glorious day,\n" +
                    "When His praise like the sea billows roll\n" +
                    "Will there be any stars, any stars in my crown,\n" +
                    "\n" +
                    "\n" +

                    "O what joy will it be when His face I behold\n" +
                    "Living gems at His feet to lay down\n" +
                    "It would sweeten my bliss, in that city of gold\n" +
                    "Should there be any stars in my crown\n" ),

            new Eagle( "68. YOU CAN FEEL IT IN YOUR SOUL.\n","If you go to church on Sunday,\n" +
                    "And leave the savior out you feel like you’re alone\n" +
                    "When they all begin to shout\n" +
                    "When you get old time religion\n" +
                    "You want the world to know\n" +
                    "But you won’t have to ask nobody\n" +
                    "You can feel it in your soul\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tYou can feel it in your soul\n" +
                    "\tAnd you want the world to know\n" +
                    "\tAnd you won’t have to ask nobody\n" +
                    "\tYou can feel it in your soul\n" +
                    "\n" +

                    "Some people ask their neighbors\n" +
                    "About the ways of sin and what they have to do\n" +
                    "For Christ to live within\n" +
                    "But let me tell you, brother,\n" +
                    "There is one thing you should do\n" +
                    "And you won’t have to ask nobody\n" +
                    "You can feel it in your soul\n" +
                    "\n" +

                    "If you have a kind of religion,\n" +
                    "And don’t know what to do you better pick up your Bible\n" +
                    "And read the pages through\n" +
                    "He tells you in His word\n" +
                    "Ever thing you want to know\n" +
                    "And you won’t have to ask your neighbor\n" +
                    "You can feel it in your soul\n" ),

            new Eagle( "69. THROUGH IT ALL.\n","I’ve had many tears and sorrows\n" +
                    "I’ve had questions for tomorrow\n" +
                    "There’ve been times I didn’t know the right from wrong\n" +
                    "But in every situation\n" +
                    "God gave blessed consolation\n" +
                    "That my trials come to only make me strong\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThrough it all, through it all\n" +
                    "\tI’ve learnt to trust in Jesus\n" +
                    "\tI’ve learnt to trust in God\n" +
                    "\tThrough it all, through it all\n" +
                    "\tI’ve learnt to depend upon His word.\n" +
                    "\n" +

                    "I’ve been t6o lots of places\n" +
                    "And I’ve seen a lot of faces\n" +
                    "There’ve been times I felt so all alone\n" +
                    "But in my lonely hours\n" +
                    "Yes, those precious lonely hours\n" +
                    "Jesus lets me know that I was His own\n" +
                    "\n" +

                    "I thank God for the mountains\n" +
                    "And I thank Him for the valleys\n" +
                    "I thank Him for the storms He brought me thru\n" +
                    "For if I’d never had a problem\n" +
                    "I wouldn’t know that He could solve them\n" +
                    "I’ve never know what faith in God could do\n" ),

            new Eagle( "70. JESUS WALKED UPON THE WATER.\n","Jesus walked upon the water,\n" +
                    "Of the stormy Galilee,\n" +
                    "And He said, “if you are faithful,\n" +
                    "You can come and walk with me”\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tJesus walked upon the water,\n" +
                    "\tWhen the waves were dashing high\n" +
                    "\tAnd He calmed the angry billows,\n" +
                    "\tTill the storm had passed Him by\n" +
                    " \n" +
                    "\n" +

                    "Jesus walked upon the water,\n" +
                    "Just to show the power of God\n" +
                    "And the glory shown around Him\n" +
                    "On the billows where He trod\n" +
                    "\n" +

                    "Jesus walked upon the water\n" +
                    "Where no mortal man would dare\n" +
                    "It was like a light from heaven\n" +
                    "As He blessed His people there\n" ),

            new Eagle( "71. DID YOU EVER GO SAILIN’?\n","There is an old ramshackle shack\n" +
                    "Where in dreams I wander back\n" +
                    "And listen to those Southern melodies\n" +
                    "‘Twas the place where I was born,\n" +
                    "On a bright October morn\n" +
                    "And it’s nestled at the end of\n" +
                    "My river of memories\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tDid you ever go sailin’ " +
                    "\tdown the river of memories\n" +
                    "\tTo a little log cabin that is nestled " +
                    "\tamong the sycamore trees;\n" +
                    "\tWhere the sunshine is cheery and " +
                    "\tnothing in the world grows dreary\n" +
                    "\tThere’s a cabin " +
                    "\tat the end of my river of memories\n" +
                    "\n" +

                    "There’s a mother old and gray\n" +
                    "At the end of memory’s way\n" +
                    "I will meet her there tonight among the trees\n" +
                    "With a smile of welcome, she\n" +
                    "So sweetly beckons me\n" +
                    "To that cabin at the end of\n" +
                    "My river of memories\n" +
                    "\n" +
                    "\n" +

                    "When the twilight shadows fall\n" +
                    "Many childhood voices call\n" +
                    "Call me back again to days that used to be\n" +
                    "And in answer to their prayer\n" +
                    "I will soon be sailin’ there\n" +
                    "To that cabin at the end of\n" +
                    "My river of memories\n" ),


            new Eagle( "72. MY JOURNEY TO THE SUN.\n","On a fire and brimstone church house pew, my back against the wall\n" +
                    "I convinced myself I’d cut and run when it came to altar call\n" +
                    "But on this night things were different, that old\n" +
                    "Preacher spoke of grace\n" +
                    "And for those who dared to taste it, they would\n" +
                    "See the master’s face\n" +
                    "\n" +

                    "Now each and every word he uttered cut and pierced my heart\n" +
                    "For the first time there was a ring of truth,\n" +
                    "Resounding in the dark\n" +
                    "When I felt the spirit move me, I knew my time had come\n" +
                    "On a tearful trip I started my journey to the son\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tNow nothing sounds so sweet as the sound of pilgrims’ feet\n" +
                    "\tOn the narrow way that blesses all who come\n" +
                    "\tAnd the peace that I found is like no other\n" +
                    "\tOn my journey to the son\n" +
                    "\n" +

                    "Oh the tribulations of this world have bogged my every step\n" +
                    "Many times I beg for mercy by the bed where I slept\n" +
                    "In His love my plea is granted, by His strength I overcome\n" +
                    "With His guiding hand, I resume my journey to the son\n" ),

            new Eagle( "73. HIDE THOU ME.\n","Sometimes I feel discouraged and think my work’s in vain\n" +
                    "I’m tempted oft to murmur, to grumble and complain\n" +
                    "But when I think of Jesus and what he bore for me,\n" +
                    "Then I cry to the Rock of Ages, Hide Thou me.\n" +
                    "(Rock of ages Hide Thou me)\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOh, Rock of ages Hide Thou me\n" +
                    "\t(Blessed Rock of Ages)\n" +
                    "\t(Oh, Blessed Rock) Blessed Rock of Ages\n" +
                    "\t(Hide Thou me) Hide Thou me\n" +
                    "\tThere is no other refuge only thee\n" +
                    "\t(No other refuge) (Only Thee)\n" +
                    "\tSometimes (sometimes) I’m weary (sad and blue)\n" +
                    "\tSo sad and blue\n" +
                    "\tSometimes (sometimes) faint hopes bedim my view\n" +
                    "\t(Bedim my view)\n" +
                    "\tThen I cry to the Rock (Blessed Rock of Ages)\n" +
                    "\tHide Thou me (Rock of Ages, Hide Thou me)\n" +
                    "\n" +

                    "Sometimes it seems I dare not go one step farther on\n" +
                    "And from my heart all courage has disappeared and gone\n" +
                    "But I remember Jesus with all His love for me\n" +
                    "Then I cry to the rock of ages\n" +
                    "Hide Thou me (Rock of Ages, Hide Thou Me)\n" +
                    "\n" +

                    "I have a Friend in Jesus, blessed anchor of my soul\n" +
                    "I feel His presence ever, when stormy billows roll\n" +
                    "And when I think of Jesus and what He bore for me\n" +
                    "Hide Thou me (Rock of Ages, Hide Thou me)\n" ),

            new Eagle( "74. PRAY FOR ME.\n","\tCHORUS:\n" +
                    "\tPray for me, Pray for me\n" +
                    "\tI’m tired of sin. I want to be saved\n" +
                    "\n" +

                    "I went to church one night\n" +
                    "I thought the Lord was calling me\n" +
                    "I went to the altar and prayed\n" +
                    "While everyone stayed and prayed with me\n" +
                    "But I just couldn’t get through something stood in my way\n" +
                    "But on my way home, I told the Lord\n" +
                    "If I die in sin, I’ll go down trusting you\n" +
                    "I’m gonna change my life, even if you won’t save me\n" +
                    "I’m gonna do thy will anyway\n" +
                    "\n" +

                    "I left the church with a troubled heart\n" +
                    "And as I walked along this country road, the moon\n" +
                    "And stars were shining from heavens\n" +
                    "In the stillness I could hear the echoes of shouting\n" +
                    "Souls saved that night on the same bench where I had prayed\n" +
                    "And said, “Lord, I can’t go home without you\n" +
                    "I know that you have saved others, and you can save me too”\n" +
                    "As I stopped by the roadside to kneel down, the sky was darkened\n" +
                    "By a great black cloud that hid the face of the\n" +
                    "Moon. And from out of the cloud came a voice\n" +
                    "Saying, “ye have heard my spirit shall not always strive with man.”\n" +
                    "Have I turned Him away too many times?\n" +
                    "Does He no longer stand at my door and knock?\n" ),

            new Eagle( "75. SHAKE MY MOTHER’S HAND FOR ME.\n","When you reach that golden city,\n" +
                    "Friends and loved ones you will see,\n" +
                    "When the saints come out to meet you,\n" +
                    "Oh, shake my mother’s hand for me.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tShake my mother’s hand and tell her,\n" +
                    "\tHappy may her spirits be,\n" +
                    "\tWhen the saints come out to meet you,\n" +
                    "\tOh, shake my mother’s hand for me.\n" +
                    "\n" +

                    "There are times I often wonder\n" +
                    "How can all these trials be?\n" +
                    "Time can’t keep me here much longer\n" +
                    "Oh, shake my mother’s hand for me.\n" +
                    "\n" +

                    "Over there you’ll meet my savior,\n" +
                    "Many others you will see,\n" +
                    "When you’ve heard a talk with Jesus,\n" +
                    "Oh, shake my mother’s hand for me.\n" ),

            new Eagle( "76. GOD COLORING BOOK.\n","Today as I was walking\n" +
                    "In a field just down the way\n" +
                    "I sat down on a fallen log to pass time away\n" +
                    "And as I looked around me the more that I did look\n" +
                    "The more I realized\n" +
                    "That I am viewing, God coloring book\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI saw a golden ray of light, a silver drop of dew,\n" +
                    "\tSoft white floating clouds, sailing o’er the sky of blue,\n" +
                    "\tA yellow dandelion, a pretty evergreen,\n" +
                    "\tSome red and orange flowers, growing wild along the streams\n" +
                    "\n" +

                    "The grayness in an old man’s hair\n" +
                    "The pink in babies’ cheeks\n" +
                    "The blackness in the stormy sky\n" +
                    "The brown in fallen leaves\n" +
                    "And the multicolored rainbows\n" +
                    "Stretched out across the sky\n" +
                    "And the purple haze of sunset just before the night\n" +
                    "\n" +

                    "Then I turned my face toward the sky\n" +
                    "And pray a silent prayer\n" +
                    "And though God may not speak to me\n" +
                    "I see Him everywhere\n" +
                    "He is all around me\n" +
                    "He is everywhere I look\n" +
                    "And each new day is but a new page\n" +
                    "In God coloring book\n" ),

            new Eagle( "77. ARE YOU BUILDING ON THE ROCK?\n","\tCHORUS:\n" +
                    "\tAre you building on the rock?\n" +
                    "\tAre you building on the rock?\n" +
                    "\tAre you building on the rock?\n" +
                    "\tOr on the sand?\n" +
                    "\n" +

                    "Are you building on a firm foundation?\n" +
                    "Are you building on the sinking sand?\n" +
                    "Do you think you got religion?\n" +
                    "Are you worthy of the master’s Hand?\n" +
                    "\n" +

                    "Have you ever called on Jesus?\n" +
                    "And asked him for His mercy?\n" +
                    "If you ever call on Jesus,\n" +
                    "He’ll hear and answer prayer?\n" ),

            new Eagle( "78. HIGHER THAN THE MOUNTAINS.\n","\tCHORUS:\n" +
                    "\tHigher than the mountains\n" +
                    "\tTaller than the trees\n" +
                    "\tDeeper than the ocean\n" +
                    "\tIs God love for me\n" +
                    "\tIs God love for me\n" +
                    "\n" +

                    "Angels tell the story\n" +
                    "How a savior came\n" +
                    "He is King of glory\n" +
                    "Jesus is His name\n" +
                    "\n" +

                    "He is meek and lowly\n" +
                    "He is free from sin\n" +
                    "Sanctified and holy\n" +
                    "He will come again\n" +
                    "\n" +

                    "To build a holy nation\n" +
                    "A people for His own\n" +
                    "Of every generation\n" +
                    "Chosen in His son\n" +
                    "\n" +

                    "Everyone’s invited\n" +
                    "For all eternity\n" +
                    "God and man United\n" +
                    "Ever more shall be\n" ),

            new Eagle( "79. HEAVENLY BLUE.\n","I was mad when He called you from me\n" +
                    "But you’re happy as you can be\n" +
                    "Cause He saved you from lots of misery\n" +
                    "And with the smile on your face tells me\n" +
                    "You are happy as you can be\n" +
                    "Now I’m going to ask god if He’ll save a place for me\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tMother, sweet precious mother\n" +
                    "\tMother, we love you mother\n" +
                    "\tI saw you with god last night\n" +
                    "\tHe was holding to your hand,\n" +
                    "\tShowing you around in the Promised Land\n" +
                    "\tI saw you with God last night\n" +
                    "\n" +

                    "Gonna write two letters to the heavenly blue\n" +
                    "One to God and one to you\n" +
                    "I want to thank Him for being so nice to you\n" +
                    "I’ve been lonesome since you went away\n" +
                    "But not one tear I shed today\n" +
                    "Cause I know you’re happy up there in the heavenly blue\n" +
                    "\n" +

                    "When I came back home that day\n" +
                    "I was lonesome as I could be\n" +
                    "But I know that He have accepted me\n" +
                    "I been lonesome since you went away\n" +
                    "But not one tear I shed today\n" +
                    "Cause I know you’re happy up there in the heavenly blue\n" ),

            new Eagle( "80. AT THE END OF MY JOURNEY.\n","I know I shall go at the end of my journey\n" +
                    "As onward I go, I rejoice in His love\n" +
                    "I’ll think of His life, on the cross He has given\n" +
                    "Soon I shall go, but not by myself\n" +
                    "\n" +

                    "What wonderful joy at the end of the Journey\n" +
                    "No sickness or death will make our hearts sad\n" +
                    "Sweet peace overflows like a mighty river\n" +
                    "Soon I hall go but not by myself\n" +
                    "\n" +

                    "I know I’ll go, at the end of my journey\n" +
                    "The shadows of over around me enfold\n" +
                    "I’ll take up the cross and follow the savior\n" +
                    "Soon I hall go but not by myself\n" ),

            new Eagle( "81. JUST ONE ROBE WILL DO.\n","When time shall come for my leaving\n" +
                    "When I bid you “A’Dieu”\n" +
                    "Don’t spend your money for flowers\n" +
                    "Just one rose will do\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tBecause I’m going to a beautiful garden\n" +
                    "\tAt last when my work is through\n" +
                    "\tDon’t spend your money on flowers\n" +
                    "\tJust one rose will do\n" +
                    "\n" +

                    "I’d rather\n" +
                    "Have one rose from a garden of a friend\n" +
                    "Than the choicest flowers, when stay on earth shall end\n" +
                    "I’d rather have a kind word, in kindness said to me\n" +
                    "Than flattery when my heart is still and life has ceased to be\n" +
                    "I’d rather have a pleasant smile from someone\n" +

                    "I know is true\n" +
                    "Than tears shed around my casket when I bid\n" +
                    "This ol’ world “A’Dieu”\n" +
                    "Bring me all the flowers today, whether they’re\n" +
                    "Pink or white or red\n" +
                    "I’d rather have one rose now, than a truckload\n" +
                    "When I’m dead Just one rose will do\n" ),

            new Eagle( "82. HELP ME STAND.\n","It’s so easy, Lord, to stumble\n" +
                    "In this old world we’re living in\n" +
                    "How ol’ Satan goes to and fro,\n" +
                    "And there’s so many that are falling\n" +
                    "Yes, they’re falling everyday\n" +
                    "So help me stand, Lord,\n" +
                    "The way you stood long ago\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tHelp me stand by your grace\n" +
                    "\tAnd look the whole world in the face\n" +
                    "\tAnd say you’re mine, where ever I go\n" +
                    "\tAnd when my tempter comes around,\n" +
                    "\tLord, give me strength to turn Him down\n" +
                    "\tSo help me stand, Lord,\n" +
                    "\tThe way you stood long ago\n" +
                    "\n" +

                    "All through the Bible, You had disciples\n" +
                    "That were able, Lord, to stand\n" +
                    "Though their spirits sometimes sank low\n" +
                    "And there were many that were slain\n" +
                    "Because they stood for your name\n" +
                    "So help me stand, Lord,\n" +
                    "The way you stood long ago\n" ),

            new Eagle( "83. CALLING ME.\n","Softly through the shades of evening\n" +
                    "Whispering so tenderly\n" +
                    "I can hear the ascents calling\n" +
                    "Loving voices calling me\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tCalling me from lads eternal\n" +
                    "\tThough their forms no more I see\n" +
                    "\tI shall one day gladly answer\n" +
                    "\tLoving voices calling me\n" +
                    "\n" +

                    "When my life work shall be ended\n" +
                    "And by this my soul is free\n" +
                    "I will answer at the river\n" +
                    "Loving voices calling me\n" +
                    "\n" +

                    "When I leave this world of sorrow\n" +
                    "Enter great eternity\n" +
                    "Through the misty shades I’ll follow\n" +
                    "Loving voices calling me\n" ),

            new Eagle( "84. JUST REHEARSING.\n","We’re just rehearsing\n" +
                    "We’re just rehearsing\n" +
                    "And someday we’ll sing together\n" +
                    "In a band around God’s throne\n" +
                    "This old world cannot reward us\n" +
                    "We are just rehearsing for that singing up home\n" +
                    "\n" +

                    "This old world is nothing but dressing place\n" +
                    "Where we make preparations to spend that endless day\n" +
                    "But til the curtain’s open and it’s that time to sing\n" +
                    "We are just rehearsing songs of praise to the King\n" +
                    "\n" +

                    "When I sing of Jesus, of His saving grace\n" +
                    "I feel His blessed presence, my soul He does embrace\n" +
                    "Sometimes I get so happy, I forget my song\n" +
                    "To know I’ve been invited to that singing up home\n" +
                    "\n" +

                    "We’ll sing the song of Moses with words of sweetest praise\n" +
                    "To God in all His glory, we’ll see Him face to face\n" +
                    "And hear the voices ringing of loved ones who are gone\n" +
                    "We’ll blend our voice with angels in that singing up home\n" ),

            new Eagle( "85. CAST AWAY.\n","If I carry a gospel to a region afar\n" +
                    "To a world that’s going astray\n" +
                    "Don’t let me faint in sight of the gate\n" +
                    "And become just a cast away\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tCastaway, castaway,\n" +
                    "\tTossed like a driftwood on a cold, dark, ocean\n" +
                    "\tCastaway, castaway,\n" +
                    "\tMarked forever just a lonely castaway\n" +
                    "\n" +

                    "Judas walked with Jesus\n" +
                    "Even touching His garment\n" +
                    "Watching the miracles each day\n" +
                    "Yet he sold his master for a price of a slave\n" +
                    "And became just a castaway\n" ),

            new Eagle( "86. SWEETER THAN FLOWERS.\n","Just as far as I can remember,\n" +
                    "She’ll remain the rose of my heart\n" +
                    "Mom took sick along in December\n" +
                    "February brought us broken hearts\n" +
                    "The reason we’ve not called a family reunion\n" +
                    "We knew she wouldn’t be there\n" +
                    "But since we’ve thought it all over, momma,\n" +
                    "We know your spirit is there\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tNo, no I can’t forget the hours\n" +
                    "\tYou’re the onliest one, mom\n" +
                    "\tAnd sweeter than the flowers\n" +
                    "\tNo, no, there’s no need to bother\n" +
                    "\tTo speak of you now\n" +
                    "\tWould only papa\n" +
                    "\tOh, no momma, we’ll never forget you\n" +
                    "\tAnd someday we’ll meet you up there\n" +
                    "\n" +

                    "It looked so good to see us together\n" +
                    "But I had to look after dad\n" +
                    "Oh, momma, when I passed by your coffin,\n" +
                    "I didn’t want to remember you there\n" +
                    "\n" +

                    "They all gathered round\n" +
                    "I looked at their faces\n" +
                    "All heads were bowed mighty low\n" +
                    "But that was one time\n" +
                    "We all had to face it\n" +
                    "Though it hurt us so bad you know\n" ),

            new Eagle( "87. A SOUL WINER FOR JESUS.\n","I want to be a soul winner for Jesus everyday\n" +
                    "He’s done so much for me\n" +
                    "I want to aid the lost sinner to leave his erring way\n" +
                    "And be from bondage free\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tA soul winner for jess (A soul winner for Jesus Christ)\n" +
                    "\tA soul winner for Jesus\n" +
                    "\tOh, let me be each day\n" +
                    "\tA soul winner for Jesus\n" +
                    "\tA soul winner for Jesus\n" +
                    "\tHe’s done so much for me\n" +
                    "\n" +

                    "I want to be a soul winner and bring the lost to Christ\n" +
                    "That they His grace may know\n" +
                    "I want to live for Christ ever and do His blessed will\n" +
                    "Because He loves me\n" +
                    "\n" +

                    "I want to be a soul winner till Jesus calls for me\n" +
                    "To lay my burdens down\n" +
                    "I want to hear Him say, servant, you’ve gathered\n" +
                    "Many sheaves\n" +
                    "Receive a starry crown\n" ),

            new Eagle( "88. I KNOW WHO HOLDS TOMORROW.\n","I don’t know about tomorrow\n" +
                    "I just live from day to day\n" +
                    "I don’t borrow from its sunshine\n" +
                    "For its skies may turn to gray\n" +
                    "I don’t worry for the future\n" +
                    "For I know what jess said\n" +
                    "And today I’ll walk beside Him\n" +
                    "For He knows what is ahead\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tMany things about tomorrow\n" +
                    "\tI don’t try to understand\n" +
                    "\tBut I know who holds tomorrow\n" +
                    "\tAnd I know who holds my hand\n" +
                    "\n" +

                    "Every step is getting brighter as the golden stairs I climb\n" +
                    "Every burden’s getting lighter every cloud is silver lined\n" +
                    "There the sun is always shining\n" +
                    "There no tear will dim the eyes at the ending of the rainbow\n" +
                    "Where the mountains touch the sky\n" +
                    "\n" +

                    "I don’t know about tomorrow it may bring me poverty\n" +
                    "But the one who feeds the sparrows\n" +
                    "Is the one who stands by me\n" +
                    "And the path that be my portion\n" +
                    "May be through the flame or flood\n" +
                    "But His presence goes before me\n" +
                    "And I’m covered with His blood\n" ),

            new Eagle( "89. I’M NOT ALONE.\n","When evening has passed, and the victory’s won\n" +
                    "My travelling days are over and gone\n" +
                    "I’ll be with Jesus in the Glory land\n" +
                    "And join the Angel Band\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI’m not alone, I’m not alone\n" +
                    "\tWith Jesus I’m going home\n" +
                    "\tI’m not alone, I’m not alone\n" +
                    "\tWhile pressing on, I’m not alone\n" +
                    "\n" +

                    "To think of Jesus on the cross\n" +
                    "For you and me he paid the cost\n" +
                    "With pain and grief that he groaned\n" +
                    "And just like Him, I’m not alone\n" ),

            new Eagle( "90. HE’ GOT THE WHOLE WORLD IN HIS HAND.\n","He’s got the whole world in His hand\n" +
                    "He’s got the whole wide world in His hand\n" +
                    "He’s got the whole world in His hand\n" +
                    "He’s got the whole world in His hand\n" +
                    "\n" +

                    "He’s got the little-bitty baby in His hands\n" +
                    "He’s got the little-bitty baby in His hands\n" +
                    "He’s got the little-bitty baby in His hands\n" +
                    "He’s got the whole world in His hand\n" +
                    "\n" +

                    "He’s got you and me, brother, in His hands\n" +
                    "He’s got you and me, brother, in His hands\n" +
                    "He’s got you and me, brother, in His hands\n" +
                    "He’s got the whole world in His hand\n" +
                    "\n" +

                    "He’s got everybody here, in His hands\n" +
                    "He’s got everybody here, in His hands\n" +
                    "He’s got everybody here, in His hands\n" +
                    "He’s got the whole world in His hand\n" ),

            new Eagle( "91. ON THE SEA OF GALILEE.\n","Am I a soldier of the cross,\n" +
                    "A follower of the lamb?\n" +
                    "And shall I fear to own His cause,\n" +
                    "Or blush to speak His Name?\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOn the sea (the sea) of Galilee (of Galilee)\n" +
                    "\tMy Jesus is walking on the sea\n" +
                    "\tOn the sea (the sea) of Galilee (of Galilee)\n" +
                    "\tMy Jesus is walking on the sea\n" +
                    "\n" +

                    "Must I be carried to the skies\n" +
                    "On flowery beds of ease?\n" +
                    "While others fought to win the prize\n" +
                    "And sail through bloody seas?\n" +
                    "\n" +

                    "There shall I bathe my weary soul\n" +
                    "In seas of heavenly rest,\n" +
                    "And not a wave of trouble rolls\n" +
                    "Across my peaceful breast\n" ),

            new Eagle( "92. MY GOD IS REAL.\n","There are some things that I may not know\n" +
                    "There are some places I can’t go\n" +
                    "Oh, but I’m so sure of this one thing,\n" +
                    "That God is real for I can feel Him in my soul\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tMy God is real, real in my soul\n" +
                    "\tMy God is real for He has washed and made me whole\n" +
                    "\tHis love for me is like pure gold\n" +
                    "\tMy God is real for I can feel Him in my soul\n" +
                    "\n" +

                    "I cannot tell just how you felt\n" +
                    "When Jesus washed your sins away\n" +
                    "Oh, but since that day, yes that hour\n" +
                    "God has been real, for I can feel His Holy Power\n" ),

            new Eagle( "93. GOSPEL TRAIN.\n","There’s a train that’s headed for the land of glory\n" +
                    "And you’ll want to catch it when it comes your way\n" +
                    "It is powered by the mighty gospel story\n" +
                    "And will take you to a land of brighter day\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOh, hear the whistle blowing\n" +
                    "\tAs you’re crossing over Jordan’s shore\n" +
                    "\tTo the Promised Land we’re going\n" +
                    "\tJump on board and don’t be late\n" +
                    "\tWe are headed for the pearly gates\n" +
                    "\tWe’ll ride that gospel train forever more\n" +
                    "\n" +

                    "You will need a ticket and a reservation\n" +
                    "Come get in the train and follow His command\n" +
                    "You will surely reach your final destination\n" +
                    "When you trust and put your life in Jesus Hand\n" +
                    "\n" +

                    "There’s a map that tells the rout the train is taking\n" +
                    "And you’ll want to keep it with you as you ride\n" +
                    "It will steer in the choices you are making\n" +
                    "If you’ll read and let God Book be your guide\n" ),

            new Eagle( "94. IN MY FATHER’S HOUSE ARE MANY MANSIONS.\n" ,"In my Father’s house are many mansions,\n" +
                    "If it were not true He would have told me so,\n" +
                    "He has gone away to live in that bright city,\n" +
                    "He’s preparing me a mansion there I know.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tDo not shun the Saviour’s love from up in Glory,\n" +
                    "\tOr you won’t be there to sing the gospel story,\n" +
                    "\tIn my Father’s house are many mansions,\n" +
                    "\tIf you’re true then to this land you’ll surely go.\n" +
                    "\n" +

                    "Jesus died upon the cross to bear my sorrow,\n" +
                    "Freely died that souls like you might have new life,\n" +
                    "But I know there soon will come a bright tomorrow,\n" +
                    "When the world will all be free from sin and strife,\n" +
                    "\n" +

                    "When your friends have turned you down and left you lonely,\n" +
                    "In this world you’re all alone and oh so blue,\n" +
                    "Turn your thoughts away from sin to Jesus only,\n" +
                    "A new life and friendship sweet He’ll give to you.\n"),

            new Eagle( "95. THE FIRST STEP TO HEAVEN.\n","Wake up, O sinner,\n" +
                    "You are facing the darkness of death\n" +
                    "Each moment could be the moment you draw your last breath\n" +
                    "And the weight of your fears are the shackles that keep you enslaved\n" +
                    "But the blood of the lamb is the one way to by-pass the grave\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThe first step to heaven\n" +
                    "\tIs knowing you’re lost\n" +
                    "\tThe highway to glory is the way up the cross\n" +
                    "\tYou can hand Him your burdens, the moment you see\n" +
                    "\tThe first step to heaven\n" +
                    "\tIs down on your knees\n" +
                    "\n" +

                    "To all you believers who have answered the good  Shepherd’s call\n" +
                    "There’s a chasm of darkness with the light that can save one and all\n" +
                    "Not a soul crosses Jordan on the strength of their muddy old deeds\n" +
                    "That mansion up yonder is reserved for those who believe\n" ),

            new Eagle( "96. JUST OVER IN THE GLORY LAND.\n","I’ve a home prepared where the saints abide\n" +
                    "Just over in the glory-land\n" +
                    "And I long to be by my savior’s side\n" +
                    "Just over in the glory-land\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tJust over in the glory-land\n" +
                    "\t(Just over, over in the glory-land)\n" +
                    "\tI’ll join the happy angel band\n" +
                    "\t(I’ll join, yes, join the happy angel band)\n" +
                    "\tJust over in the glory-land\n" +
                    "\t(Just over, over in the glory-land)\n" +
                    "\tThere with (yes, with) the mighty host I’ll stand\n" +
                    "\tJust over in the glory-land\n" +
                    "\n" +

                    "I am on my way to those mansions fair\n" +
                    "Just over in the glory-land\n" +
                    "There to sing God’s praise, and His glory share\n" +
                    "Just over in the glory-land\n" +
                    "\n" +

                    "What a joyful thought that my Lord I’ll see\n" +
                    "Just over in the glory-land\n" +
                    "And with kindred saved, there forever be\n" +
                    "Just over in the glory-land\n" +
                    "\n" +

                    "With the blood washed throng I will shout and sing\n" +
                    "Just over in the glory-land\n" +
                    "Glad Hosannas to Christ, the Lord and King,\n" +
                    "Just over in the glory-land\n" ),

            new Eagle( "97. THE LOVE OF GOD.\n","I tried and tried to think of some good deeds that I have done\n" +
                    "That would give to me the right to claim a kinship to God son\n" +
                    "Could it have been because I tried in every way to please?\n" +
                    "Could it have been because I spent sometimes down on my knees?\n" +
                    "\n" +

                    "Could it have been because my heart was often touché by pain?\n" +
                    "Could it have been because I’ve often witnessed in His name?\n" +
                    "Or could it be that in the past some precious souls I’ve won\n" +
                    "But I searched my heart and realized it’s nothing I have done\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThe love of God defies all understanding of the mind\n" +
                    "\tHe chose to walk up Calvary Hill and died for all man kind\n" +
                    "\tThose ugly scars He bored for me while hanging on the cross\n" +
                    "\tWas the price of my redemption\n" +
                    "\tAnd He did it all for me\n" +
                    "\n" +

                    "I tried to lend a helping hand to someone on life’s road\n" +
                    "Shared a simple cup of water with the tired and thirsty souls\n" +
                    "I tried to be to those I meet as gentle as a dove\n" +
                    "But I’ve never done a single deed that’s worthy of His Love\n" ),

            new Eagle( "98. JUST FOR ME.\n","When the ma of Galilee\n" +
                    "Hung upon a cruel tree\n" +
                    "He was dying for sinners like me\n" +
                    "As the blood was dripping down,\n" +
                    "On the cross and on the ground,\n" +
                    "There was one drop He shed just for me\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tJust for me and the sin of my soul\n" +
                    "\tJust to cleanse me and make me free and whole\n" +
                    "\tAs the blood was dripping down,\n" +
                    "\tOn the cross and on the ground,\n" +
                    "\tThere was one drop He shed just for me\n" +
                    "\n" +

                    "When they pierced His precious side\n" +
                    "“Oh, forgive them now!” He cried\n" +
                    "There was pardon extended to me\n" +
                    "And both blood and water came\n" +
                    "Glory to His precious Name\n" +
                    "There was one drop He shed just for me\n" ),

            new Eagle( "99. CUP OF LONELINESS.\n","I see Christian pilgrim\n" +
                    "So redeemed from sin\n" +
                    "Called out of darkness\n" +
                    "A new life to begin\n" +
                    "Were you ever in the valley,\n" +
                    "Where the way is dark and dim?\n" +
                    "Did you ever drink the cup of loneliness with Him?\n" +
                    "\n" +

                    "Did you ever have them laugh at you?\n" +
                    "And say it was a fake\n" +
                    "The stand that you so boldly\n" +
                    "For the Lord did take?\n" +
                    "Did they ever mock at you\n" +
                    "And laugh in ways quite grim?\n" +
                    "Did you ever drink the cup of loneliness with Him?\n" +
                    "\n" +

                    "Did you ever try to preach,\n" +
                    "Then hold fast and pray?\n" +
                    "And even when you did it,\n" +
                    "There did not seem a way\n" +
                    "And you lost courage\n" +
                    "Then lost all your vim\n" +
                    "Did you ever drink the cup of loneliness with Him?\n" +
                    "\n" +

                    "Ah, my friends, tis bitter-sweet,\n" +
                    "While here on earthly sod\n" +
                    "To follow in the footsteps,\n" +
                    "That our dear savior trod\n" +
                    "To suffer with the savior\n" +
                    "And when the way is dark and dim,\n" +
                    "Did you ever drink the cup of loneliness with Him?\n" ),

            new Eagle( "100. WHERE NO ONE STANDS ALONE.\n","Once I stood in the night\n" +
                    "With my head bowed low\n" +
                    "In the darkness as black as could be\n" +
                    "And my heartfelt alone\n" +
                    "And I cried, “Oh, Lord,\n" +
                    "Don’t hide your face from me.”\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tHold my hand, all the way,\n" +
                    "\tEvery hour, every day\n" +
                    "\tFrom here through the great unknown\n" +
                    "\tTake my hand, let me stand,\n" +
                    "\tWhere no one stands alone\n" +
                    "\n" +

                    "Like a King I may live in a palace tall\n" +
                    "With great riches to call my own\n" +
                    "But I don’t know a thing in this whole wide world\n" +
                    "That’s worse than being alone\n" ),

            new Eagle( "101. I’D RATHER LIVE BY THE SIDE OF THE ROAD.\n","There are some people who would rather live in splendor\n" +
                    "And brag about their silver and their gold\n" +
                    "People who would trade God’s promise\n" +
                    "For earth’s glory to hold\n" +
                    "There are people who would rather live in mansions\n" +
                    "People who would rather live abroad\n" +
                    "But I’d rather have a little log cabin by the side of the road\n" +

                    "\tCHORUS:\n" +
                    "\tI’d rather live by the side of the road\n" +
                    "\tAnd try to point souls to the blest abode\n" +
                    "\tThan to be a king or a millionaire\n" +
                    "\tAnd live in mansions in bright array\n" +
                    "\tI’d rather do a neighborly deed\n" +
                    "\tFor a traveler here or a friend in need\n" +
                    "\tI’d rather live by the side of the road\n" +
                    "\tAnd help some pilgrim along life’s way\n" +
                    "\n" +

                    "Every day I want to be a friendly neighbor\n" +
                    "And try to help somebody on the way\n" +
                    "I want my life to tell for Jesus every hour of the day\n" +
                    "Take way my every thought of fame and fortune\n" +
                    "Take away my every thought of rich abode\n" +
                    "And leave me just a little log cabin by the side of the road\n" +
                    "\n" +

                    "I would rather have a cabin by the roadside,\n" +
                    "Where the pilgrim of man is passing by\n" +
                    "And help to point souls to Jesus and that city on high\n" +
                    "Every day I want to help to scatter roses\n" +
                    "Every night I want my lamp to shine abroad\n" +
                    "With a welcome from my little bay window\n" +
                    "By the side of the road\n" ),

            new Eagle(  "102. ONLY GOD.\n","Here each day, we daily travel\n" +
                    "And as on the way we go\n" +
                    "There are things beyond our vision\n" +
                    "There are things we do not know\n" +
                    "God has given all completeness\n" +
                    "And he knows the reason why\n" +
                    "His great plan was so decided\n" +
                    "Why we live ad why we die\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOnly God can make a rainbow\n" +
                    "\tOnly He makes altars to shine\n" +
                    "\tBy His power, the dew drops glisten\n" +
                    "\tThese are gifts of love and mercy divine\n" +
                    "\tOnly God can give full pardon\n" +
                    "\tCleanse your soul and make you free\n" +
                    "\tThe door of heaven He has opened\n" +
                    "\tOnly God could save a sinner like me\n" +
                    "\n" +

                    "In the land of joy awaiting\n" +
                    "Over on the other side\n" +
                    "God has built for us bright mansions\n" +
                    "Where no troubles there betide\n" +
                    "Heaven stars up there will glisten\n" +
                    "And the vesper breezes blow\n" +
                    "Only God can make the heavens\n" +
                    "None but He such love can show\n"),

            new Eagle( "103. HOLY GHOST REVIVAL.\n","In a quiet congregation on a Sunday afternoon,\n" +
                    "The preacher in the pulpit said, “Our Lord is coming soon\n" +
                    "But our choir no longer sings and our saints no longer praise\n" +
                    "And how can we expect to make it through these days?”\n" +
                    "\n" +

                    "But remember years ago, in those old camp meeting days\n" +
                    "How we tarried at the altar; we’d lift up Holy praise\n" +
                    "And our tears of joy kept the altars clean\n" +
                    "We’d shout the victory\n" +
                    "In that Holy Ghost revival, that we need\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThat Holy Ghost revival is what we need today\n" +
                    "\tIt’ll heal the sick, raise the dead, wash all our sin away\n" +
                    "\tSend the fire, the holy fire, Lord, let it start with me\n" +
                    "\tThat Holy Ghost revival that we need\n" +
                    "\n" +

                    "One by one they bowed their heads\n" +
                    "And the tears began to flow\n" +
                    "As the Holy Ghost conviction swept over every soul\n" +
                    "It started in the back, like a whisper in the wind\n" +
                    "That moved up to the front row\n" +
                    "They could feel it once again\n" +
                    "\n" +

                    "Well, grandma started singing, someone began to shout\n" +
                    "Heaven opened up and tongues of fire danced about\n" +
                    "Like on the day of Pentecost; I’m sure they all agree\n" +
                    "That the Holy Ghost Revival is what we need\n" ),

            new Eagle( "104. READ ROMANS 10:9.\n","Are you feeling sad and blue?\n" +
                    "Wishing for a friend so true?\n" +
                    "Do you feel that you’ve been left so far behind?\n" +
                    "Then a message I will bring\n" +
                    "Gladness to your soul I’ll sing\n" +
                    "Read Romans 10:9\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThat if thou shall confess The Lord Jesus,\n" +
                    "\tAnd believe that God has raised Him so devein,\n" +
                    "\tYou will find the way more clear\n" +
                    "\tYou will find a friend so dear\n" +
                    "\tRead Romans 10:9\n" +
                    "\n" +

                    "There’s no use to travel on this cruel world alone\n" +
                    "When you have a friend so helpful and kind\n" +
                    "Tell Him of every care, you will always find Him there\n" +
                    "Read Romans 10:9\n" +
                    "\n" +

                    "All the words are oh, so true\n" +
                    "They will surely help you through\n" +
                    "Just believe them and true happiness you’ll find\n" +
                    "Then you’ll shout and pray\n" +
                    "And tell others every day\n" +
                    "Read Romans 10:9\n" ),

            new Eagle( "105. TOUCHING JESUS.\n","A woman tried many physicians,\n" +
                    "Yet grew worse, so to Jesus she came\n" +
                    "And when the crowd tried to restrain her\n" +
                    "She whispered these words through her pain\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tTouching Jesus is all that matters\n" +
                    "\tAnd my life will never be the same\n" +
                    "\tThere is only one way to touch Him\n" +
                    "\tThat’s believe when you call on His name\n" +
                    "\n" +

                    "I was bound when I knelt at that old altar,\n" +
                    "But they said Jesus could meet every need\n" +
                    "And when this prisoner finally touched Jesus\n" +
                    "He set me free, Praise the Lord, free indeed!\n" ),

            new Eagle( "106. JESUS’ BLOOD.\n","Burdened soul, turn not away\n" +
                    "From the strong and mighty power\n" +
                    "Oh, take time to kneel and pray\n" +
                    "Jesus’ blood has never lost its power\n" +
                    "\n" +

                    "Jesus’ blood can cleanse each stain\n" +
                    "Though in sin you’ve wondered far\n" +
                    "Jesus blood can ease the pain\n" +
                    "Jesus’ blood has never lost its power\n" +
                    "\n" +

                    "Though your sins as scarlet be\n" +
                    "Plunge beneath the cleansing shower\n" +
                    "God will surely set you free\n" +
                    "Jesus’ blood has never lost its power\n" +
                    "\n" +

                    "I am His and He is mine\n" +
                    "Every day and every hour\n" +
                    "I am the branch and He is the vine\n" +
                    "Jesus’ blood has never lost its power\n" ),

            new Eagle( "107. LOVE FOUND A PARDON.\n","Tossed by the winds and the waves of life\n" +
                    "Sailing alone on life’s sea\n" +
                    "Sin had me bound in confusion\n" +
                    "But love found a pardon for me\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tLove, love, God mighty love\n" +
                    "\tLove beyond a pardon for me\n" +
                    "\tLove, love, God mighty love\n" +
                    "\tLove found a pardon for me\n" +
                    "\n" +

                    "Love sent the savior from heaven\n" +
                    "Love beyond all degree\n" +
                    "Love paid the debt of atonement\n" +
                    "And love found a pardon for me\n" +
                    "\n" +

                    "Love so amazing and love so free\n" +
                    "Love found a pardon for me\n" +
                    "Love so amazing and love so free\n" +
                    "Love found a pardon for me\n" ),

            new Eagle( "108. THERE’S A HAND WRITING ON THE WALL.\n","Belshazzar was a mighty king\n" +
                    "And the vessels from God’s house he had them;\n" +
                    "Never dreaming that same night that He would fall,\n" +
                    "But a hand came writing on the wall\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThere’s a hand writing on the wall,\n" +
                    "\tEvery time you turn away from Jesus call\n" +
                    "\tAnd it’s writing down your fate\n" +
                    "\tIf you answer Him too late\n" +
                    "\tThere’s a hand writing on the wall\n" +
                    "\n" +

                    "Don’t you know it’s dangerous to say?\n" +
                    "“I want Jesus a more convenient day?”\n" +
                    "For today is God’s salvation day to all\n" +
                    "There’s a hand writing on the wall\n" +
                    "\n" +

                    "Everyday there’s souls that’s passing on,\n" +
                    "On to reap whatever they have sewn\n" +
                    "So take heed lest you should be the next to fall\n" +
                    "There’s a hand writing on the wall\n" ),

            new Eagle( "109. I’VE FOUND A HIDING PLACE.\n","A-down that lonesome road\n" +
                    "to heaven’s blest abode,\n" +
                    "for many years I was burdened with care\n" +
                    "So soft the lightnings flashed\n" +
                    "And raging billows dashed\n" +
                    "My sorrow then was so heavy to bear\n" +
                    "But since my Jesus came,\n" +
                    "O praise His Holy Name\n" +
                    "He sheds the light of His wonderful grace\n" +
                    "And every night and day\n" +
                    "To Him I steal away,\n" +
                    "I’ve found a blessed hiding place\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI’ve found a hiding place, A blessed hiding place\n" +
                    "\tI said a hiding place A blessed hiding place\n" +
                    "\tThere’s glory in my soul The Hallelujahs roll\n" +
                    "\tFor since my Jesus came I’m under His control\n" +
                    "\tHe keeps me night and day He answers when I pray\n" +
                    "\tAnd from the raging storms To Him I steal away\n" +
                    "\tI bear no tempter’s knock I feel no tempter’s shock\n" +
                    "\tFor in the solid rock I’ve found a hiding place,\n" +
                    "\n" +

                    "Just like those wandering Jews, I had no place to choose,\n" +
                    "Each day I had to keep travelling on\n" +
                    "But now I’ve found the way that leads to endless day\n" +
                    "No more in darkness I wander alone\n" +
                    "When Satan would alarm if I fly to God’s strong arm\n" +
                    "And hideaway in, His loving embrace\n" +
                    "For in the solid rock, the blessed solid rock\n" +
                    "I’ve found a blessed hiding place\n" ),


            new Eagle( "110. THE GLORY LAND WAY.\n","I’m in the way, the bright and shining way\n" +
                    "I’m in the glory land way\n" +
                    "Telling the world that Jesus saves to day\n" +
                    "I’m in the glory land way\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI’m in the glory land way\n" +
                    "\tI’m in the glory land way\n" +
                    "\tHeaven is nearer and the way growth clearer\n" +
                    "\tFor I’m in the glory land way\n" +
                    "\n" +

                    "Onward I go, rejoicing in His love\n" +
                    "I’m in the glory land way\n" +
                    "Soon I shall see Him in that home above\n" +
                    "Yes, I’m in the glory land way\n" +
                    "\n" +

                    "List to the call, the gospel call today\n" +
                    "Get in the glory land way\n" +
                    "Wanderer, come home, oh hasten to obey\n" +
                    "And get in the glory land way\n" ),

            new Eagle( "111. TATTLER’S WAGON.\n","Once I had a tattler’s wagon. Which behind me I did pull\n" +
                    "As fast as I could empty it some friends would fill it full\n" +
                    "By and by I got so busy. There was little else to do\n" +
                    "But still I’d meet the saints and sing\n" +
                    "“I’m going through, Jesus, I’m going through.”\n" +
                    "\n" +

                    "Well, I was going through. And tattling as I went\n" +
                    "But going through like that, you know,\n" +
                    "Isn’t worth a cent I’d talked about my neighbors\n" +
                    "They’d give me tattles too and then we’d go to church and sing\n" +
                    "“I believe Jesus saves, and His blood washes whiter than snow.”\n" +
                    "\n" +

                    "If someone testifies and prays, some good sister doubts\n" +
                    "And others have no confidence when a certain party shouts\n" +
                    "If some one hears a little lie, for some good reasons told\n" +
                    "He loads his wagon up and sings “when we all see Jesus,\n" +
                    "We’ll sing and shout the victory.”\n" +
                    "\n" +

                    "We’d back our wagons up and get another load\n" +
                    "And just as soon as we could go We’d start on tattler’s road\n" +
                    "And when we met a passerby, We’d stop and fret stew\n" +
                    "And dump the poison out and sing\n" +
                    "“Makes me love everybody, makes me love everybody,\n" +
                    "Makes me love everybody, and that’s good enough for me.”\n" +
                    "\n" +

                    "Oh, the thing that we should do is smash those wagons now\n" +
                    "And each one bridle his own tongue Stop this thing somehow\n" +
                    "Let’s stop this awful tattling let’s bring it to an end\n" +
                    "Then we can meet the saints and sing\n" +
                    "“In the sweet by and by, we shall\n" +
                    "Meet on that beautiful shore.”\n" ),

            new Eagle( "112. KNEEL AT THE CROSS.\n","Kneel at the cross\n" +
                    "Christ will meet you there\n" +
                    "Come while He waits for you\n" +
                    "List to His voice\n" +
                    "Leave with Him your care\n" +
                    "And begin life anew\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI’m in the glory land way\n" +
                    "\t(I’m in the glory land way) (I’m in the glory land way)\n" +
                    "\tLeave every care\n" +
                    "\t(I’m in the glory land way) (I’m in the glory land way)\n" +
                    "\tI’m in the glory land way\n" +
                    "\t(I’m in the glory land way) (I’m in the glory land way)\n" +
                    "\tJesus will meet you there\n" +
                    "\n" +

                    "Kneel at the cross\n" +
                    "Give your idols up\n" +
                    "Look unto realms above\n" +
                    "Turn not away\n" +
                    "To life’s sparkling cup\n" +
                    "Trust only in His love\n" +
                    "\n" +

                    "Kneel at the cross\n" +
                    "There are is room for all\n" +
                    "Who would His glory share?\n" +
                    "Bliss there awaits,\n" +
                    "Harm can ne’er befall\n" +
                    "Those who are anchored there\n" ),

            new Eagle( "113. AS AN EAGLE STIRS HER NEST.\n","As an eagle stirs her nest,\n" +
                    "Oh, God, stir up your people,\n" +
                    "Til we stir the whole world for thee\n" +
                    "We’ve not done our every best\n" +
                    "Oh, God, stir up your people\n" +
                    "Til the world through the gospel is free\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tWe must run and not be weary\n" +
                    "\tWe must hasten to the lost\n" +
                    "\tTo the whole world we must carry\n" +
                    "\tTrue love, Jesus, and His cross\n" +
                    "\n" +

                    "As an eagle stirs her nest\n" +
                    "Oh, God, stir up your people\n" +
                    "Til we stir the whole world for thee\n" ),

            new Eagle( "114. OLD DOC BROWN.\n","He was just an old country doctor In a little Georgia town\n" +
                    "Fame and fortune had passed him by, But we never saw him frown\n" +
                    "As day by day in his kindly way, He served us one and all\n" +
                    "Many a patient forgot to pay, Although' doc's fees were small\n" + "\n" +

                    "But Old Doc Brown didn't seem to mind, He didn't even send out bills\n" +
                    "His only ambition was to find, It seems, sure cures for aches and ills\n" +
                    "Why nearly half the folks in my home town, Yes, I'm one of them too\n" +
                    "Were ushered in by Old Doc Brown, When we made our first debut\n" +  "\n" +

                    "Tho' he needed his dimes and there were times, That he'd receive a fee\n" +
                    "He'd pass it on to some poor soul, That needed it worse than he\n" +
                    "But when the depression hit our town, And drained each meager purse\n" +
                    "The scanty income of Old Doc Brown, Just went from bad to worse\n" +  "\n" +

                    "He had to sell all of his furniture, Why, he couldn't even pay his office rent\n" +
                    "So to a dusty room over a Livery stable, Doc Brown and his practice went\n" +
                    "On the hitchin' post at the curb below, To advertise his wares\n" +
                    "He nailed a little sign that read, 'Doc Brown has moved upstairs'\n" + "\n" +

                    "There he kept on helpin' folks get well, And his heart was just pure gold\n" +
                    "But anyone with eyes could see, That Doc was gettin' old\n" +
                    "And then one day he didn't even answer, When they knocked upon his door\n" +
                    "Old Doc Brown was a-lyin' down, But his soul - was no more\n" +  "\n" +

                    "They found him there in an old black suit, And on his face was a smile of content\n" +
                    "But all the money they could find on him, Was a quarter and a copper cent\n" +
                    "So they opened up his ledger, And what they saw gave their hearts a pull\n" +
                    "Beside each debtor's name, Old Doc had (*writ) these words, 'Paid in full'\n" + "\n" +

                    "It looked like the potter's field for Doc, That caused us some alarm\n" +
                    "'Til someone 'membered the family graveyard, Out on the Simmons farm\n" +
                    "Old doc had brought six of their kids, And Simmons was a grateful cuss\n" +
                    "He said, Doc's been like one of the family, So, you can let him sleep with us\n" +  "\n" +

                    "Old Doc should have had a funeral, Fine enough for a king\n" +
                    "It's a ghastly joke that our town was broke, And no one could give a thing\n" +
                    "'Cept Jones, the undertaker, He did mighty well\n" +
                    "Donatin' an old iron casket, That he'd never been able to sell\n" +   "\n" +

                    "And the funeral procession, it wasn't much, For grace and pomp and style\n" +
                    "But those wagon loads of mourners, They stretched out for more than a mile\n" +
                    "And we breathed a prayer as we laid him there, To rest beneath the sod\n" +
                    "This man who'd earned the right, To be on speaking terms with God\n" +   "\n" +

                    "His grave was covered with flowers, But not from the floral shops\n" +
                    "Just roses and things from folks' garden, And one or two dandelion pots\n" +
                    "For the depression had hit our little town hard, And each man carried a load\n" +
                    "So some just picked the wildflowers, As they passed along the road\n" +     "\n" +

                    "We wanted to give him a monument, Kinda figured we owed him one\n" +
                    "'Cause he'd made our town a better place, For all the good he'd done\n" +
                    "But monuments cost money, So, we did the best we could\n" +
                    "And on his grave we gently placed, A monument - of wood\n" +   "\n" +


                    "We pulled up that old hitchin' post, Where Doc had nailed his sign\n" +
                    "And we painted it white and to all of us, It certainly did look fine\n" +
                    "Now the rains and snow has washed away, Our white trimmings of paint\n" +
                    "And there ain't nothin' left but Doc's own sign, And that is gettin' faint\n" +   "\n" +

                    "Still, when southern breezes and flickering stars, Caress our sleeping town\n" +
                    "And the pale moon shines through Kentucky pines, On the grave of Old Doc Brown\n" +
                    "You can still see that old hitchin' post, As if an answer to our prayers\n" +
                    "Mutely telling the whole wide world, Doc Brown has moved up stairs\n" ),

            new Eagle( "115. LED OUT OF BONDAGE.\n","God promised to lead His children out of bondage\n" +
                    "He said He'd free them from Pharaoh's evil hand\n" +
                    "He said He'd guide and protect them on their journey\n" +
                    "And lead them to the promised land\n" + "\n" +

                    "God's children were slaves in Egypt land\n" +
                    "So God took Moses by the hand\n" +
                    "He said Moses tell old Pharaoh to set 'em free\n" +
                    "But Moses wanted a way to get out\n" +
                    "Cause in his mind he's beginning to doubt\n" +
                    "He said Lord old Pharaoh he ain't a gonna listen to me\n" + "\n" +


                    "Now the Lord said son throw down that rod\n" +
                    "Old Moses did and he cried to God\n" +
                    "Cause it turned to a snake as evil and wicked as sin\n" +
                    "Then he cried again with an awful wail\n" +
                    "The Lord said seize him by the tail\n" +
                    "Old Moses did and it turned to a rod again\n" +
                    "\n" +

                    "Well the Lord said Moses I've got power\n" +
                    "An I'll be with you every hour\n" +
                    "Said go tell Pharaoh to set my children free\n" +
                    "Well Moses did but the Lord helped out\n" +
                    "He sent a plague to the land about\n" +
                    "So old Pharaoh told him to go and let him be\n" + "\n" +


                    "Well they started out with a cloud that day\n" +
                    "And a fire by night to lead the way\n" +
                    "But old Pharaoh suddenly decided to change his mind\n" +
                    "So he gathered together his soldier band\n" +
                    "Got all them chariots throughout the land\n" +
                    "Said I'll let them Israelites go some other time\n" +
                    "\n" +


                    "Well they came to the banks of the old Red Sea\n" +
                    "Turned to Moses and started to plea\n" +
                    "And Moses fell on his knees an there is the sand\n" +
                    "The Lord told Moses trust in God\n" +
                    "All ya gotta do is just raise that rod\n" +
                    "And over these mighty waters stretch your hand\n" + "\n" +

                    "Well Moses followed the Lord's command\n" +
                    "The waters parted and there is the sand\n" +
                    "They saw a path that led to the other shore\n" +
                    "Well the ground was dry and they passed on through\n" +
                    "And old Pharaoh's army thought they would to\n" +
                    "But the waters fell ain't never been seen no more\n" ),

            new Eagle( "116. MOTHER PRAYS LOUD IN HER SLEEP.\n","\tCHORUS:\n" +
                    "\tMy mother prays so loud in her sleep\n" +
                    "\tShe wakes all the neighbors with her sweet creams\n" +
                    "\tBut no one complains, their hearts feel at ease,\n" +
                    "\tWhen they hear mother praying so loud, loud, loud\n" +
                    "\tWhen they hear mother praying so loud in her sleep\n" +
                    "\n" +

                    "I come home at night and the first thing I hear\n" +
                    "Is the sweet tender voice, ringing so clear\n" +
                    "She’s thanking The Lord for all He has done\n" +
                    "And praying that God will save everyone\n" +
                    "\n" +

                    "When mother is praying so loud in her sleep\n" +
                    "Upon her face there’s a smile so sweet\n" +
                    "There’s a picture I wish that the whole world could see\n" +
                    "When mother is praying so loud in her bed\n" ),

            new Eagle( "117. CONSIDER THE LILIES.\n","Consider the Lilies, they don’t toil nor spin\n" +
                    "And there’s not a king with more splendor than them\n" +
                    "Consider the sparrows, they don’t plant nor sew\n" +
                    "But they’re fed by the master who watches them grow\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tAnd we have a heavenly Father above\n" +
                    "\tWith eyes full of mercy and His heart full of love\n" +
                    "\tAnd He really cares when your head bowed low\n" +
                    "\tConsider the Lilies and then you will know\n" +
                    "\n" +

                    "May I introduce you to this friend of mine?\n" +
                    "Who hangs up the stars and tells the sun when to shine\n" +
                    "Kisses the flowers every morning with the dew\n" +
                    "He’s not too busy to care about you\n" ),

            new Eagle( "118. WORKING ON THE ROAD.\n", "\tCHORUS:\n" + "I’m working on a road (I’m working on a road)\n" +
                    "That leads to glory (That leads to glory)\n" +
                    "My savior’s hand (My savior’s hand)\n" +
                    "I’m building my hopes (I’m building my hopes)\n" +
                    "On things eternal (On things eternal)\n" +
                    "I’m working on a road (I’m working on a road)\n" +
                    "To glory land\n" +
                    "\n" +

                    "Each day I get so lonely while living here below\n" +
                    "My Saviour’s is waiting patiently; I’m planning now to go\n" +
                    "I want a firm foundation that’s built with God’s own Hand\n" +
                    "So now I’ve started building a road to glory land\n" +
                    "\n" +

                    "Oh listen to me, don’t you want to go?\n" +
                    "You know we have no promise of living here below\n" +
                    "You know He suffered for our sin and died upon the cross\n" +
                    "For all who did believe on Him, their souls would not be lost\n" +
                    "\n" +

                    "And when this road is finished, I want to travel on\n" +
                    "I can hear the angels singing up there around the throne\n" +
                    "I want to see my mother and take her by the hand\n" +
                    "As soon as I have finished the road to glory land\n" ),


            new Eagle( "119. SEND THE LIGHT.\n","Theirs is a call comes ringing o’er the restless wave\n" +
                    "“Send the light! Send the light!”\n" +
                    "There are souls to rescue, there are souls to save\n" +
                    "“Send the light! Send the light!”\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tSend the light the! The blessed gospel light\n" +
                    "\tLet it shine from shore to shore\n" +
                    "\tSend the light! The blessed gospel light\n" +
                    "\tLet it shine forevermore\n" +
                    "\n" +

                    "Let us pray that grace may everywhere abound\n" +
                    "“Send the light! Send the light!”\n" +
                    "And a Christ-like spirit everywhere be found\n" +
                    "“Send the light! Send the light!”\n" +
                    "\n" +

                    "Let us not grow weary in the work of love\n" +
                    "“Send the light! Send the light!”\n" +
                    "Let us gather jewels for a crown above\n" +
                    "“Send the light! Send the light!”\n" ),

            new Eagle( "120. SATAN AND THE SAINT.\n","“I have the world to offer you.”\n" +
                    "Yes, you have the world to hold\n" +
                    "Til the day when God declares\n" +
                    "Time on earth shall be no more\n" +
                    "Fire and brimstone shall rain down\n" +
                    "And melt it like the snow\n" +
                    "What will you have to offer then\n" +
                    "To a dying soul?\n" +
                    "\n" +

                    "“But think of all you’re giving up.”\n" +
                    "I’m giving up the chance to die\n" +
                    "Spend my life in hell, burning in a lake of fire\n" +
                    "I thank God He’s made away. That I might escape\n" +
                    "By living grace of God I shall see His face\n" +
                    " \n" +

                    "“You don’t sin, you are good enough.”\n" +
                    "There’s not a just man upon the earth\n" +
                    "That doeth good and sinneth not\n" +
                    "All we like sheep have gone astray\n" +
                    "We have turned everyone to his own way\n" +
                    "And the Lord has laid on Him\n" +
                    "The iniquity of us all\n" +
                    "\n" +

                    "“But life will be too dull for you.”\n" +
                    "Everything you have offered me\n" +
                    "Don’t mean nothing to my heart\n" +
                    "Far from sin I’ve been set free\n" +
                    "Praise the Lord, I’m going home, ever to rejoice\n" +
                    "Take your world and go behind\n" +
                    "I have found a peace of mind\n" +
                    "Everlasting joy is mine Jesus is my choice\n" ),

            new Eagle( "121. THERE’S A DIFFERENCE IN RELIGION AND SALVATION.\n","Now Jesus said to Nicodemus\n" +
                    "“Except a man be born again,\n" +
                    "He cannot enter in the kingdom.”\n" +
                    "Are you sure about your soul my friend?\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThere’s a difference in religion and salvation\n" +
                    "\tFor religion can be based on hate or love\n" +
                    "\tMost everybody has religion\n" +
                    "\tBut a Christian has salvation,\n" +
                    "\tAnd salvation comes from God above\n" +
                    "\n" +

                    "It’ not everyone that saith, “Lord, Lord.”\n" +
                    "Our savior said would enter\n" +
                    "But those who keep our God’s commandments\n" +
                    "Take their cross and endure to the end\n" +
                    "\n" +

                    "Come let us draw ever nearer\n" +
                    "And our every weight lay aside\n" +
                    "With the things that so easily beset us\n" +
                    "Run the race without peace, without pride\n" ),

            new Eagle( "122. DANIEL PRAYED.\n","I heard about a man one day\n" +
                    "Who wasted not His time away\n" +
                    "(Oh, Daniel prayed) Oh, Daniel prayed\n" +
                    "Every morning, noon and night every morning, noon and night\n" +
                    "He cared not for the king’s decree\n" +
                    "But trusted God to set him free\n" +
                    "(Oh, Daniel prayed) Oh, Daniel prayed\n" +
                    "Every morning, noon and night\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOh, Daniel served the living God\n" +
                    "\tWhile here upon this world he trod\n" +
                    "\t(He prayed to God) He prayed to God\n" +
                    "\tEvery morning, noon and night\n" +
                    "\tHe cared not for the things of Baal\n" +
                    "\tBut trusted one who never fails\n" +
                    "\t(Oh, Daniel prayed) Oh, Daniel prayed\n" +
                    "\tEvery morning, noon and night\n" +
                    "\n" +

                    "They cast Him in the lion’s den\n" +
                    "Because he would not honor men\n" +
                    "(He prayed to God) He prayed to God\n" +
                    "Every morning, noon and night\n" +
                    "Their jaws were locked, it made him shout\n" +
                    "And God soon brought him safely out\n" +
                    "(Oh, Daniel prayed) Oh, Daniel prayed\n" +
                    "Every morning, noon and night\n" +
                    "\n" +

                    "Oh, brother, let us watch and pray\n" +
                    "Like Daniel live from day to day\n" +
                    "(He prayed to God) He prayed to God\n" +
                    "Every morning, noon and night\n" +
                    "We, too, can gladly dare and do the things of God\n" +
                    "He’ll take us through\n" +
                    "(Oh, Daniel prayed) Oh, Daniel prayed\n" +
                    "Every morning, noon and night\n" ),

            new Eagle( "123. THIS TRAIN.\n","This train is bound for glory, this train\n" +
                    "This train is bound for glory, this train\n" +
                    "This train is bound for glory\n" +
                    "If you ride it you must be holy;\n" +
                    "This train is bound for glory, this train\n" +
                    "\n" +

                    "This train is bound for glory, this train\n" +
                    "This train is bound for glory, this train\n" +
                    "This train is bound for glory\n" +
                    "No hypocrites, midnight ramblers\n" +
                    "This train is bound for glory, this train\n" +
                    "\n" +

                    "This train don’t carry no liars, this train\n" +
                    "This train don’t carry no liars, this train\n" +
                    "This train don’t carry no liars\n" +
                    "No hypocrites and no high flyers\n" +
                    "This train is bound for glory, this train\n" +
                    "\n" +

                    "This train don’t carry no rustlers, this train\n" +
                    "This train don’t carry no rustlers, this train\n" +
                    "This train don’t carry no rustlers\n" +
                    "Side street walkers, two-bit hustlers\n" +
                    "This train is bound for glory, this train\n" ),

            new Eagle( "124. JOHN SAW THAT CITY.\n","There’s a city, Holy City,\n" +
                    "Where the streets are paved with gold\n" +
                    "And its walls are made of jasper\n" +
                    "And its beauty can’t be told\n" +
                    "It’s the home of the redeemed ones\n" +
                    "Who have known God saving grace\n" +
                    "What a happy, glad reunion when we meet in the place\n" +
                    "\n" +


                    "\tCHORUS:\n" +
                    "\tJohn saw that city,\n" +
                    "\tAnd the river flowing free\n" +
                    "\tSaw the tree transplanted,\n" +
                    "\tIn that city built for you and me\n" +
                    "\n" +

                    "In that city, Holy City\n" +
                    "Where no tears can dim the eye\n" +
                    "There will be no disappointment\n" +
                    "There will be no sad good byes\n" +
                    "All the saints will then be holy\n" +
                    "And will live in one accord\n" +
                    "There’ll be shouting, there’ll be singing\n" +
                    "When we meet with the Lord\n" +
                    "\n" +

                    "Over in that Holy City\n" +
                    "We will need no sun to shine\n" +
                    "We will walk the streets of glory\n" +
                    "In that happy land sublime\n" +
                    "Tis the of wondrous beauty\n" +
                    "Where the saints will never grow old\n" +
                    "We will sing glad hallelujah\n" +
                    "In that home of the soul\n" ),

            new Eagle( "125. LIGHT IN THE SKY.\n","Oh, the light in the sky\n" +
                    "Shining from the east to the west\n" +
                    "In a moment in the twinkling of an eye\n" +
                    "That’s the way our Lord shall come\n" +
                    "On that great triumphant morn\n" +
                    "Like a flash, quick as lightning from the sky\n" +
                    "\n" +

                    "Jesus said that there’d be signs\n" +
                    "In the earth and in the skies\n" +
                    "Look around and you will see them if you try\n" +
                    "East to west the lightnings shine\n" +
                    "Shows His coming so divine\n" +
                    "Like a flash, quick as lightning from the sky\n" +
                    "\n" +

                    "Oh, I want to meet Him there\n" +
                    "With His saints up in the air\n" +
                    "When He comes the sinful men of earth to try\n" +
                    "So prepare to meet Him, friend\n" +
                    "For He’ll surely come again\n" +
                    "Like a flash, quick as lightning from the sky\n" ),

            new Eagle( "126. SOMETHING GOT A HOLD OF ME.\n","At first when I heard of the people who claim\n" +
                    "The old time religion is real\n" +
                    "I said “I’ll go down, take a look at the crowd”\n" +
                    "For it’s just the weak mind that I feel\n" +
                    "I walked up the steps and peeked in the door\n" +
                    "The devil said, “Don’t you go in.”\n" +
                    "But I said, “It won’t hurt, I’ll just step inside,\n" +
                    "And sit as far back as I can.”\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tBut something got a hold of me, Praise God\n" +
                    "\tYes, something got a hold of me\n" +
                    "\tI went there to fight, but I tell you that night\n" +
                    "\tGod surely got a hold of me\n" +
                    "\n" +

                    "They sang like they meant it\n" +
                    "They all clapped their hands\n" +
                    "I said, “It’s emotion that’s all\n" +
                    "When they get down to pray,\n" +
                    "I’ll just get up and leave,\n" +
                    "For I don’t want to be seen here at all.”\n" +
                    "But about that time he got started to preach\n" +
                    "And he looked right straight down at me\n" +
                    "He told everybody how mean that I was\n" +
                    "Didn’t talk like he thought much of me\n" +
                    "\n" +

                    "I sat in my seat just thinking it o’er\n" +
                    "And they all started to pray\n" +
                    "The fire fell from heaven, I knelt to the floor;\n" +
                    "I prayed there and God had His way\n" +
                    "And now then I know that I don’t need to doubt\n" +
                    "For I got an experience that night\n" +
                    "For I’ll never forget it as long as I live\n" +
                    "I found that salvation was right\n" ),


            new Eagle( "127. DEATH OF MOTHER.\n","When I was just a little boy,\n" +
                    "My mother cared for me,\n" +
                    "But now she’s gone on to her rest,\n" +
                    "I’ll meet her there at rest.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI’ll never forget the death of mother,\n" +
                    "\tAlthough this is a sad song,\n" +
                    "\tI loved her then and I love her now,\n" +
                    "\tAnd I’ll love her even though she is gone.\n" +
                    "\n" +

                    "My mother was a helpless one,\n" +
                    "And could not walk a step,\n" +
                    "I nursed her like a little child,\n" +
                    "And I’d stay there by her side.\n" +
                    "\n" +

                    "One day my mother felt just fine,\n" +
                    "That made us feel so good,\n" +
                    "That night was the dying night,\n" +
                    "And it brought back heartaches and cries.\n" +
                    "\n" +

                    "On her neck a cancer grew,\n" +
                    "And that was the death of her,\n" +
                    "She suffered so before she died,\n" +
                    "And then she fainted and died.\n" +
                    "\n" +

                    "The blood did run down her neck,\n" +
                    "And run upon the floor,\n" +
                    "I held my mother in my arms,\n" +
                    "While Jesus took her in His arms.\n" ),

            new Eagle( "128. COME TO THE LORD AND BE SAVED.\n","Come and listen, my friend\n" +
                    "If you are lost in sin\n" +
                    "Just come and listen in\n" +
                    "And I’ll tell you how to get saved from sin\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tCome to the Lord and be saved\n" +
                    "\tCome and be saved today\n" +
                    "\tDo not put off His way\n" +
                    "\tJust come to the Lord and be saved\n" +
                    "\n" +

                    "If you are lost in sin,\n" +
                    "Get down on your knees all alone,\n" +
                    "God will give you a tongue\n" +
                    "Who-so-ever will let him come\n" +
                    "\n" +

                    "It’s time for you to be saved\n" +
                    "Or you will wait too late\n" +
                    "Het down on your knees all alone\n" +
                    "And come to the Lord all alone\n" ),

            new Eagle( "129. THEY WOULDN’T BEND.\n","Here is a story from the good book we know\n" +
                    "A story ‘bout a miracle That happened long ago\n" +
                    "We hope that you’ll take courage When temptation you meet\n" +
                    "There’s somebody watching you\n" +
                    "Who’s strong when you’re weak.\n" +
                    "\n" +


                    "\tCHORUS:\n" +
                    "\t(They wouldn’t bend)\n" +
                    "\tThey held to the will of God so we are told\n" +
                    "\t(They wouldn’t bow)\n" +
                    "\tThey would not bow their knees to the idols made of gold\n" +
                    "\t(They wouldn’t burn)\n" +
                    "\tThey were protected by the 4th man in the fire\n" +
                    "\tThey wouldn’t bend, they wouldn’t bow, they wouldn’t burn\n" +
                    " \n" +


                    "The prophet Daniel tells about three men who walked with God\n" +
                    "Shadrach, Meshach and Abednego\n" +
                    "Before the wicked king they stood\n" +
                    "And the king commanded them bound and thrown\n" +
                    "Into the fiery furnace that day\n" +
                    "But the fire was so hot and the men were slain\n" +
                    "Who forced them on the way\n" +
                    "Now when the three men were cast in,\n" +
                    "And the king rose up to witness this awful fate\n" +
                    "He began to tremble at what he saw\n" +
                    "And in astonished tones he spake\n" +
                    "Did we not cask three men bound into the midst of that fire?\n" +
                    "But, lo, I see four men unhurt, unbound and walking down there\n" +
                    "There’s Shadrach, Meshach and Abednego\n" +
                    "In the fiery coals they trod,\n" +
                    "And the form of the fourth man I see is like the son of God\n" ),

            new Eagle( "130. IF GOD BE FOR US.\n","\tCHORUS:\n" +
                    "\tHe said, “If God be for us, who can be against us?\n" +
                    "\tWho can separate us from His Mighty Hand?\n" +
                    "\tIf God be for us, who can be against us?\n" +
                    "\tWe can win the battle if for God we stand.”\n" +
                    "\n" +

                    "Goliath stood there boldly defying God army.\n" +
                    "There stood little David, but he didn’t stand alone\n" +
                    "He said, “In the name of The Lord, I come against thee!”\n" +
                    "He slew that giant with a sling and a stone\n" +
                    "\n" +

                    "The lions were roaring, fierce and hungry\n" +
                    "Daniel knew the one he served would bring him out\n" +
                    "The king cried, “Daniel, has your God delivered thee?”\n" +
                    "Daniel cried, “The Lord has shut the lions’ mouth.”\n" ),

            new Eagle( "131. ONE DAY I WAS OUT IN SIN.\n","One day I was in sin all alone\n" +
                    "Jesus came along to take me home\n" +
                    "And He showed me that I could be free\n" +
                    "But the devil came by and said it could not be\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tSo there I was between the two\n" +
                    "\tIt was easy to see that I was confused\n" +
                    "\tAnd as I look back, I wasn’t bad\n" +
                    "\tBut that was one way the ol’ devil could make us sad\n" +
                    "\n" +

                    "So look out my friend or the devil will win\n" +
                    "Our souls in hell, before we can win\n" +
                    "Look out at sin and leave it alone\n" +
                    "Jesus will come and take us home\n" +
                    "\n" +

                    "If the devil could only make us believe\n" +
                    "That was alright we could be deceived\n" +
                    "So look out for the devil, he’s a sneaky guy\n" +
                    "He will take your soul to hell, when you die\n" ),

            new Eagle( "132. I THOUGHT AND I THOUGHT.\n","And thought and I thought about my Lord\n" +
                    "How He died on the cross to save us from loss\n" +
                    "I fell on my knees, and prayed I could see\n" +
                    "And now I’m free and happy and see\n" +
                    "\n" +

                    "I thought and I thought about my sin\n" +
                    "If I should die before I win\n" +
                    "Then I thought of my soul, where it would go\n" +
                    "If I should die, before I know\n" +
                    "\n" +

                    "I thought and I thought about the people\n" +
                    "That go to church, and they would be weep-le’s\n" +
                    "And then go home, get mad and pout,\n" +
                    "That would make me wonder and doubt\n" ),

            new Eagle( "133. SHAKE HANDS WITH MOTHER AGAIN.\n","If I should be living when Jesus comes,\n" +
                    "And could know the day and the hour,\n" +
                    "I’d like to be standing at mother’s tomb,\n" +
                    "When Jesus comes in His power.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\t‘Twill be a wonderful happy day,\n" +
                    "\tYou left when you went away,\n" +
                    "\tWhen I can hear Jesus, my Saviour say,\n" +
                    "\tShake hands with mother again.\n" +
                    "\n" +

                    "I’d like to say “mother this is your boy,\n" +
                    "You left when you went away”\n" +
                    "And I can see Jesus upon His throne,\n" +
                    "In that bright city, so fair.\n" +
                    "\n" +

                    "There’s coming a time when I can go home,\n" +
                    "To meet my loved ones up there,\n" +
                    "There I can see Jesus upon His throne,\n" +
                    "In that bright city, so far.\n" +
                    "\n" +

                    "There’ll be no more sorrow or pain to bear,\n" +
                    "In that home beyond the sky,\n" +
                    "O glorious thought when we all get there,\n" +
                    "We never will say “good-bye”.\n" ),

            new Eagle( "134. I SAW A MAN.\n","Last night I dreamed an angel came.\n" +
                    "He took my hand, He called my name\n" +
                    "He made me look the other way\n" +
                    "I saw a man, I heard Him say,\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tHe said, “If I be lifted up,\n" +
                    "\tI’ll draw all men to me.”\n" +
                    "\tHe turned and then I saw the nail-scared hands that bled for me\n" +
                    "\tI touched the hem of His garment that fell round Him there\n" +
                    "\tMy life, my heart, I gave, my soul was in His care\n" +
                    "\n" +

                    "When I awoke my heart beat so\n" +
                    "And in the dark I saw a glow\n" +
                    "This was no dream, He turned my way\n" +
                    "Again I heard my savior say\n" ),

            new Eagle( "135. I’M READY TO GO.\n","\tCHORUS:\n" +
                    "\tHallelujah, (I’m ready) I’m ready (Hallelujah)\n" +
                    "\tI can hear the voices sing soft and low\n" +
                    "\tHallelujah, (I’m ready) I’m ready (Hallelujah)\n" +
                    "\tHallelujah, I’m ready to go\n" +
                    "\n" +

                    "In the darkest of night, not a star was in sight\n" +
                    "On the highway that leads down below\n" +
                    "But Jesus came in, saved my soul from sin\n" +
                    "Hallelujah, I’m ready to go\n" +
                    "\n" +

                    "Sinner, don’t wait until it’s too late\n" +
                    "He’s a wonderful savior to know\n" +
                    "I fell on my knees, He answered by pleas\n" +
                    "Hallelujah, I’m ready to go\n" ),

            new Eagle( "136. KEEP ON THE FIRING LINE.\n","If you’re in the battle for the Lord and the right\n" +
                    "Keep on the firing line\n" +
                    "If you win, my brother, surely you must fight\n" +
                    "Keep on the firing line\n" +
                    "There are many dangers that we all must face\n" +
                    "If we die still fighting is no disgrace\n" +
                    "Cowards in the service you will find no place,\n" +
                    "So keep on the firing line\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOh, you must fight, be brave against all evils\n" +
                    "\tNever run, nor even left behind.\n" +
                    "\tIf you will for God and the right just keep on the firing line\n" +
                    "\n" +

                    "God will only use the soldier He can trust.\n" +
                    "Keep on the firing line\n" +
                    "If you wear a crown, then bear the cross you must,\n" +
                    "Keep on the firing line\n" +
                    "Life is but to labor for the master dear,\n" +
                    "Help to banish evil and to spread good cheer\n" +
                    "Great you will be rewarded for your service here\n" +
                    "So keep on the firing line\n" +
                    "\n" +

                    "When we get to heaven, we’ll be glad,\n" +
                    "Keep on the firing line\n" +
                    "How we’ll praise the savior for the call we had\n" +
                    "Keep on the firing line\n" +
                    "When we see the souls that we have helped to win\n" +
                    "Leading them to Jesus, from the path of sin\n" +
                    "With a shout of welcome, we will all march in\n" +
                    "So keep on the firing line\n" ),

            new Eagle( "137. WHERE THE ROSES NEVER FADE.\n","I am going to a city,\n" +
                    "Where the streets of gold are laid,\n" +
                    "Where the tree of life is blooming,\n" +
                    "And the roses never fade.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tHere they bloom but for a season,\n" +
                    "\tSoon their beauty is decayed,\n" +
                    "\tI am going to a city,\n" +
                    "\tWhere the roses never fade.\n" +
                    "\n" +

                    "In this world we have our troubles,\n" +
                    "Satan’s thing we must evade,\n" +
                    "We’ll be free from all temptations,\n" +
                    "Where the roses never fade.\n" +
                    "\n" +

                    "Loved ones gone to be with Jesus,\n" +
                    "In the roses of white are laid,\n" +
                    "Now are waiting for my coming,\n" +
                    "Where the roses never fade.\n" ),

            new Eagle( "138. IT HAPPENED LIKE HE SAID.\n","On the Sea of Galilee a storm did prevail\n" +
                    "Then the Lord awoke and said, “Peace be still.”\n" +
                    "And it happened just like He said\n" +
                    "And the crowd round about cried, “What kind of man\n" +
                    "Rebuked the element and they understand”?\n" +
                    "It happened just like He said.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tIt happened just like He said\n" +
                    "\tHe cleansed the leper and He raised the dead\n" +
                    "\tHe fed five thousand with five loaves of bread\n" +
                    "\tHe said, “More things than these shall you do,\n" +
                    "\tFor I go to make intercession for you.”\n" +
                    "\tAnd it happened just like He said\n" +
                    "\n" +
                    "\n" +

                    "Well, blind Bartimaeus cried out by the road\n" +
                    "Jesus said, “Your faith has made you whole.”\n" +
                    "And it happened just like He said\n" +
                    "Jesus said, “What do you want from me?”\n" +
                    "Bartimeaus cried, “Lord, that I might see.”\n" +
                    "And it happened just like He said\n" +
                    "\n" +

                    "Jesus said, “Surely, I must go away,\n" +
                    "And if I go, I’m coming back someday.”\n" +
                    "And it’ll happened just like He said\n" +
                    "“I go to prepare a place for you,\n" +
                    "That where I am, you can be too.”\n" +
                    "And it’ll happened just like He said\n" ),

            new Eagle( "139. FADED BIBLE.\n","There’s a faded Bible on the table\n" +
                    "Worn by time and gentle hands you see.\n" +
                    "It’s the same old faded Holy Bible\n" +
                    "That mother used to always read to me\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI can hear her voice so sweet and tender\n" +
                    "\tAs she read the from the Bible for us all.\n" +
                    "\tHow I treasure that old faded Bible\n" +
                    "\tAnd mother’s picture hanging on the wall\n" ),

            new Eagle( "140. I HAVE THE LORD.\n","If I had all the wealth of this world,\n" +
                    "And I had not the love of my Lord,\n" +
                    "I would still be poor on this earth,\n" +
                    "But you see, I have the Lord and that’s enough\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI’m an heir to all of heaven\n" +
                    "\tOf course today, I have Jesus to show me the way.\n" +
                    "\tI’m so rich that I don’t know what I’m worth\n" +
                    "\tI have the Lord and that’s enough on this earth\n" +
                    "\n" +

                    "Once I was lost in the blackness of life\n" +
                    "But the Lord came and gave me my sight.\n" +
                    "Since that day I’ve been wealthy at heart\n" +
                    "You see, the Lord came and gave my start\n" ),

            new Eagle( "141. COME BRIDE.\n","Come and sit by my right oh you bride,\n" +
                    "come and lay your sweet on the fire,\n" +
                    "The fire of the word from on high,\n" +
                    "it will take your soul up on high.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tCome and sit by the one on my right,\n" +
                    "\tBe honest be faithful tonight,\n" +
                    "\tPromise Him you’ll be His friend,\n" +
                    "\tAnd never again be in sin.\n" +
                    "\n" +

                    "We had a great prophet with us,\n" +
                    "we should never be starchy or fuss\n" +
                    "He told us the truth about sin,\n" +
                    "So come up on high my friend.\n" +
                    "\n" +

                    "Watch every word and be saved,\n" +
                    "He hears every word that we say,\n" +
                    "This is a great prophecy my friend,\n" +
                    "if you take it you will go in.\n" ),
            new Eagle( "142. ON THE WAY TO CANAAN’S LAND","I’m on way to Canaan’s land\n" +
                    "I’m on way to Canaan’s land\n" +
                    "I’m on way to Canaan’s land\n" +
                    "I’m on my way (Praise God) I’m on my way\n" +
                    "\n" +

                    "If daddy won’t go, it won’t hinder me\n" +
                    "If daddy won’t go, it won’t hinder me\n" +
                    "If daddy won’t go, it won’t hinder me\n" +
                    "I’m on my way (Praise God) I’m on my way\n" +
                    "\n" +

                    "If mother won’t go, it won’t hinder me\n" +
                    "If mother won’t go, it won’t hinder me\n" +
                    "If mother won’t go, it won’t hinder me\n" +
                    "I’m on my way (Praise God) I’m on my way\n" +
                    "\n" +

                    "If sister won’t go, it won’t hinder me\n" +
                    "If sister won’t go, it won’t hinder me\n" +
                    "If sister won’t go, it won’t hinder me\n" +
                    "I’m on my way (Praise God) I’m on my way\n" +
                    "\n" +

                    "Oh, be baptized in Jesus name\n" +
                    "Oh, be baptized in Jesus name\n" +
                    "Oh, be baptized in Jesus name\n" +
                    "I’m on my way (Praise God) I’m on my way\n" +
                    "\n" +

                    "I’m on way to Canaan’s land\n" +
                    "I’m on way to Canaan’s land\n" +
                    "I’m on way to Canaan’s land\n" +
                    "I’m on my way (Praise God) I’m on my way\n" ),

            new Eagle( "143. THERE’LL BE JOY, JOY, JOY.\n","There’ll be joy, joy, joy\n" +
                    "Up in my father’s house\n" +
                    "Up in my father’s house\n" +
                    "Up in my father’s house\n" +
                    "There’ll be joy, joy, joy\n" +
                    "Up in my father’s house\n" +
                    "Where there’s peace, sweet peace\n" +
                    "\n" +

                    "We’ll all be happy there\n" +
                    "Up in my father’s house\n" +
                    "Up in my father’s house\n" +
                    "Up in my father’s house\n" +
                    "We’ll all be happy there\n" +
                    "Up in my father’s house\n" +
                    "Where there’s peace, wonderful peace\n" +
                    "\n" +

                    "Don’t you want to go up there?\n" +
                    "To my father’s house\n" +
                    "To my father’s house\n" +
                    "To my father’s house\n" +
                    "Don’t you want to go up there?\n" +
                    "To my father’s house\n" +
                    "Where there’s peace, sweet peace\n" +
                    "\n" +

                    "There’ll be drunkards there\n" +
                    "Up in my father’s house\n" +
                    "Up in my father’s house\n" +
                    "Up in my father’s house\n" +
                    "There’ll be drunkards there\n" +
                    "Up in my father’s house\n" +
                    "Where there’s peace, sweet peace\n" ),

            new Eagle( "144. MOTHERLESS CHILDREN.\n","Motherless children face a hard time in this world\n" +
                    "Motherless children face a hard time in this world\n" +
                    "They are driven out in the cold, got nowhere to go\n" +
                    "Motherless children face a hard time when the mother is dead\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOrphan children face a hard time in this world\n" +
                    "\tOrphan children face a hard time in this world\n" +
                    "\tSister does the best she can but she really don’t understand\n" +
                    "\tOrphan children face a hard time when the mother is dead\n" +
                    "\n" +

                    "Brother won’t treat you like mother will, when the mother is dead\n" +
                    "Brother won’t treat you like mother will, when the mother is dead\n" +
                    "You may ask a piece of bread, but you are told to go to bed\n" +
                    "Motherless children face a hard time when the mother is dead\n" +
                    "\n" +

                    "Friends won’t treat you like mother will, when the mother is dead\n" +
                    "Friends won’t treat you like mother will, when the mother is dead\n" +
                    "They will tell you what to do but they’ll turn their back on you\n" +
                    "Motherless children face a hard time when the mother is dead\n" ),

            new Eagle( "145. DUST ON THE BIBLE.\n","\tCHORUS:\n" +
                    "\tDust on the Bible,\n" +
                    "\tDust on the Holy Bible,\n" +
                    "\tThe words of all the prophets\n" +
                    "\tAnd the sayings of our Lord\n" +
                    "\tOf all the other books you’ll find\n" +
                    "\tThere’s none salvation whole\n" +
                    "\tGet the dust off the Bible\n" +
                    "\tAnd redeem your poor soul\n" +
                    "\n" +

                    "I went into a home one day\n" +
                    "To see some friends of mine\n" +
                    "Of all their books and magazines,\n" +
                    "Not a Bible could I find\n" +
                    "I asked them for the Bible\n" +
                    "When they brought it what a shame\n" +
                    "The dust was covered o’er it\n" +
                    "Not a fingerprint was plain\n" +
                    "\n" +

                    "You can read magazines,\n" +
                    "Read of love and tragic things\n" +
                    "And one verse of scripture\n" +
                    "Do you know,\n" +
                    "When it is the very truth,\n" +
                    "And its contents good for you\n" +
                    "Dust on the Bible\n" +
                    "Will doom your poor soul\n" ),

            new Eagle( "146. A SOLDIER PRAYER.\n","A letter came to me today.\n" +
                    "With a broken heart, I knelt to pray\n" +
                    "The letter said my mother’s gone\n" +
                    "Far away to claim her brand new home\n" +
                    "\n" +

                    "Daddy says here just before she died\n" +
                    "How she would pray for me and cry,\n" +
                    "For God to bring her darling home\n" +
                    "From this war that’s kept me here so long\n" +
                    "\n" +

                    "Oh, mother dear, it won’t be long,\n" +
                    "Your baby boy is coming home\n" +
                    "We’ll soon unite way up on high\n" +
                    "Where there is no war up in the sky\n" +
                    "\n" +

                    "I’m proud to serve the soldier said\n" +
                    "His tearing eyes were turning red\n" +
                    "I’ve waited so long to come home\n" +
                    "But I’ll meet you, mama, in the sky\n" +
                    "\n" +

                    "My country called I had to go\n" +
                    "To defend this land we all love so\n" +
                    "From this wound my time has come to die\n" +
                    "Soon I’ll meet you, mama, in the sky\n" +
                    "\n" +

                    "Oh, mother dear, it won’t be long\n" +
                    "Your baby boy is coming home\n" +
                    "We’ll soon unite way up on high\n" +
                    "Where there’s no war up in the sky\n" ),

            new Eagle( "147. PURPLE ROBE.\n","There’s a story so unkind,\n" +
                    "In the Holy book we find,\n" +
                    "It tells us how Jesus stood alone one day\n" +
                    "False accused and then condemned\n" +
                    "Yet they found no fault in Him,\n" +
                    "The man who wore the scarlet purple robe.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tPurple robe my Saviour wore,\n" +
                    "\tOh the shame for me He bore\n" +
                    "\tAs He stood alone forsaken on that day,\n" +
                    "\tThere they placed upon His head\n" +
                    "\tPiercing thorns the blood stained red,\n" +
                    "\tHis raiment was a scarlet purple robe.\n" +
                    "\n" +

                    "In the common judgment hall\n" +
                    "He was mocked and scorned by all\n" +
                    "As tears of sorrow fell upon His cheeks\n" +
                    "Soldiers of the wicked band,\n" +
                    "Smote Him with their evil hands\n" +
                    "The man who wore the scarlet purple robe.\n" ),

            new Eagle( "148. WE DON’T HAVE AS FAR TO GO.\n","Some years ago I started out\n" +
                    "To travel on sweet heaven’s rout\n" +
                    "Oft times the road gets rough and long\n" +
                    "But I don’t have as far to go, as I had before\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tWe don’t have as far to go my friend, as we had before\n" +
                    "\tWe have waded waters deep\n" +
                    "\tWe climbed high mountain peaks\n" +
                    "\tWe have walked through the valley low\n" +
                    "\tWe don’t have as far to go my friend, as we had before\n" +
                    "\n" +

                    "He brought me out from sin and shame\n" +
                    "In my despair, I called His name\n" +
                    "Just look where He has brought us from\n" +
                    "We don’t have as far to go my friend, as we had before\n" ),

            new Eagle( "149. THEY ARE PRAISING GOD OVER THERE.\n","Come and go with me, come and go with me\n" +
                    "Come and go with me over there\n" +
                    "Come and go with me, Come and go with me\n" +
                    "Come and go with me over there\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOver there, over there\n" +
                    "\tThey are praising God over there\n" +
                    "\tOver there, over there\n" +
                    "\tThey are praising God over there\n" +
                    "\n" +

                    "Come sinner friend, come sinner friend,\n" +
                    "Come and go with me over there\n" +
                    "Come sinner friend, come sinner friend\n" +
                    "Come and go with me over there\n" +
                    "\n" +

                    "God will save your soul, God will save your soul\n" +
                    "God will save your soul over there\n" +
                    "God will save your soul, God will save your soul\n" +
                    "God will save your soul over there\n" +
                    "\n" +

                    "The Holy Ghost is there, The Holy Ghost is there\n" +
                    "The Holy Ghost is over there\n" +
                    "It will fall on you, it will fall on you\n" +
                    "It will fall on you over there\n" ),

            new Eagle( "150. IF THAT ISN’T LOVE.\n","He left the splendor of heaven,\n" +
                    "Knowing His destiny,\n" +
                    "Was the lonely hill of Golgotha,\n" +
                    "There to lay down His life for me.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tIf that isn’t love,\n" +
                    "\tThe ocean is dry,\n" +
                    "\tThere’s no stars in the sky,\n" +
                    "\tAnd the sparrow can’t fly,\n" +
                    "\tIf that isn’t love,\n" +
                    "\tHeaven is a myth,\n" +
                    "\tThere’s no feeling like this,\n" +
                    "\tIf that isn’t love.\n" +
                    "\n" +

                    "Even in death He remembered,\n" +
                    "The thief hanging by His side,\n" +
                    "He spoke with love and companion\n" +
                    "Then He took Him to Paradise.\n" ),

            new Eagle( "151. GOLDEN LIGHT.\n","There’s a bright and golden light\n" +
                    "That is shining on our way,\n" +
                    "And it cometh from above,\n" +
                    "Tis a precious light of truth\n" +
                    "That will lead to endless day\n" +
                    "Tis a light of the Saviour’s love.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tGolden light, (golden light), shine on (shine on)\n" +
                    "\tShine on us from above\n" +
                    "\tIt will brighten up the way\n" +
                    "\tThat will lead to endless day\n" +
                    "\tTis a light of the Saviour’s love.\n" +
                    " \n" +

                    "Tis the light that leads me on\n" +
                    "Keeps me from the path of sin\n" +
                    "To my savior I will flee\n" +
                    "Tis a glorious light of day\n" +
                    "It will guide us on our way\n" +
                    "That will give us joy and peace within.\n" +
                    "\n" +

                    "If we trust the Saviour’s voice\n" +
                    "And obey His blessed command\n" +
                    "It will lead us home above\n" +
                    "There the golden light will shine\n" +
                    "Ever in that happy clime\n" +
                    "It will be God’s own precious love.\n" ),

            new Eagle( "152. HE WONT ACCEPT EXCUSES.\n","All of you my brother, lost in sin today,\n" +
                    "Prepare to seek the savior before it’s too late\n" +
                    "You can’t have excuses, for Jesus won’t accept excuses up in Heaven,\n" +
                    "Where judgment must be met.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tHe won’t accept excuses, if you want to enter in\n" +
                    "\tYou’ll have to come to Jesus and free your soul from sin\n" +
                    "\tDon’t think that He will pardon if you forget to pray\n" +
                    "\tHe won’t accept excuses on the great judgment day.\n" +
                    "\n" +

                    "If you never think of Jesus, oh what a fatal end\n" +
                    "It could lead to judgment corrupted with sin,\n" +
                    "If to the Divine daily, you forgot to pray,\n" +
                    "Up there in Heaven you will be turned away.\n" +
                    "\n" +

                    "You can’t tell the savior if you had things to do\n" +
                    "If you die in sin, there can be no excuses,\n" +
                    "First seek the kingdom and Jesus to obey,\n" +
                    "This world doesn’t matter, when you meet the judgment day.\n" ),

            new Eagle( "153. I WANT TWO WINGS.\n","Go down, Gabriel, go down,\n" +
                    "Put one foot on the sea,\n" +
                    "But don’t you blow that trumpet, Good Lord,\n" +
                    "Till you get your command from me.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tO Lord, I want two wings to veil my face,\n" +
                    "\tO Lord, I want two wings to fly away,\n" +
                    "\tO Lord, I want two wings to veil my face,\n" +
                    "\tSo this world can’t do me no harm.\n" +
                    "\n" +

                    "Well, when I get to Heaven,\n" +
                    "Gonna put on my white long robe,\n" +
                    "Gonna drink from that cool, clear water, Good Lord,\n" +
                    "To satisfy my thirsty soul.\n" ),

            new Eagle( "154. WAIT A LITTLE LONGER PLEASE JESUS.\n","Here the labour is so hard, The work is hard and tired,\n" +
                    "And our weary hearts are yearning for a rest\n" +
                    "Then finally getting anxious To be in that happy land,\n" +
                    "Where we receive good peace and happiness.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tWait a little longer please, Jesus,\n" +
                    "\tThere are so many still wandering now in sin,\n" +
                    "\tJust a little longer please Jesus,\n" +
                    "\tA few more days to get our loved ones in.\n" +
                    "\n" +

                    "We may look in to the skies, and tears will fill our eyes\n" +
                    "For our burdened hearts grow heavy every day,\n" +
                    "For if we cry, oh Lord to come, come and take the children home\n" +
                    "And then we look around and then we’ll say.\n" ),

            new Eagle( "155. HEAVEN CAME DOWN AND GLORY FILLED MY SOUL.\n","Oh, what a wonderful, wonderful day,\n" +
                    "Day I shall never forget\n" +
                    "After I’d wandered in darkness away,\n" +
                    "Jesus, my Saviour I met\n" +
                    "Oh, what a tender, compassionate friend,\n" +
                    "He met the needs of my heart,\n" +
                    "Shadows dispelling, with joy I am telling,\n" +
                    "He made all my darkness depart.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tHeaven came down and glory filled my soul,\n" +
                    "\tWhen at the cross my Saviour made me whole\n" +
                    "\tMy sins were washed away, and my night was turned to day,\n" +
                    "\tHeavens came down and glory filled my soul.\n" +
                    "\n" +

                    "Born of the spirit of life from above, Into God family divine,\n" +
                    "Justified fully through Calvary’s blood,\n" +
                    "Oh, what a standing is mine\n" +
                    "And the transaction so quickly was made,\n" +
                    "When as a sinner I came\n" +
                    "Took of the offer, of grace He did offer,\n" +
                    "He saved me Oh praise His dear name.\n" +
                    "\n" +

                    "Now I’ve a hope that will surely endure,\n" +
                    "After the passing of time\n" +
                    "I have a mansion in Heaven for sure,\n" +
                    "There in those mansions sublime\n" +
                    "And it’s because of that wonderful day,\n" +
                    "When at the cross I believed\n" +
                    "Riches eternal, and blessings supernal,\n" +
                    "From His precious hand I received.\n" ),

            new Eagle( "156. ASHAMED TO OWN MY BLESSED SAVIOUR.\n","Upon the lonely tree of Calvary,\n" +
                    "My savior took the blame for me,\n" +
                    "Then do you think that I’d disowned him,\n" +
                    "When His own blood He shed for me?\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tAshamed to own my blessed Saviour,\n" +
                    "\tAshamed of Him who died for you,\n" +
                    "\tSomeday I know that you’ll be sorry,\n" +
                    "\tFor He’ll be ashamed of you.\n" +
                    "\n" +

                    "Oh brother how can you deny Him,\n" +
                    "Ashamed to own God’s gift of love,\n" +
                    "Our only promise of tomorrow,\n" +
                    "Our precious Saviour from above.\n" +
                    "\n" +

                    "Oh Lord above, look down upon me,\n" +
                    "Though I’m not worthy now to pray,\n" +
                    "Please cleanse me, Lord and make me holy,\n" +
                    "That you would own me every day.\n" ),

            new Eagle( "157. OLD FOLKS HOME.\n","When Mom and Dad start growing old,\n" +
                    "Our setting sun is rear,\n" +
                    "They find that they’re forsaken\n" +
                    "By the ones they hold so dear,\n" +
                    "They gave their children the best they had,\n" +
                    "And now they’re left alone\n" +
                    "To live a life of loneliness\n" +
                    "In an Old Folks Home.\n" +
                    "\n" +

                    "The time when help is needed most\n" +
                    "Their children turn them down\n" +
                    "They seem to cause unhappiness\n" +
                    "Whenever they’re around\n" +
                    "They did not seem to mind at all\n" +
                    "You were their very own\n" +
                    "But now you gave them loneliness\n" +
                    "In an Old Folks Home.\n" +
                    "\n" +

                    "They did without so many things\n" +
                    "They loved and cared for you\n" +
                    "When you were sick, they stayed awake\n" +
                    "And watched the whole night through\n" +
                    "They did not seem to mind at all\n" +
                    "For you were their very own\n" +
                    "But now you gave them loneliness\n" +
                    "In an Old Folks Home.\n" +
                    "\n" +

                    "I know they’d like to share your home\n" +
                    "And live the way you do\n" +
                    "To have someone to care for them\n" +
                    "The way they cared for you\n" +
                    "With broken hearts they pray at night\n" +
                    "For God to call them home\n" +
                    "Where there will be no loneliness\n" +
                    "In an Old Folks Home.\n" ),

            new Eagle( "158. I HEARD MY MOTHER PRAY FOR ME.\n","Last night as I lay down to sleep\n" +
                    "I heard someone begin to weep\n" +
                    "Then I got up just to see\n" +
                    "I heard my mother praying for me.\n" +
                    "\n" +

                    "She was kneeling by her bed\n" +
                    "And tears of pain were being shed\n" +
                    "She said, “Dear God, please hear my plea”\n" +
                    "I heard my mother praying for me.\n" +
                    "\n" +

                    "I got my Bible and sat down\n" +
                    "And in the Holy Book I found\n" +
                    "The way to end this misery\n" +
                    "Thank God my mother prayed for me.\n" +
                    "\n" +

                    "I read it on into the night\n" +
                    "And began to see the light\n" +
                    "And now at least my soul is free\n" +
                    "Thank God my mother prayed for me.\n" ),

            new Eagle( "159. TO GET MY REWARD.\n","I’ve heard my sin forgiven\n" +
                    "And I’m on my journey home\n" +
                    "For me a rest awaiting\n" +
                    "There I’ll live on and on.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tEvery day, everyday a little nearer\n" +
                    "\tEvery night I talk to my Lord\n" +
                    "\tI’ll soon be going to heaven to get my reward\n" +
                    "\tTo get my reward, yes to get my reward\n" +
                    "\tI’ll soon be going to heaven to get my reward\n" +
                    "\n" +

                    "Just a few more days to travel\n" +
                    "Just a few more nights to pray\n" +
                    "But glory, hallelujah\n" +
                    "I’ll be shouting on my way.\n" +
                    "\n" +

                    "This world is not my home\n" +
                    "I just stopped to say hello\n" +
                    "And tell you about the place\n" +
                    "I’m planning now to go.\n" ),

            new Eagle( "160. UNLOVED AND UNCLAIMED.\n","She lay on a cold marble slab at the morgue\n" +
                    "Thousand viewed her, but none knew her name\n" +
                    "They laid her to rest in potter’s field this morn\n" +
                    "She’ll sleep there unloved and unclaimed.\n" +
                    "There was no loved ones to weep over her\n" +
                    "Not one tear did I see shed\n" +
                    "The lady they took from that muddy old river\n" +
                    "But no one came to claim their dead.\n" +
                    "\n" +

                    "The muddy old river has taken her life\n" +
                    "And a cold earth will hold her remains\n" +
                    "I pray when she reaches those pearly golden gates,\n" +
                    "She won’t be unloved and unclaimed.\n" +
                    "\n" +

                    "She lay in a cold marble slab at the morgue\n" +
                    "Thousand view her, but non knew her name\n" +
                    "They laid her to rest in potter’s field this morn\n" +
                    "She’ll sleep there unloved and unclaimed.\n" ),

            new Eagle( "161. THE LONESOME VALLEY.\n","Everybody’s got to walk that lonesome valley\n" +
                    "They’ve got to walk it by their self\n" +
                    "There’s nobody here can walk it for them\n" +
                    "They’ve got to go there by their self.\n" +
                    "\n" +
                    "\n" +

                    "He’s got to walk that lonesome valley\n" +
                    "He’s got to walk it by himself\n" +
                    "There’s nobody here can walk it for him\n" +
                    "He’s got to go there by himself.\n" +
                    "\n" +

                    "Every sinner’s got to walk that lonesome valley\n" +
                    "They’ve got to walk it by their self\n" +
                    "There’s nobody here can walk it for them\n" +
                    "They’ve got to go there by their self.\n" ),

            new Eagle( "162. THE LOVE OF GOD.\n","If you could own all the world and its money,\n" +
                    "Build castles tall enough to reach the sky above,\n" +
                    "If you could know everything there was to know about life’s game,\n" +
                    "Then you know nothing until you’ve known the love of God.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tUntil you’ve known the loving hand,\n" +
                    "\tThat reaches down to fallen men,\n" +
                    "\tAnd lifts him up from out of sin where he was trod,\n" +
                    "\tUntil you’ve known just how it feels,\n" +
                    "\tTo know that God is really real\n" +
                    "\tThen you’ve known nothing until you’ve known the love of God.\n" +
                    "\n" +

                    "If in your life-time you could meet every body,\n" +
                    "And you could call every name from here to yon.\n" +
                    "But if you’ve not come face to face with Jesus and His saving grace,\n" +
                    "Then you know nothing until you’ve known the love of God.\n" ),

            new Eagle( "163. AN EMPTY MANSION.\n","Here I labor and toil, as I look for a home,\n" +
                    "Just an humble abode among men\n" +
                    "While in heaven a mansion is waiting for me,\n" +
                    "And the gentle ones pleading, come in.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThere’s a mansion now empty, just waiting for me,\n" +
                    "\tAt the end of life’s troublesome way,\n" +
                    "\tMany friends and dear loved ones\n" +
                    "\tWill welcome me there\n" +
                    "\tNear the door of that mansion some day.\n" +
                    "\n" +

                    "Ever thankful am I that my savior and Lord\n" +
                    "Promised unto the weary sweet rest\n" +
                    "Nothing more could I ask than a mansion above,\n" +
                    "There to live with the saved and the blessed.\n" +
                    "\n" +

                    "When my labor and toiling have ended below\n" +
                    "And my hands shall lie folded in rest,\n" +
                    "I’ll exchange this old home for a mansion up there,\n" +
                    "And invite the archangel as guest." ),

            new Eagle( "164. JESUS SAVIOUR PILOT ME.\n","Jesus, Saviour, pilot me,\n" +
                    "Over life’s tempest sea,\n" +
                    "Unknown waves before me roll,\n" +
                    "Hiding rocks and treacherous shore\n" +
                    "Chart and compass come from thee\n" +
                    "Jesus, Saviour, pilot me,\n" +
                    "\n" +

                    "As a mother stills her child\n" +
                    "Thou canst hush the oceans wild\n" +
                    "Boisterous waves obey they will\n" +
                    "When thou sayest to them, “Be still”\n" +
                    "Jesus, Saviour, pilot me,\n" +
                    "\n" +

                    "When at last I reach the shore\n" +
                    "And the fearful breakers roar\n" +
                    "Twixt me and the peaceful rest\n" +
                    "Then while leaning on thy breast\n" +
                    "May I hear Thee say to me,\n" +
                    "“Fear not I will pilot thee”\n" ),

            new Eagle( "165. NEARER MY GOD TO THEE.\n","Near-er my God to thee, Near-er to thee, E’ven though it be a cross that raiseth me,\n" +
                    "Still all my songs shall be, Near-er my God to thee,\n" +
                    "\n" +

                    "\tCHORUS:\t\n" +
                    "Near-er my God to thee, Near-er to thee.\n" +
                    "\n" +

                    "Though like the wan-der-er, the sun go down, dark-ness be over me, my rest a stone,\n" +
                    "Yet in my dream I would be, Near-er my God to thee, \n" +
                    "\n" +

                    "There let the way ap-pear steps unto heav-n, all that thou send-est me, in mer-cy given,\n" +
                    "Angels to beck-on me,Near-er my God to thee,\n" +
                    "\n" +

                    "Then with the walk-ing thoughts, bright with thy praise’ out of my ston-y griefs, Beth-el I raise,\n" +
                    "So by my woes to be, Near-er my God to thee,\n" +
                    "\n" +

                    "Or if on joy-full wings, cleav-ing the sky, sun, moon and stars for-got, up-ward I fly,\n" +
                    "Still all my songs shall be, Near-er my God to thee,\n" ),

            new Eagle( "166. ALLELUIA SING TO JESUS.\n","Al-le-lu-ia! Sing to Jesus, He’s the scepter, He’s the throne,\n" +
                    "Al-le-lu-ia! He’s the tri-umph, He’s the vic-tory alone,\n" +
                    "Hath the song of peace-full Zi-on, thunder like a mighty flood,\n" +
                    "“Jesus out of every na-tion” hath redeemed us by His blood.\n" +
                    "\n" +

                    "Al-le-lu-ia! Not as or-phan, are we left in sor-row now,\n" +
                    "Al-le-lu-ia! He is near us, Faith belive nor qus-tion how,\n" +
                    "Though the cloud from sight re-ceived Him, when the forty days were o’er,\n" +
                    "Shall our heart for-get His prom-ise, “I am with you ev-er more”?\n" +
                    "\n" +

                    "Al-le-lu-ia! Bread of Heaven, Thou on earth our food and stay,\n" +
                    "Al-le-lu-ia! Hear the sin-full, flee to thee from day to day,\n" +
                    "Inter-ces-sor friend of sin-ners, Earth re-deem-er pleaded for me,\n" +
                    "Where the songs of all the sin-less, sweep across the crys-tal sea.\n" ),

            new Eagle( "167. JOY TO THE WORLD.\n","Joy to the world! The Lord is come, let earth re-ceive her king, let every heart, prepare Him room,\n" +
                    "And Heav’n and na-ture sing, And Heav’n and na-ture sing, and Heav’n and Heav’n and na-ture sing, \n" +
                    "\n" +

                    "Joy to the world! The Sav-iour reigns, let men their songs em-ploy, while fields and floods, rocks, hills and plain,\n" +
                    "Re-peat the sounding joys, Re-peat the sounding joys, Re-peat, Re-peat the sounding joys, \n" +
                    "\n" +

                    "No more let sin and sor-row grow, no thorns in-fest the ground, He comes to make, His blessings flow,\n" +
                    "Far as the curse is found, Far as the curse is found,Far as, Far as the curse is found, \n" +
                    "\n" +

                    "He rules the world with truth and grace, and makes the na-tions prove, the glo-ries of His \n" +
                    "right-eousness,\n" +
                    "And wonders of His love, And wonders of His love, And wonders, And wonders of His love,\n" ),

            new Eagle( "168. ONE DAY JESUS WILL CALL MY NAME.\n","Some days fly and some days drag\n" +
                    "Some days I think of the day I’ll go\n" +
                    "Some days fill me and some days drain\n" +
                    "But one day, Jesus will call my name\n" + "\n" +


                    "\tCHORUS:\t\n" +
                    "   One day, Jesus will call my name\n" +
                    "   As days go by, hope I don’t stay the same\n" +
                    "   I wonna get so close to Him\n" +
                    "   There is no big change\n" +
                    "   On that day when Jesus calls my name\n" +
                    "\n" +

                    "Now most days I pray\n" +
                    "But some days I have curse\n" +
                    "There are many other days I have put myself first\n" +
                    "But it’s not what I do\n" +
                    "The cross laid the plan that one day, \n" +
                    "Jesus will call my name \n"),

            new Eagle( "169. JESUS IN ME.\n","As we travel through this world full of strives\n" +
                    "What kind of picture do we paint with our eyes?\n" +
                    "We might be the only Bible they see\n" +
                    "That’s why I hope and pray \n" +
                    "That they see Jesus in me\n" +   "\n" +

                    "\tCHORUS:\n" +
                    "   Jesus in me and the life that I live\n" +
                    "   Do they see a nail scared hand a man from Galilee?\n" +
                    "   Do they see a rugged cross on dark Calvary? \n" +
                    "   I hope and pray that the see Jesus in me\n" +
                    "\n" +

                    "In creation, there is something so eagerly made\n" +
                    "So we must be careful what we do and say\n" +
                    "A kind word, a soft touch a smile they can see\n" +
                    "So may be the world can see Jesus in me\n" ),

            new Eagle( "170. AFTER IT ALL.\n","Trials here sometimes are many\n" +
                    "And of times my feet grow weary\n" +
                    "And it’s seem I almost stumble then and fall\n" +
                    "But the tender hand that leads me \n" +
                    "Is the hand that keeps me steady\n" +
                    "And by faith I know I’ll make it after all\n" + "\n" +


                    "\tCHORUS:\n" +
                    "   After all this life is over\n" +
                    "   And my burdens have been lifted\n" +
                    "   And I stand upon the mountain top so tall\n" +
                    "   Looking over to the river that the savior is preparing\n" +
                    "   Gives me faith that I can make it after all\n" +
                    "\n" +

                    "By myself I cannot make it\n" +
                    "But I know He is here to lead me\n" +
                    "He will hear my cry just every time I call\n" +
                    "Keep on trusting keep on believing\n" +
                    "Are the words I hear Him whisper\n" +
                    "Just a few more days to labor after all \n" ),

            new Eagle( "171. I THIRST.\n","One day I came to Him, I was so thirsty\n" +
                    "I asked for water, my throat was so dry\n" +
                    "He gave me water that I have never dreamed of\n" +
                    "But for this water, my lord had to die\n" + "\n" +

                    "\tCHORUS:\n" +
                    "   He said “I thirst yet,” He made the rivers\n" +
                    "   He said “I thirst,” yet He made the sea\n" +
                    "   “I thirst,” said the King of the ages\n" +
                    "   In this great thirst, He brought water to me\n" +
                    "\n" +

                    "Now there is a river that flows as clear as crystal\n" +
                    "It comes from God throne above\n" +
                    "And like a river, it wells up inside me\n" +
                    "Bringing mercy, and life giving love\n" ),

            new Eagle( "172. UNTIL THEN.\n","It’s so plain to see the time is getting shorter\n" +
                    "Anyone can tell this world just cannot stand\n" +
                    "For the things, God created in their beauty they are now being destroyed by mortal man\n" +
                    "Oh! But God is going to raise Him up a nation\n" +
                    "Who will delight in Him and do His perfect will\n" +
                    "My friends, I feel the time is drawing nearer\n" +
                    "When we shall see our savior as He is\n" + "\n" +

                    "\tCHORUS:\n" +
                    "   But until then, I’ll lift the name of Jesus\n" +
                    "   Until then I’ll lead His lost sheep to the fold\n" +
                    "   I’ll tell the world, Jesus lives, he still saves, he still heals\n" +
                    "   And you can still find sweet refuge for your soul \n" +
                    "\n" +

                    "Any day now, I’m gonna move to my new mansion\n" +
                    "Custom built by Jesus Christ the King of kings\n" +
                    "When we gather, round the throne, with our savior\n" +
                    "We’ll sing a song that the angels cannot sing \n" ),

            new Eagle( "173. THERE IS A NEW NAME WRITTEN IN GLORY.\n","I was once a sinner, but I came\n" +
                    "Pardon to receive from my Lord\n" +
                    "This was freely given, and I found\n" +
                    "That He always kept His word\n" + "\n" +

                    "\tCHORUS:\n" +
                    "   There is a new name written UP in glory,\n" +
                    "   And it’s mine, (and it’s mine)\n" +
                    "   Oh yes, it’s mine! (Yes, it’s mine!)\n" +
                    "   And the white-robed angels sing the story \n" +
                    "   ‘A sinner has come home’ (has come home)\n" +
                    "   There is a new name written up in glory,\n" +
                    "   And it’s mine, (and it’s mine)\n" +
                    "   Oh yes, it’s mine! (Yes, it’s mine!)\n" +
                    "   With my sins forgiven I am bound for heaven \n" +
                    "   Never more to roam \n" +
                    "\n" +

                    "I was humbly kneeling at the cross\n" +
                    "Fearing naught but God’s angry frown;\n" +
                    "When the heavens opened and I saw\n" +
                    "That my name was written down\n" +
                    "\n" +

                    "In the book it’s written, “Saved by grace”\n" +
                    "O the joy that came to my soul\n" +
                    "Now I am forgiven, and I know\n" +
                    "By the blood I’m made whole\n" ),

            new Eagle( "174. THE CRIMINAL ON THE CROSS.\n","Well it was many years ago, in the time of the Bible\n" +
                    "“That they took him up to Calvary.”\n" +
                    "They could’ve let Him go, but instead,\n" +
                    "They chose Barabbas to set another criminal free\n" +
                    "When they crucified the ever loving caring master with compassion\n" +
                    "Flowing from his eyes, well He said to a thief\n" +
                    "Who was begging for mercy that today you will live in paradise.\n" + "\n" +

                    "\tCHORUS:\n" +
                    "   I am saved like the criminal on the cross\n" +
                    "   Praise God I am saved no more to suffer lose\n" +
                    "   Well he I’d live in paradise today\n" +
                    "   And He is taking care of the cost Hallelujah,\n" +
                    "   I am saved like the criminal on the cross.\n" +
                    "\n" +

                    "Well on the judgment day when all the people gather round Him\n" +
                    "And they wait to hear what He would declare\n" +
                    "There will never ever be more intense anticipation\n" +
                    "That has ever happened any where\n" +
                    "When they call my name to defend my reputation,\n" +
                    "There is only one thing I can say. I am a wretch, I am a worm\n" +
                    "I am a no good sinner. But He said “ I’ll save you any way.”\n" ),

            new Eagle( "175. I FIND JESUS.\n","I walk in silence when it comes. \n" +
                    "This feeling when the spirit leads me on\n" +
                    "If the day is barking and the night is rough. I take it as a sign to climb above\n" +
                    "The city to the hill among the clouds where I can see my savior now\n" +
                    "He is waiting with His palm, to me outstretched\n" +
                    "His mercy is a balm when I am perplexed.\n" + "\n" +

                    "\tCHORUS\n" +
                    "   I find Jesus in the darkest night\n" +
                    "   I find Jesus in the morning bright\n" +
                    "   I find Jesus in the face of those\n" +
                    "   Whose hearts are singing with the heavenly host\n" +
                    "   Some times when I feel alone, I look around and all are gone\n" +
                    "   The friends that I rely upon, are busy doing what they want\n" +
                    "   I look within and I am told its Sunday morning in my soul\n" +
                    "   And there I find a holy hall, where congregations heed the call\n" +
                    "\n" +

                    "And when I lay down my last time, and feel a chill run up my spine\n" +
                    "And recognize my time has come, I'll look around, He’ll lead me home\n" +
                    "He’ll reach his loving hand to me and bid me climb to victory\n" +
                    "Where we’ll find kindred spirits there, hearts raised in song without a care.\n" ),

            new Eagle( "176. GOD ON THE MOUNTAIN.\n","Life is easy when you are up on the mountain\n" +
                    "And you’ve got peace of mind like you’ve never known\n" +
                    "But things change when you’re down in the valley\n" +
                    "Don’t lose faith for you’re never alone\n" +  "\n" +

                    "\tCHORUS\n" +
                    "   For the God of the mountain is still God in the valley\n" +
                    "   When things go wrong, he’ll make them right\n" +
                    "   And the God of the good times, is still God in the bad times\n" +
                    "   The God of the day is still God in the night\n" +
                    "\n" +

                    "You talk of faith when you’re up on the mountain\n" +
                    "But talk comes so easy when life’s at its best\n" +
                    "Now you’re in the valley of trials and temptations\n" +
                    "That’s where your faith is really put to test\n" ),

            new Eagle( "177. THEY ALL BELONG TO MY FATHER.\n","No matter where I may roam in this world\n" +
                    "I’m still at home with the Father\n" +
                    "I at home anywhere in this world\n" +
                    "Cause it all belong to my Father\n" + "\n" +

                    "\tCHORUS\n" +
                    "   The mountain, the valley, the desert, the hills\n" +
                    "   They all belong to my father\n" +
                    "   The good Lord, He made them and he own them still\n" +
                    "   They all belong to my Father\n" +
                    "\n" +

                    "Mc Clusky or Steinberg, whatever your name\n" +
                    "We all belong to the Father\n" +
                    "He made us all and He loves us the same\n" +
                    "We all belong to the Father\n" +
                    "\n" +

                    "He made us and that make us all brothers\n" +
                    "We all belong to the Father\n" +
                    "That’s why He told to love one another\n" +
                    "We all belong to the Father" ),

            new Eagle( "178. I WANT TO LIVE THERE, DON'T YOU.\n" ,"There’s a beautiful home waiting over the foam\n" +
                    "That the Lord has prepared for the true\n" +
                    "Built for you and for me by the beautiful sea\n" +
                    "Oh, I want to live there, don’t you?\n" +  "\n" +

                    "\tCHORUS\n" +
                    "   Oh, I want to live there heaven’s glory to share\n" +
                    "   Praising the languages through\n" +
                    "   In the master’s great fold where we’ll never grow old\n" +
                    "   Oh, I want to live there, don’t you?\n" +
                    "\n" +

                    "Oft in sadness I roam then I want to go home\n" +
                    "But my labor on earth is not through\n" +
                    "So I trudge all along with a song and a smile\n" +
                    "Oh, I want to live there, don’t you?\n" +
                    "\n" +

                    "There, the streets are pure gold. I’ve often been told\n" +
                    "And nobody shall ever be blue\n" +
                    "There’ll be no goodbyes no more sorrow or sigh\n" +
                    "Oh, I want to live there, don’t you?\n"),

            new Eagle( "179. I WON’T TAKE NOTHING FOR MY JOURNEY.\n","I started out travelling for the Lord many years ago\n" +
                    "I met a lot of heartaches; I had a lot of grief and woe\n" +
                    "And when I would stumble then I would humble down\n" +
                    "And I would say ‘thank you Lord’\n" +
                    "I wouldn’t take nothing for my journey now.\n" + "\n" +

                    "\tCHORUS\n" +
                    "   I wouldn’t take nothing for my journey now\n" +
                    "   I got to make it to heaven somehow \n" +
                    "   Though the devil tempts me\n" +
                    "   And tries to turn me around\n" +
                    "   He’s offered everything that’s got a name\n" +
                    "   All the wealth I want and worldly fame if still I wouldn’t take\n" +
                    "   Nothing for my journey now\n" +
                    "\n" +

                    "There is nothing in the world that could ever take the place of God’s love\n" +
                    "Silver and gold could never buy a mighty touch from above\n" +
                    "And when my soul needs healing and I begin to feeling His power,\n" +
                    "That’s when I say, “Thank you Lord, I wouldn’t take nothing for my journey now.”\n" ),

            new Eagle( "180. BE READY FOR TOMORROW.\n","As we travel down this road of life dear brother,\n" +
                    "Do you ever give a thought as you go on?\n" +
                    "You know today’s the day, Oh, brother won’t you pray?\n" +
                    "Be ready for tomorrow may never come.\n" +  "\n" +

                    "\tCHORUS\n" +
                    "   Oh, won’t you listen now dear brother,\n" +
                    "   Don’t ever put off another day\n" +
                    "   You know you’ve got to wait, oh, heed him while you may\n" +
                    "   Be ready for tomorrow may never come.\n" +
                    "\n" +

                    "You know we have no promise of tomorrow,\n" +
                    "Our good book says today’s the day\n" +
                    "Oh, make your peace with God before this road you trod\n" +
                    "Be ready for tomorrow may never come\n" +
                    "\n" +

                    "Don’t forget to stop a while and think it’s over\n" +
                    "Don’t travel on without the love of God\n" +
                    "The road may end today, oh, brother won’t you pray?\n" +
                    "Be ready for tomorrow may never come.\n" ),

            new Eagle( "181. JESUS HELD ON TO  MY HAND.\n","As a child, we were poor\n" +
                    "My soul was so blue\n" +
                    "I wept bitter tear drop alone in my room\n" +
                    "The family circle was broken\n" +
                    "My trouble and sin\n" +
                    "But Jesus held on to my hand\n" + "\n" +

                    "   CHORUS\n" +
                    "   Jesus held on to my hand,\n" +
                    "   Giving me comfort that only he can\n" +
                    "   More than a father, brother or friend\n" +
                    "   But Jesus held on to my hand\n" +
                    "\n" +

                    "At the old time revival,\n" +
                    "They were making the plea\n" +
                    "I joined them in singing, He saw that I need\n" +
                    "He saw that I need\n" +
                    "I felt at the altar, I was dreary to stand\n" +
                    "But Jesus held on to my hand\n" ),

            new Eagle( "182. I NEED YOU MORE TODAY.\n","There are decisions I can’t make on my own\n" +
                    "And there are trials I can’t face all alone\n" +
                    "But you said you’ll walk with me down life’s trouble road\n" +
                    "And you said come on to me, “I’ll bear your heavy load”\n" + "\n" +

                    "   CHORUS\n" +
                    "   I need you more today than I need yesterday\n" +
                    "   Mountains are higher, rivers are wider\n" +
                    "   I need you more today than need yesterday\n" +
                    "   Help me remember I need you more today\n" +
                    "\n" +

                    "When I wake up in the morning and I fear to face the day\n" +
                    "Let me feel your gentle hand leading the way\n" +
                    "Yesterday has come and gone with those trials far behind\n" +
                    "But I’m ever learning Lord and every day I find\n" ),

            new Eagle( "183. HEAVEN.\n","In childhood I heard of a heaven. I wondered if this could be true\n" +
                    "That there’re sweet mansions eternal Somewhere up there beyond the blue.\n" +
                    "I wondered if people really go there. And one day sweet Jesus came in\n" +
                    "And I got a vision of heaven. My soul in all heaven I’ll spend\n" + "\n" +

                    "   CHORUS\n" +
                    "   Heaven (happy home above)\n" +
                    "   Heaven (where there’s peace and love)\n" +
                    "   Oh, it makes me feel like travelling on\n" +
                    "   Heaven (eternal)\n" +
                    "   Heaven (super on and on)\n" +
                    "   I am so glad He is real\n" +
                    "\n" +

                    "Then I got vision of heaven. My soul’s overflowing with love\n" +
                    "My heart like the savior’s broken, for those that will that home above\n" +
                    "And a voice from the hills of Judea, Still ringing words of sweet relief\n" +
                    "Worldly attractions don’t thrill me. My soul stands a castle within\n" ),

            new Eagle( "184. THE LOVE OF GOD.\n","I tried and tried to think of some goods that I’ve done,\n" +
                    "That would give to me the right to claim a kinship to God’s son.\n" +
                    "Could it have been because I tried in every way to see?\n" +
                    "Could it have been because I spend sometimes down on my knees?\n" +
                    "\n" +

                    "Could it have been because my heart was often touched by pain?\n" +
                    "Could it have been because I have often witnessed in His name?\n" +
                    "Or could it be that in the past some precious souls have won?\n" +
                    "I searched my heart and realized it’s nothing I have done.\n" + "\n" +

                    "   CHORUS\n" +
                    "   The love of God defies all understanding of the mind,\n" +
                    "   He chose to walk up Calvary’s hill and died for all men kind.\n" +
                    "   Those ugly scars He bored for me while hanging on the tree,\n" +
                    "   Was the price of my redemption and He did it all for me.\n" +
                    "\n" +

                    "I tried to lend a helping hand to someone on life’s road,\n" +
                    "Shared a simple cup of water with the tired and thirsty souls\n" +
                    "I tried to be to those I meet as gentle as a dove,\n" +
                    "But I’ve never done a single deed that’s worthy of His love.\n" ),

            new Eagle( "185. I WILL RIDE THIS TRAIL ONCE AGAIN.\n","I tell of the wondrous work of The Lord\n" +
                    "That He did in Uganda before the bride\n" +
                    "Where The man of God spoke The word\n" +
                    "Then came forth a squirrel in existence\n" +
                    "\n" +

                    "   CHORUS\n" +
                    "   We are living in the day the prophet spoke of\n" +
                    "   “I will ride this trail once again”\n" +
                    "   For The God of brother Branham is with us\n" +
                    "   Yes, He is The God of brother Maingi\n" +
                    "\n" +

                    "I tell of yet a greater work The Lord did\n" +
                    "In Nairobi when a sister passed on\n" +
                    "When The man of God called her back to life\n" +
                    "Then she sang “Let the Lord have His ways.”\n" +
                    "\n" +

                    "Manifolds are the works of The Lord\n" +
                    "That He did in the various part of the world\n" +
                    "They are testifying of the time\n" +
                    "“I will ride this trail once again.”\n" +
                    "\n" +

                    "Let me remind you brothers of the words\n" +
                    "That brother Branham spoke before he left\n" +
                    "That God may take away His man\n" +
                    "But never shall He take away His spirit.\n" ),

            new Eagle( "186. HELP IS ON THE WAY.\n","A woman in the bible days, her last meal almost gone\n" +
                    "But God sent Elijah to make His word known\n" +
                    "He said woman don’t you worry for god sent me today\n" +
                    "And before you even asked him, help was on the way\n" + "\n" +

                    "   CHORUS\n" +
                    "   Just hold on a little longer help is on the way\n" +
                    "   A brighter day is coming to those who believe and pray\n" +
                    "   Help won’t help tomorrow if you give up today\n" +
                    "   Just hold on a little longer, help is on the way\n" +
                    "\n" +

                    "Troubles of this life come by and burdens get you down\n" +
                    "You think no one is listening, you think no one is around\n" +
                    "Just remember what His word says, to trust Him and obey\n" +
                    "Keep your eyes towards the heavens, help is on the way\n" ),

            new Eagle( "187. VICTORY.\n","Hallelujah what a thought Jesus full salvation brought\n" +
                    "Victory, victory\n" +
                    "Let the power of sin heaven can never fail\n" +
                    "Victory, victory\n" + "\n" +

                    "   CHORUS\n" +
                    "   Victory, victory\n" +
                    "   Hallelujah I am free Jesus give me victory\n" +
                    "   Glory, glory hallelujah\n" +
                    "   He is all in all to me\n" +
                    "\n" +

                    "I am trusting in the Lord and according to His word\n" +
                    "Victory, Victory\n" +
                    "I have peace and joy within since my life is free from sin\n" +
                    "Victory, Victory\n" +
                    "\n" +

                    "Shout your freedom every where His eternal peace declare\n" +
                    "Victory, victory\n" +
                    "Let us sing here below in the face of every foe\n" +
                    "Victory, victory\n" +
                    "\n" +

                    "Let us sing it on that shore when this fleeting life is over\n" +
                    "Victory, victory\n" +
                    "Let us sing ye ransomed throng join the everlasting song\n" +
                    "Victory, victory\n" ),

            new Eagle( "188. HE IS STILL WORKING ON ME.\n","There really ought to be, a sign upon my heart\n" +
                    "Don’t judge me yet, there’s an unfinished job\n" +
                    "But I’ll just be perfect according to his plan\n" +
                    "Fashioned by the master’s loving hand\n" + "\n" +

                    "   CHORUS\n" +
                    "   He’s still working on me, \n" +
                    "   To make me what I ought to be\n" +
                    "   It took him only a week to make the moon and the stars\n" +
                    "   The sun and the earth and the Jupiter and mars\n" +
                    "   How loving and patient he must be\n" +
                    "   He still working on me\n" +
                    "\n" +

                    "In the mirror of his word reflections that I see\n" +
                    "Make me wonder why he never gave up on me\n" +
                    "But he loves me as I am and helps me when I pray\n" +
                    "Remember He is the potter and I’m the clay\n" ),

            new Eagle( "189. ARE YOU AFRAID TO DIE?\n","Are you a stranger to God?\n" +
                    "Carried away with your pride?\n" +
                    "Tell me, sinner, do you ever stop and think.\n" +
                    "Are you afraid to die?\n" +  "\n" +

                    "CHORUS\n" +
                    "Are you afraid, are you unsaved?\n" +
                    "Are you afraid to die?\n" +
                    "\n" +

                    "Call on him while He near,\n" +
                    "Moments are swift passing by,\n" +
                    "Will you seek him while he still may be found?\n" +
                    "Are you afraid to die?\n" +
                    "\n" +

                    "Are you too wicked to cry?\n" +
                    "Would you to God’s bosom fly?\n" +
                    "Soon he’s coming like a thief in the night,\n" +
                    "Are you afraid to die?\n" ),

            new Eagle( "190. LITTLE MOUNTAIN NGONG HOUSE.\n","There is a little mountain Church, \n" +
                    "In my thoughts of yesterday\n" +
                    "Where brothers and sisters gathered for the Lord\n" +
                    "There the man of God Ndolo\n" +
                    "Taught the way of true love \n" +
                    "For what few hours, the congregation could afford\n" +
                    "\n" +
                    "Dressed in an old fashion way\n" +
                    "We sat in seats, of plastic chairs\n" +
                    "I remember how our filled the air\n" +
                    "How the choir sounded like the angels\n" +
                    "In the songs He gave to them\n" +
                    "Get in Christ, a little deeper with love\n" +
                    "\n" +
                    "     CHORUS\n" +
                    "            Looking back now (this)that little mountain  Ngong house\n" +
                    "            Has become, my life’s cornerstone\n" +
                    "            It is (here) there, in (this)that little mountain Gong House\n" +
                    "            I first heard the word, I’ve based my life upon\n" +
                    "\n" +
                    "In the morning at a meeting, great was the love \n" +
                    "Two were the souls, that were, rescued\n" +
                    "How the Lord suspended, death from their way\n" +
                    "For that great love, that He want us to have" ),





            new Eagle( "191. I PLAN TO MEET YOU THERE.\n","When this life is over and the toil is done\n" +
                    "When this journey’s ended and the race is run\n" +
                    "Then I’ll live in heaven with this beauty rare\n" +
                    "Oh, I plan to live you there\n" + "\n" +

                    "   CHORUS\n" +
                    "   Oh, I plan to meet you there (over there)\n" +
                    "   Over in that city that is built four square\n" +
                    "   Over by the river in that land so fare\n" +
                    "   I plan to meet you there\n" +
                    "\n" +

                    "There I’ll see my mansion and the street of gold\n" +
                    "And I’ll hear the angels and the sights untold\n" +
                    "Then I’ll see my Jesus and His glory share\n" +
                    "And I plan to meet you there\n" ),

            new Eagle( "192. GLORIOUS IMPOSSIBLE.\n","See the virgin is delivered in a cold and crowded stall\n" +
                    "Mirror of the father’s glory lies beside her in the straw\n" +
                    "He is mercy incarnation marvel at His miracle\n" +
                    "For the virgin gently holds the glorious impossible\n" +
                    "\n" +

                    "Love has come to walk on water turned the water into wine\n" +
                    "Touch the leper blessed the children\n" +
                    "Love both human and divine\n" +
                    "Praise the wisdom of the father who has spoken through son\n" +
                    "Speaking still—He calls us to come to\n" +
                    "The glorious impossible\n" + "\n" +

                    "   CHORUS\n" +
                    "   Hallelujah ----------     Hallelujah\n" +
                    "   Hallelujah ---------      Glorious impossible\n" +
                    "\n" +

                    "He was bruised for our transgression\n" +
                    "And he bears eternal scars\n" +
                    "He was raised for our salvation and His righteousness is ours\n" +
                    "Praise – or praise him praise the glory\n" +
                    "Of this lavish grace so full\n" +
                    "Lift your soul now and receive the glorious impossible\n" ),

            new Eagle( "193. OVER AND OVER AGAIN.\n","I stood on the banks of a wide raging river, trusting that I'd Get across.\n" +
                    "I've made my way through some valleys and Deserts,\n" +
                    "Believing I'd never get lost.\n" +
                    "I've stood at the foot of What felt like mount Everest,\n" +
                    "knowing I'd have the strength For the climb.\n" +
                    "Is through every trial, each test, temptation,\n" +
                    "There's one thing is sure every time. \n" +
                    "\n" +

                    "            CHORUS\n" +
                    "            Over, and over. Again, and again God is faithful.\n" +
                    "            Over, and over, again, and again through it all.\n" +
                    "            He's made me able.\n" +
                    "            To stand and survive, to come through alive\n" +
                    "            When sure looks like I wouldn't win. \n" +
                    "            Jesus is with me, so I'll claim the victory.\n" +
                    "            Over, and over again.\n" +
                    "\n" +

                    " If you ask me why, I have no hesitation;\n" +
                    "God does what He Says He will do. \n" +
                    "I'd simply say every battle has taught me,\n " +
                    "There's nothing He won’t help me through.\n" +
                    "So why should I Dwell on the hardships and struggles,\n" +
                    "when I look just Beyond them I see.\n" +
                    "The way this will end in a great Celebration,\n" +
                    "Deep in my heart I believe.\n" ),

            new Eagle( "194. WHEN I WAKE UP TO SLEEP NO MORE.\n ","What a glad thought some wonderful morning\n" +
                    "When we hear Gabriel’s trumpet sound\n" +
                    "When I wake up (when I wake up) \n" +
                    "To sleep no more (to sleep no more)\n" +
                    "Leaving behind all troubles and trials\n" +
                    "With a glad shout I’ll leave the ground\n" +
                    "When I wake up (when I wake)\n" +
                    " To sleep no more (to sleep no more)\n" +
                    "\n" +

                    "   CHORUS:\n" +
                    "   When I wake up (some glad morning)\n" +
                    "   To sleep no more (jewels adorning)\n" +
                    "   How happy I’ll be (over in glory)\n" +
                    "   On the beautiful shore (telling the story)\n" +
                    "   With the redeemed of all the ages\n" +
                    "   Praising the one who I adore\n" +
                    "   When I wake up (when I wake up)\n" +
                    "   To sleep no more (to sleep no more)\n" +
                    "\n" +

                    "Glory to God I’ll have a new body\n" +
                    "Changed in the twinkling of an eye\n" +
                    "When I wake up (when I wake up) \n" +
                    "To sleep no more (to sleep no more)\n" +
                    "Rising to meet our blessed redeemer \n" +
                    "Bound for the city up on high\n" +
                    "When I wake up (when I wake up)\n" +
                    "To sleep no more (to sleep no more)\n" ),

            new Eagle( "195. BURDENS ARE LIFTED AT CALVARY.\n","Days are filled with sorrow and care\n" +
                    "Hearts are lonely and drear\n" +
                    "Burdens are lifted at Calvary\n" +
                    "Jesus is now here\n" +
                    "\n" +

                    "   CHORUS\n" +
                    "   Burdens are lifted at Calvary\n" +
                    "   Calvary, Calvary\n" +
                    "   Burdens are lifted at Calvary\n" +
                    "   Jesus is now here\n" +
                    "\n" +

                    "Cast your care on Jesus today\n" +
                    "Leave your worry and fear\n" +
                    "Burdens are lifted at Calvary\n" +
                    "Jesus is now here\n" +
                    "\n" +

                    "Troubled soul, the savior can see\n" +
                    "Every heartache and tear\n" +
                    "Burdens are lifted at Calvary\n" +
                    "Jesus is now here\n" ),

            new Eagle( "196. DON’T  WAIT THE LAST MINUTE TO PRAY.\n","A great day is coming, it’s not far away\n" +
                    "Don’t wait the last minute my brother to pray\n" +
                    "If your soul is danger, if you’ve lost your way\n" +
                    "Don’t wait the last minute my brother to pray\n" + "\n" +

                    "   CHORUS\n" +
                    "   Don’t wait, my brother, don’t wait\n" +
                    "   Don’t wait until it’s too late\n" +
                    "   If your soul is danger, if you’ve lost your way\n" +
                    "   Don’t wait the last minute to pray\n" +
                    "\n" +

                    "A sad day is coming for those who go wrong\n" +
                    "Please listen, my brother, and don’t tarry long\n" +
                    "The good Lord is willing to open the way\n" +
                    "Don’t wait the last minute my brother to pray\n" +
                    "\n" +

                    "Theirs is no charge in heaven for treasures so rare\n" +
                    "The crown that you win when you meet Him up there\n" +
                    "There is no temptation to cause you to stray\n" +
                    "Don’t wait the last minute my brother to pray\n" ),

            new Eagle( "197. GOD, IS BIGGER THAN ANY MOUNTAIN.\n","Bigger than the shadows that falls across my path\n" +
                    "God is bigger than any mountain that I can or cannot see\n" +
                    "He’s bigger than any all the confusion, bigger than anything\n" +
                    "God is bigger than any mountain that I can or cannot see\n" +
                    "\n" +

                    "   CHORUS\n" +
                    "   He’s bigger than all my problems, bigger than all my fears \n" +
                    "   God is bigger than any mountain that I can or cannot see\n" +
                    "   Oh, yes, He’s bigger than all my questions, bigger than anything\n" +
                    "   God is bigger than any mountain that I can or cannot see\n" +
                    "\n" +

                    "He’s bigger than all the giants of pain and unbelief\n" +
                    "God is bigger than any mountain that I can or cannot see\n" +
                    "He’s bigger than any discouragement, bigger than any thing\n" +
                    "God is bigger than any mountain that I can or cannot see\n" ),

            new Eagle( "198. SOMEDAY WE’LL LIVE IN THAT CITY.\n",
                    "Just the other day, as I was walking,\n" +
                    "In a city not built by man,\n" +
                    "I can see the people have fallen,\n" +
                    "In the hands of Satan commands\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tSomeday we live in the city,\n" +
                    "\tWhere the streets are paved with gold,\n" +
                    "\tThere be Joy and peace forever,\n" +
                    "\tIn the new Jerusalem.\n" +
                    "\n" +

                    "And I know that that Jesus is calling,\n" +
                    "Turn away from the fields of sin,\n" +
                    "So then try to enter through the straight gate,\n" +
                    "That the lamb of God of has prevailed.\n" ),

            new Eagle( "199. I LIKE THE PRESENT TENSE GOD.\n","People of today, have drifted far from God\n" +
                    "And are wondering without knowing,\n" +
                    "Where to meet Christ, the perfect place to be\n" +
                    "And, to abide today\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI like the Present Tense God, (hallelujah)\n" +
                    "\tHe is the same Lord Jesus Christ, (praise His Holy name)\n" +
                    "\tHe speak through a man today, as He did and does\n" +
                    "\tI like the Present Tense God\n" +
                    "\n" +

                    "When a prophet leaves the scene, the spirit of the Lord,\n" +
                    "Moves on from man, to a man\n" +
                    "To take the message for, the spirit never dies\n" +
                    "I like the Present Tense God\n" +
                    "\n" +

                    "The Lord Jesus chosen way is to speak the gospel through one man\n" +
                    "He is doing the same today amazingly, \n" +
                    "Speaking the word of life, needed in this hour.\n" +
                    "Never a man can speak like the Present Tense God" ),

            new Eagle( "200. AND TODAY IN AFRICA.\n","As told before by Brother Branham, \n" +
                    "“I’ll ride this trail once again.”\n" +
                    "This prophecy has come to pass\n" +
                    "And today we have the Lord.\n" +
                    "\n" +
                    "\tCHORUS:\n" +
                    "\tAnd today(In our day),\n" +
                    "\tIn Africa(In Africa)\n" +
                    "\tThe Lord Jesus is walking in a man,\n" +
                    "\tAnd today(In our day), \n" +
                    "\tIn Africa(In Africa)\n" +
                    "\tThe Lord Jesus is walking in a man.\n" +
                    "\n" +
                    "The sick are healed, \n" +
                    "Many souls are saved,\n" +
                    "While here on earth He did,\n" +
                    "The truth is told to everyone,\n" +
                    "And warned to “sin no more”\n" +
                    "\n" +
                    "He promised us that, \n" +
                    "“He will be with us,\n" +
                    "Until the end of the day.”\n" +
                    "His promise has never failed,\n" +
                    "And today, He’s yet with us.\n" ),

            new Eagle( "201. INE INDINYADA NDI.\n","   Ena amanyanda ndi chuma chawo,\n" +
                    "   Ine ndinyada ndi, Yesu wanga x 2.\n" +
                    "\n" +
                    "\tCHORUS:\n" +
                    "\tNdinyada ndinyanda ndi Yesu wanga,\n" +
                    "\tIne ndinyada ndi Yesu wanga.\n" +
                    "   \n" +
                    "    Ena amanyanda ndi nyumba zawo,\n" +
                    "    Ine ndinyada ndi Yesu wanga.\n" +
                    "\n" +
                    "    Ena amanyada ndi afiti,\n" +
                    "    Ine ndinyada ndi Yesu wanga.\n" +
                    "\n" +
                    "   Ena amanyada ndi ma Benzi awo,\n" +
                    "   Ine ndi nyada ndi Yesu wanga." ),

            new Eagle( "202. AKHALE WODALA.\n","         Pamene Yesu analowa mumzinda,\n" +
                    "        Yelusalemu, muzinda wa ukulu\n" +
                    "        Ana angono anayemba kukuwa\n" +
                    "        Akhale wodala mwana wa Dadid x 2\n" +
                    "\n" +
                    "\tCHORUS:\n" +
                    "\tAkhale wodala anayemba kuyimba x 4\n" +
                    "\n" +
                    "     Pamene Odello anayemba kuyimba,\n" +
                    "     Kuyimba kuja, kuyimba kwa kumwamba\n" +
                    "     Ziwanda zonse  zinayemba kuthawa\n" +
                    "     Akhale wodala mwana wa David x 2" ),


            new Eagle( "203. DAVID SLING.\n","      Davide mnyamatayo anali olimba,\n" +
                    "        Davide anangokhala mchinda chaponyela\n" +
                    "        Davide mnyamatayo napita kutsinje\n" +
                    "        Davide anangotola miyala isanu\n" +
                    "        Naiika mwala umodzi mchoponyelach\n" +
                    "        Nadzungulitsadi dzunguli   dzunguli  dzunguli\n" +
                    "        Kamwala vii pamphumi kho\n" +
                    "        Chiwinda chinagwa woyolo woyolo woyolo.\n" ),

            new Eagle( "204. HELP IS ON THE WAY.\n","The woman in  the Bible days,\n" +
                    "Her last meal was almost gone,\n" +
                    "But God sent Elijah to make His Word known,\n" +
                    "He said, “woman, don’t  you worry,for God sent me today”\n" +
                    "Before you even ask Him, help was on the way.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tJust hold on, a little longer,\n" +
                    "\tHelp is on the way,\n" +
                    "\tA brighter day is coming,\n" +
                    "\tFor those who believe,\n" +
                    "\tHelp won’t help tomorrow\n" +
                    "\tIf you give up today.\n" +
                    "\tJust hold on a little longer, \n" +
                    "\t‘Cause help is the way.\n" +
                    "\n" +

                    "Troubles of this life come by,\n" +
                    "And burdens turn you down,\n" +
                    "You think no one is listening,\n" +
                    "You think no one’s around.\n" +
                    "Just remember what is word say,\n" +
                    "“Trust Him and obey”\n" +
                    "Just hold on a little longer \n" +
                    "Cause help is on way.\n" +
                    "\n" ),

            new Eagle( " 205. DO YOU LIVE WHAT YOU PREACH?\n","Many prophets are here as a witness for God,\n" +
                    "Many churches now they represent.\n" +
                    "And if you’ve been redeemed, you’ll know whom God sent\n" +
                    "For we know by their fruits whom they serve.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tDo you live what you preach?\n" +
                    "\tWould you preach what you live?\n" +
                    "\tIn the presence of God could you stand\n" +
                    "\tJesus knows every deed, good or bad from your birth\n" +
                    "\tDo you live what preach in your church.\n" +
                    "\n" +

                    "Some may stand in their church and proclaim they love,\n" +
                    "And may win earthly fame in their speech\n" +
                    "If they love not their brother indeed and in truth,\n" +
                    "The right hand of God they will never reach.\n" +
                    "\n" +
                    "\n" +

                    "If your heat don’t out in the service of God\n" +
                    "Then you’re lost with the sinners on earth\n" +
                    "If you have on desire to be honest with God,\n" +
                    "You don’t live what you preach in your church." ),


            new Eagle( "206. HE TOOK YOUR PLACE.\n","Upon the rugged cross of Calvary,\n" +
                    "Was there my blessed Saviour cried\n" +
                    "“Forgive them for they know not what they do”\n" +
                    "Oh, sinner friend, for thee He died.\n" +
                    "\n" +
                    "\tCHORUS:\n" +
                    "\tHis hands are gently knocking on your door,\n" +
                    "\toutside He’s pleading to come in,\n" +
                    "\tHis heart is breaking as  He waits for you.\n" +
                    "\tTo wash you free from every sin.\n" +
                    "\n" +

                    "Someday He’s coming back to claim His own,\n" +
                    "We’ll fly to Heaven’s golden shore,\n" +
                    "A crown of life He gives on that glad day,\n" +
                    "With Him we’ll live forever more.\n" +
                    "\n" +
                    "\n" +
                    "Those cruel thorns they, pierced my Saviour head,\n" +
                    "The blood was flowing down His face,\n" +
                    "In shame, forsaken there He hung and died.\n" +
                    "Oh, sinner friend, He took your place." ),

            new Eagle( "207. HE GIVETH MORE GRACE\n","He giveth more grace when our burdens grow greater,\n" +
                    "He sendeth more strength as our labours increase;\n" +
                    "To added afflictions, He added His Mercy,\n" +
                    "To multiplied trials, He multiplies peace.\n" +
                    "\n" +
                    "\tCHORUS:\n" +
                    "\tHis love has  no limits, His grace has more measures,\n" +
                    "\tHis power, no boundary known unto men;\n" +
                    "\tFor out of His infinite riches in Jesus,\n" +
                    "\tHe giveth , and giveth, and giveth again.\n" +
                    "\n" +
                    "When we have exhausted our store of endurance,\n" +
                    "When our strength has failed, ere the day is half done.\n" +
                    "When we reach the end of our hoarded resources,\n" +
                    "Our father’s full giving is only begun.\n" +
                    "\n" +
                    "For not that thy need shall exceed His provision,\n" +
                    "Our God ever yearns, His resources to share,\n" +
                    "Lean hard on the arms everlasting, availing\n" +
                    "The Father both thee and thy load will upbear." ),


            new Eagle( "208. I WANT TO STROLL OVER HEAVEN WITH YOU.\n","If I surveyed all the good things that come to me from above,\n" +
                    "If I count all the blessings from the store house of love,\n" +
                    "I’d would simply ask of  a favour of Him beyond mortal king\n" +
                    "And I’m sure that He’d grant it again.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI want to stroll over heaven with you some glad day,\n" +
                    "\tWhen all the troubles and heartaches are vanished away,\n" +
                    "\tThen we’ll enjoy the beauty where all things a new,\n" +
                    "\tI want to stroll over Heaven with you.\n" +
                    "\n" +

                    "So many places, of beauty we long to see here below,\n" +
                    "But time and treasures have kept us from making plans as you know.\n" +
                    "But come the morning of  the rapture,\n" +
                    "Together we’ll stand anew,\n" +
                    "While I stroll over Heaven with you.\n" ),

            new Eagle( "209. I AM REDEEMED.\n","CHORUS:\n" +
                    "\tI am Redeemed, bought with a price,\n" +
                    "\tJesus Has changed my whole life,\n" +
                    "\tIf anybody ask you, Just who I am,\n" +
                    "\tI want you tell them, that I am Redeemed.\n" +
                    "\n" +
                    "Where there was there hate, Love now abide,\n" +
                    "Where there was confusion,  Peace now reigns.\n" +
                    "I’m walking with Jesus, I’m a child of a king,\n" +
                    "And from sin my Lord set me." ),

            new Eagle( "210. I’M NOT THE MAN I USED TO BE.\n","In a letter from apostle Paul,\n" +
                    "He confessed to one and all,\n" +
                    "That’s the spirit is strong\n" +
                    "And the flesh is awfully weak.\n" +
                    "Things I should do, I don’t\n" +
                    "And my God begun a work that one day be complete.\n" +
                    "\n" +
                    "\tCHORUS:\n" +
                    "\t    And I Know, I’m not the man that I ought to be,\n" +
                    "\t    Many times I fall short, of what you want of me,\n" +
                    "\t    And I’m surely not the man, that I want to be\n" +
                    "\t    But thank God I’m not the man I used to be\n" +
                    "\n" +
                    "Just like Paul of old, I keep pressing toward the goal\n" +
                    "Forgetting all the things that lie behind\n" +
                    "And instead I look ahead and I go where I’m led\n" +
                    "Toward the mark for the price that will be mine\n" ),

            new Eagle( "211. SOMEDAY MY SHIP WIIL SAIL\n","Life is just a passing moment,\n" +
                    "On a never ending trail,\n" +
                    "Though my pathway wonders for a while, \n" +
                    "Someday my ship will sail\n" +
                    "\n" +

                    "           CHORUS\n" +
                    "                 And I will walk this road a while\n" +
                    "                 I will walk it with a smile\n" +
                    "                 And I will take it in my stride \n" +
                    "                 Someday I’ll be satisfied\n" +
                    "\n" +

                    "There’s eternity before me, \n" +
                    "Just beyond the darkening veil,\n" +
                    "Though my goes weary to go on,\n" +
                    "Someday my ship will sail.\n" ),

            new Eagle( "212. HARVEST IS PAST.\n","The leaves are falling, harvest is past\n" +
                    "So it is in the spirit, the end is coming fast\n" +
                    "The time will soon be here, when Jesus Christ shall come\n" +
                    "So, lift up your head your redemption is drawing nigh\n" +
                    "\n" +
                    "      CHORUS\n" +
                    "         It will be, too late, my brother then, to pray\n" +
                    "         Don’t put off till tomorrow, what you can do today,\n" +
                    "         And you’ll find yourself in judgement\n" +
                    "         And you have to pay\n" +
                    "         For the opportunity that has come your way\n" +
                    "\n" +
                    "It’s gleaning time the reapers, are in the field\n" +
                    "To find the last of the seed the others will not yield\n" +
                    "And the glory of god will shine for it’s evening time\n" +
                    "And the true bride of christ will soon fall into line\n" ),

            new Eagle( "213. HE TOUCHED ME.\n","Shackled by a heavy burden\n" +
                    "Neath the load of guilty of shame\n" +
                    "And the hand of Jesus touched me\n" +
                    "And now I’m no longer the same\n" +
                    "\n" +
                    "        CHORUS\n" +
                    "        He touched me, Oh! He touched me\n" +
                    "        And Oh! What a joy that floods my soul\n" +
                    "        Something happened, and now I know\n" +
                    "        He touched me and made whole\n" +
                    "\n" +
                    "Oh! since I met this blessed saviour\n" +
                    "Since He cleansed and made me whole\n" +
                    "I’ll never cease to praise Him \n" +
                    "I’ll shout it while eternity rolls\n" ),

            new Eagle( "214. LORD, I’M READY TO GO HOME.\n","Through the valleys of this life, I have wondered\n" +
                    "And I’ve worked for Jesus all along the way,\n" +
                    "And now I see the sun for me is setting,\n" +
                    "I have reached the ending of the road.\n" +
                    "\n" +
                    "        CHORUS\n" +
                    "              Lord, I’ve been faithful in the service you have given\n" +
                    "              And the harvest of the field, Lord I have done\n" +
                    "              And now,, my steps are getting weary\n" +
                    "              Lord, I’m waiting, I’m ready to go home\n" +
                    "\n" +
                    "Looking back upon the life, I’ve lived for Jesus,\n" +
                    "I can see how He has helped me all the way,\n" +
                    "And the tears I’ve shed just helped to keep me humbled,\n" +
                    "And each burdened only taught me how to pray.\n" +
                    "\n" +
                    "Though I hate to leave so many friends, behind me,\n" +
                    "And the parting of our way, will touch my heart,\n" +
                    "But I’ll wait, for them, inside the gate of heaven, \n" +
                    "Where the children of God will never part.\n" ),

            new Eagle( "215. LOOK FOR ME AT JESUS FEET.\n","When I leave this world of sorrow, sometime before you do\n" +
                    "Just look for me in heaven and we’ll talk the ages through\n" +
                    "And when at first, you failed to see me, let me tell you where I’ll be\n" +
                    "I’ll be thanking Christ, my saviour, for saving a wretch like me\n" +
                    "\n" +
                    "        CHORUS\n" +
                    "           Don’t wait neath the gates of Pearls, \n" +
                    "           Don’t wait on the streets of gold\n" +
                    "           Don’t wait by the walls of jasper, \n" +
                    "           Nor among the many sites untold. \n" +
                    "           For I’ve been longing, and I’ve been waiting, \n" +
                    "           For the precious, holy one to meet\n" +
                    "           There’ll be through the countless ages, \n" +
                    "           Wait for me at Jesus feet\n" +
                    "\n" +
                    "And when you should, reach that city, before my time has come\n" +
                    "Perhaps you’d like to greet me, when my race down here is run\n" +
                    "Just wait, for i’ll soon, be coming, across life’s ebbing sea\n" +
                    "And I’ll tell you now my brother, just where to wait for" ),

            new Eagle( "216. JESUS, PILOT MY SHIP.\n","The soul of man, is like a ship,\n" +
                    "That sails n the sea of time\n" +
                    "Storms may come, winds may blow, \n" +
                    "And rock this ship of mine\n" +
                    "But the reason my ship has never sank, \n" +
                    "And today is still afloat\n" +
                    "My compass in, His precious Hand, \n" +
                    "And Jesus pilot my ship\n" +
                    "\n" +
                    "       CHORUS\n" +
                    "            I won’t sail this stormy seas no more, \n" +
                    "            Unless Jesus leads the way\n" +
                    "            I won’t ever drift, so far from the shore, \n" +
                    "            If I can’t hear what He has to say\n" +
                    "            For I belong to a fleet that sails today, \n" +
                    "            On a glorious one way trip\n" +
                    "            We’ll land safely on the shore to sail no more\n" +
                    "            For Jesus, pilots my ship\n" +
                    "\n" +
                    "My soul pulled in, to safety’s port,\n" +
                    "My stern was torn apart\n" +
                    "The bow of my vessel, so badly crushed,\n" +
                    "Sin waters flooded my heart\n" +
                    "I travelled so long on life’s angry waves,\n" +
                    "With my cargo of fear and despair\n" +
                    "Then I called on name and He lifted the blame,\n" +
                    "Now He pilots my ship everywhere.\n" ),

            new Eagle( "217. THERE IS REST BY AND BY.\n","Often weary and worn, on the pathway below\n" +
                    "When the burden is heavy and my heart throbs with woe\n" +
                    "Oh there comes a sweet whisper, to quell ev’ry sigh\n" +
                    " Do not faint ‘neath the load, there is rest by and by\n" +
                    "\n" +
                    "         CHORUS\n" +
                    "             There is rest by and by\n" +
                    "             In the beautiful city, there is rest by and by\n" +
                    "             Where the ransomed shall live, with the saviour on high\n" +
                    "             In the beautiful city, there is rest by and by\n" +
                    "\n" +
                    "You will not labour long for the master below\n" +
                    "Soon His call you will hear, your free spirit will go\n" +
                    "To the light of His presence in mansions on high\n" +
                    "Where the faithful repose, there is rest by and by\n" +
                    "\n" +

                    "Then, dear saviour, I would not in sadness repine\n" +
                    "Nor would here on a sweet bed of roses recline\n" +
                    "For a country I seek where they nevermore die\n" +
                    "And in Zion my home, there is rest by and by\n" ),

            new Eagle( "218. I WANT TO THANK HIM FOR WHAT HE HAS DONE.\n","Someday I shall stand in God’s city\n" +
                    "To receive the bright treasure i’ve won \n" +
                    "But how can I ever accept them\n" +
                    "Til I thank Him for what He done\n" +
                    "\n" +
                    "           CHORUS\n" +
                    "                When I thank Him for what He has done \n" +
                    "                I must look back to the crucified one\n" +
                    "                On that beautiful shore, I must kneel once more\n" +
                    "                Just to thank Him for what He has done\n" +
                    "\n" +
                    "They say there will be no more sighing\n" +
                    "In that city, when life’s race is run\n" +
                    "But how can I keep from crying\n" +
                    "When I thank Him for what He has done\n" +
                    "\n" +
                    "Before I can shout Hallelujah\n" +
                    "Before I can sing that sweet song\n" +
                    "I must kneel at the feet of Jesus\n" +
                    "And thank Him for what He has done\n" ),

            new Eagle( "219. I’M GONNA GET GET CARRIED.\n","CHORUS:\n" +
                    "                 I’m gonna get let the Glory roll \n" +
                    "                 When the roll is called in Glory\n" +
                    "                 I’ll gonna get beside myself when I get beside \n" +
                    "                 The King that day\n" +
                    "                 I’m gonna have the time of my life \n" +
                    "                 When the time of my life is over\n" +
                    "                 I’m gonna get carried away, \n" +
                    "                 When I get carried away\n" +
                    "\n" +
                    "Well, I don’t know why I become a little shy \n" +
                    "When I get around a whole lotta people\n" +
                    "And I can’t figure out why I never can shout\n" +
                    "About the love that floods my soul\n" +
                    "Well, I must confess, I can’t express\n" +
                    "The feelings deep inside me\n" +
                    "But the things I know and cannot show,\n" +
                    "One day will overflow\n" +
                    "\n" +
                    "Oh, I’ll pass the clouds and shout so loud,\n" +
                    "It may sound like thunder\n" +
                    "My tearful eyes may fill the skies, \n" +
                    "Until it looks like rain\n" +
                    "When I leave this world past the gates of pearl\n" +
                    "And stand before my saviour\n" +
                    "I’ll let my soul let the Glory roll\n" +
                    "When from the roll He calls my name \n" ),

            new Eagle( "220. THE FOURTH MAN.\n" ,"Here is a story \n" +
                    "From the good book we know,\n" +
                    "A story about a miracle\n" +
                    "That happened long ago,\n" +
                    "We hope that you’ll take courage\n" +
                    "When temptation you meet\n" +
                    "There’s somebody watching you \n" +
                    "Who’s strong when you’re weak\n" +
                    "\n" +
                    "             CHORUS\n" +
                    "                  They wouldn’t bend\n" +
                    "                  They held on to the will of God so we are told\n" +
                    "                  They wouldn’t bow\n" +
                    "                  They would not bow their knee to the idol made of gold\n" +
                    "                  They wouldn’t burn\n" +
                    "                  They were protected by the fourth man in the fire\n" +
                    "                  They wouldn’t bend\n" +
                    "                  They wouldn’t bow \n" +
                    "                  They wouldn’t burn\n" +
                    "\n" +
                    "Now the prophet Daniel tells about\n" +
                    "Three men who walked with God\n" +
                    "Shadrach, Meshach and Abednego\n" +
                    "Before the wicked king they stood\n" +
                    "And the king commanded them \n" +
                    "Bound and thrown in the fiery furnace that day\n" +
                    "But the fire was so hot \n" +
                    "That the men were slain\n" +
                    "Who forced then on their way\n" +
                    "\n" +

                    "Now when the few were thrown and the king \n" +
                    "Rose up to witness this awful fate,\n" +
                    "He began to tremble at what he saw\n" +
                    "And in astonished tones he spake\n" +
                    "\n" +

                    "Did we not cast three men boundary\n" +
                    "Into the midst of that fire,\n" +
                    "Well though I see four men unhurt\n" +
                    "Unbound and waking down there\n" +
                    "\n" +

                    "There’s is Shadrach, Meshach and Abednego\n" +
                    "An’ the fiery coals they trod\n" +
                    "And the form of the fourth man\n" +
                    "That I see is like the son of God\n"),

            new Eagle( "221. YESU NE HAME.\n","Yesu ne hame changa kiya hai x 4\n" +
                    "\n" +
                    "         CHORUS\n" +
                    "                Is liye ham gayege, sab ko btayege\n" +
                    "                Ekhi raja Yesu masih hai x 2\n" +
                    "                Hallelujah Amen Hallelujah  x 4\n" +
                    "\n" +
                    "Yesu ne hame azad kiya hai x 4\n" +
                    "\n" +

                    "Yesu ne annad kiya hai x 4\n" ),

            new Eagle( "222. WE WOULD KNEEL DOWN","When I was out in sin, we went to Church on one day\n" +
                    "In the Ngong Hill house, the chosen place,\n" +
                    "We didn’t have nothing fancy\n" +
                    "And it must have been something about that place\n" +
                    "People came from miles around\n" +
                    "There was Present Tense singing and testifying \n" +
                    "And, dinner in the house\n" +
                    "\n" +
                    "          CHORUS\n" +
                    "                 And we wouldn’t\n" +
                    "                 Kneel down give our heart to Jesus\n" +
                    "                 For He’s the one to save our soul\n" +
                    "                 We’d kneel down \n" +
                    "                 Give our heart to Jesus \n" +
                    "                 We knew He’s come, and He’s in a man\n" +
                    "\n" +
                    "Oh! my don’t you know how people have changed, \n" +
                    "Since that Church at the Ngong Hill\n" +
                    "They got back to life, pressing less much harder \n" +
                    "And they don’t have church on Sunday\n" +
                    "They got fancy cloth and fancy life,\n" +
                    "They act like they don’t have a care, \n" +
                    "And they got time to go for their work \n" +
                    "But they don’t have time for prayer\n" +
                    "\n" +

                    "Well the Bible is just as true as today\n" +
                    "As it was back then\n" +
                    "It’s church that drifted far away, out in the sea of sin\n" +
                    "When the old time religion is in your soul\n" +
                    "You’ll receive the one He sent,\n" +
                    "For God don’t think each day the same,\n" +
                    "Oh! brother, we must repent\n" ),

            new Eagle( "223. WAIT FOR THE LIGHT TO SHINE.\n","When the road is rocky, and you’re carrying the load\n" +
                    "Wait for the light to shine\n" +
                    "When you find you’re friendless on that weary lonesome road’\n" +
                    "Wait for the light to shine.\n" +
                    "           Wait for the light to shine (shine, shine)\n" +
                    "           Wait for the light to shine\n" +
                    "           Pull yourself together and keep looking for a sign\n" +
                    "           Wait for the light to shine\n" +
                    "\n" +
                    "Don’t forget your brother as you travel through this land\n" +
                    "Wait for the light to shine\n" +
                    "He may be in trouble and may need a helping hand\n" +
                    "Wait for the light to shine\n" +
                    "           Wait for the light to shine (shine, shine)\n" +
                    "           Wait for the light to shine\n" +
                    "           Never give hope or cast your pearls and pour wine\n" +
                    "           Wait for the light to shine\n" +
                    "\n" +
                    "Don’t let trouble fool you and your sin will be gone\n" +
                    "Wait for the light to shine\n" +
                    "Don’t forget his darkness just before the break of dawn\n" +
                    "Wait for the light to shine\n" +
                    "          Wait for the light to shine (shine, shine)\n" +
                    "          Wait for the light to shine\n" +
                    "          Keep these words on your mind as you walk the narrow line\n" +
                    "          Wait for the light to shine" ),

            new Eagle( "224. HELP ME LORD, TO DO THE THINGS YOU WANT ME TO DO.\n","The road of life is dangerous,\n" +
                    "Temptations pull us strong.\n" +
                    "I try to do the best I can,\n" +
                    "And not for a very long.\n" +
                    "A few short steps, all it takes,\n" +
                    "To take the path of sin,\n" +
                    "And I know if astray I may not reach the road again.\n" +
                    "\n" +


                    "\tCHORUS:\n" +
                    "\tHelp me Lord, to do the things you know you want me to,\n" +
                    "\tI’m weary of these struggles, My strength is nearly gone,\n" +
                    "\tI need your arms to lean upon, so I won’t go astray,\n" +
                    "\tHelp me Lord to walk the straight and narrow way.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Our blessed Saviour died upon, the Cross at Calvary,\n" +
                    "His life, He gave that He might save a sinner such as me,\n" +
                    "I want to do the best I can, to walk the path He trod,\n" +
                    "And find my place through Heaven’s gate besides the throne of God." ),


            new Eagle( "225. ANGA MACALO IN.\n", "Onongo atye kayoke, wot i col piny  Rwot me gum in imara,\n" +
                    "I yabo wanga, imiyo aneno, Rwot me gum imiyo alare.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tAnga macalo in, ai Yecu, Rwot me gum in imara,\n" +
                    "\tI yabo wanga imiyo aneno, Rwot me gum imiyo alare.\n" +
                    "\n" +
                    "Kadi lobo cayi, dok gi-kweri, Rwot me Gum an ajoli,\n" +
                    "Gin ma itiyo i-kwona dit atika, Rwot me gum imiyo alubi.\n" +
                    "\n" +
                    "I lanebi meri, i-kane kunu, Rwot me gum dong aneni,\n" +
                    "I lanebi meri, itye ka pyonya, Rwot me gum imiyo apwonye.\n"),


            new Eagle( "226. ANCHORED IN LOVE.","I found a sweet haven of sunshine at last\n" +
                    "And Jesus abiding above\n" +
                    "His dear arms around me are lovingly cast\n" +
                    "And sweetly He tells His love\n" +
                    "\n" +
                    "         CHORUS\n" +
                    "                The tempest is over\n" +
                    "                I’m saved evermore\n" +
                    "                What gladness what rapture is mine\n" +
                    "                The danger is past \n" +
                    "                I’m anchored at last \n" +
                    "                I’m anchored in love divine\n" +
                    "\n" +
                    "He saw me endangered and lovingly came\n" +
                    "To pilot my storm beaten soul\n" +
                    "Sweet peace He has spoken and blest His dear name\n" +
                    "The billows no longer roll\n" +
                    "\n" +

                    "His love shall control me through life evermore\n" +
                    "Completely I’ll trust to the end\n" +
                    "I’ll praise Him each hour of my last fleeting breath\n" +
                    "Shall sing of my soul best friend\n" ),


            new Eagle( "227. I’LL SOON BE GONE","I’ll soon be gone I’ll soon be gone\n" +
                    "I’ll soon be home\n" +
                    "I’ll leave the troubles of this world\n" +
                    "Nevermore to roam\n" +
                    "I’ll join the saints who’ve gone before\n" +
                    "In that heavenly home\n" +
                    "\n" +
                    "\n" +
                    "I’ll soon be gone I’ll soon be gone\n" +
                    "I’ll soon be home\n" +
                    "I’ll leave the troubles of this world\n" +
                    "Nevermore to roam\n" +
                    "I’ll join the saints who’ve gone before\n" +
                    "And forever living in that beautiful home\n" +
                    "Called sweet Beulah Land." )







    };

    public Eagle(String eagle_title, String eagle_lyrics) {
        this.eagle_title = eagle_title;
        this.eagle_lyrics = eagle_lyrics;
    }

    public String getEagle_title() {
        return eagle_title;
    }

    public String getEagle_lyrics() {
        return eagle_lyrics;
    }
    public String toString(){
        return this.eagle_title;
    }
}
