package com.example.joelcrawford.starbuzz;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;


public class PresentTenseCategoryActivity extends AppCompatActivity {
    private ListView listView;
    private MenuItem searchMenuItem;
    private SearchView searchView;
    private ArrayAdapter<PresentTense> listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );

        setContentView(R.layout.activity_category);
        listView = findViewById(R.id.listview);

        listAdapter = new ArrayAdapter<PresentTense>( this,
                R.layout.row_layout_category, R.id.rowTextView,
                PresentTense.presentTenses );

        listAdapter.setNotifyOnChange(true);
        listView.setAdapter( listAdapter );

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String selectedItem = ((PresentTense)listView.getItemAtPosition(i)).getPresent_title();
                Intent intent= new Intent( PresentTenseCategoryActivity.this,PresentTenseActivity.class );
                intent.putExtra( PresentTenseActivity.EXTRA_PRESENT_NO, selectedItem );
                startActivity( intent );
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchMenuItem = menu.findItem(R.id.search);
        searchView = (SearchView) searchMenuItem.getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setSubmitButtonEnabled(true);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                listAdapter.getFilter().filter(s);
                return true;
            }
        });

        return super.onCreateOptionsMenu(menu);

    }
}
