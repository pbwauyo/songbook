package com.example.joelcrawford.starbuzz;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class PresentTenseActivity extends Activity {

    public static final String EXTRA_PRESENT_NO = "present_NO";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_present_tense );

        //get lyrics from intent

        String presentName = (String) getIntent().getExtras().get( EXTRA_PRESENT_NO );
        PresentTense presentTense= PresentTense.presentTenses[getPresentTensePosition(presentName)];


        //populate the title
//      TextView present_title= (TextView) findViewById( R.id.present_title );
//        present_title.setText( PresentTense.getPresent_title() );


        //populate the lyrics
        TextView present_words = (TextView) findViewById( R.id.present_words );
        present_words.setText( presentTense.getPresent_words() );

    }

    int getPresentTensePosition(String name){
        int position = 0;
        for(int i=0; i<PresentTense.presentTenses.length; i++){
            if(PresentTense.presentTenses[i].getPresent_title().equals(name)){
                position = i;
                break;
            }
        }
        return position;
    }
}
