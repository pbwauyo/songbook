package com.example.joelcrawford.starbuzz;



public class TenMajor {

    private String title;
    private String lyrics;


//tenMajors is an arry of TenMajor
    public static final TenMajor[] tenMajors ={
            new TenMajor( "1. NEAR THE CROSS\n","1.NEAR THE CROSS\n" + "\n" +
                    "Jesus, keep me near the cross,\n" +
                    "There a precious fountain, \n" +
                    "Free to all, a healing stream,\n" +
                    "Flows from Calvary’s mountain.\n" +
                    "\n" +

                    "\tCHORUS: " + "\n" +
                    "\tIn the cross, in the cross,\n" +
                    "\tBe my glory ever,\n" +
                    "\tTill my ruptured soul shall find,\n" +
                    "\tRest beyond the river.\n" +
                    "\n" +

                    "Near the cross, a trembling soul\n" +
                    "Love and mercy found me,\n" +
                    "There the Bright and Morning star,\n" +
                    "Sheds its beams around me.\n" +
                    "\n" +

                    "Near the cross! O lamb of God,\n" +
                    "Bring its scene before me,\n" +
                    "Help me walk from day to day,\n" +
                    "With its shadows o’er me.\n" +
                    "\n" +

                    "Near the cross I’ll watch and wait,\n" +
                    "Hoping trusting ever,\n" +
                    "Till I reach the golden strand,\n" +
                    "Just beyond the river.\n" ),


        new TenMajor( "2. THE GREAT PHYSICIAN\n","2. THE GREAT PHYSICIAN\n" + "\n" +
                "The great physician now is near,\n" +
                "The sympathizing Jesus,\n" +
                "He speaks the drooping heart to cheer,\n" +
                "Oh, hear the voice of Jesus,\n" +
                "\n" +

                "\tCHORUS: " + "\n" +
                "\tSweetest note in seraph song,\n" +
                "\tSweetest name on mortal tongue,\n" +
                "\tSweetest carol ever sung,\n" +
                "\tJesus, blessed Jesus.\n" +
                "\n" +

                "Your many sins are all forgiven,\n" +
                "Oh, hear the voice of Jesus,\n" +
                "Go on your way in peace to heaven,\n" +
                "And wear a crown with Jesus.\n" +
                "\n" +

                "All glory to the dying Lamb!\n" +
                "I now believe in Jesus,\n" +
                "I love the blessed Saviour’s name,\n" +
                "I love the name of Jesus.\n" + "\n" +

                "His name dispels may guilt and fear\n" +
                "No other name but Jesus,\n" +
                "O how my soul delight to hear,\n" +
                "The charming name of Jesus." ),

        new TenMajor( "3. HOW GREAT THOU ART\n" ,"3. HOW GREAT THOU ART\n" + "\n" +
                "O Lord my God! When I in awesome wonder,\n" +
                "Consider all the world thy hands have made,\n" +
                "I see the stars, I hear the rolling thunder,\n" +
                "Thy pow’r throughout the universe displayed.\n" +
                "\n" +

                "\tCHORUS: " + "\n" +
                "\tThen sings my soul, my Saviour God to thee,\n" +
                "\tHow great thou art. How great thou art,\n" +
                "\tThen sings my soul, my Saviour God to thee,\n" +
                "\tHow great thou art. How great thou art,\n" +
                "\n" +

                "When through the woods and forest glades I wonder,\n" +
                "And hear the birds sing sweetly in the trees,\n" +
                "When I look down from lofty mountain grandeur\n" +
                "And hear the brook and feel the gentle breeze.\n" +
                "\n" +

                "And when I think that God His son not sparing,\n" +
                "Sent Him to die, I scarce can take it in,\n" +
                "That on the cross, my burden gladly bearing,\n" +
                "He bled and died to take away my sins.\n" +
                "\n" +

                "When Christ shall come, with shout of acclamation,\n" +
                "And take me home, what joy shall feel my heart,\n" +
                "Then I shall bow in humble adoration,\n" +
                "And there proclaim, my God how great thou art.\n"),

        new TenMajor( "4. WHAT A FRIEND WE HAVE IN JESUS\n","4. WHAT A FRIEND WE HAVE IN JESUS\n" + "\n" +
                "What a friend we have in Jesus, all our sins and grief to bear!\n" +
                "What a privilege to carry, everything to God in prayer!\n" +
                "Oh, what peace we often forfeit, O what needless pain we bear,\n" +
                "All because we do not carry, everything to God in prayer.\n" +
                "\n" +

                "Have we trials and temptations? Is there trouble any where?\n" +
                "We should never be discouraged, take it to the Lord in prayer.\n" +
                "Can we find a friend so faithful, who will all our sorrows share,\n" +
                "Jesus knows our every weakness, take it to the Lord in prayer.\n" +
                "\n" +

                "Are we weak and heavy laden, cumbered with a load of care \n" +
                "Precious Saviour still our refuge, take it to the Lord in prayer.\n" +
                "Do thy friends despise forsake thee? Take it to the Lord in prayer,\n" +
                "In His arms He’ll take and shield thee, thou wilt find a solace there.\n" ),

        new TenMajor( "5. THE UNSEEN HAND\n","5. THE UNSEEN HAND\n" + "\n" +
                "There is an unseen hand to me, that leads the way where I cannot see,\n" +
                "While going through this world of war, His hand still leads me as I go.\n" +
                "\n" +

                "\tCHORUS: " + "\n" +
                "\tI’m trusting to, the unseen hand, that leads me through, this weary land,\n" +
                "\tAnd some sweet day, I’l reachl that strand, still guided by, the unseen hand.\n" +
                "\n" +

                "His hand has led through shadows drear, and while it leads I have no fear,\n" +
                "I know it will lead me to that home, where sin nor sorrow never can come.\n" +
                "\n" +

                "I long to see my Saviour’s face, and sing the story saved by grace,\n" +
                "And there upon that golden strand, I’ll praise Him for His guiding hand." ),

        new TenMajor( "6. THE OLD COUNTRY CHURCH\n","6. THE OLD COUNTRY CHURCH\n" + "\n" +
                "There’s a place deer to me where I’m longing to be,\n" +
                "With my friends in the old country church\n" +
                "There with mother we went, and our Sundays were spent,\n" +
                "With my friends in the old country church.\n" +
                "\n" +

                "\tCHORUS: " + "\n" +
                "\tPrecious years, of memory, O what Joy they bring to me,\n" +
                "\tHow I long once more to be, with my friends in the old country church.\n" +
                "\n" +

                "As a small country boy how my heart beat with Joy,\n" +
                "When I knelt in the old country church,\n" +
                "And the Saviour above, by His wonderful love,\n" +
                "Saved my Soul in the old country church.\n" +
                "\n" +

                "How I wish that today, all the people would pray,\n" +
                "As we prayed in the old country church,\n" +
                "If they’d only confess Jesus surely would bless,\n" +
                "As He did in the old country church.\n" +
                "\n" +

                "Oft my thoughts make me weep, for so many now sleep,\n" +
                "In their graves near the old country church,\n" +
                "And sometimes, I may rest with the friends I love best,\n" +
                "In a grave near the old country church.\n" ),

        new TenMajor( "7. THE LILY OF THE VALLEY\n","7. THE LILY OF THE VALLEY\n" + "\n" +
                "I’ve found a friend in Jesus, He’s everything to me,\n" +
                "He’s the fairest of ten thousand to my soul,\n" +
                "The Lily of the Valley in Him alone I see,\n" +
                "All I need to cleanse and make me fully whole.\n" +
                "In sorrow He’s my comfort, in trouble He’s my stay,\n" +
                "He tells me every care on Him to roll, Hallelujah!\n" +
                "He’s the Lily of the Valley, the Bright and Morning Star,\n" +
                "He’s the fairest of ten thousand to my soul.\n" +
                "\n" +


                "He all my griefs has taken and all my sorrows borne,\n" +
                "In temptation He’s my strong and mighty tower,\n" +
                "I have all for Him forsaken, and all my idols torn,\n" +
                "From my heart and now He keeps me by His power.\n" +
                "Though all the world forsake me, and satan tempt me sore,\n" +
                "Through Jesus I shall safely reach the goal, Hallelujah!\n" +
                "He’s the Lily of the Valley, the Bright and Morning Star,\n" +
                "He’s the fairest of ten thousand to my soul.\n" +
                "\n" +


                "He’ll never, never leave me, nor yet forsake me here,\n" +
                "While I live by faith and do His blessed will,\n" +
                "A wall of fire about me, I’ve nothing now to fear,\n" +
                "With His manner He my hungry soul shall fill,\n" +
                "Then sweeping up to glory, we’ll see His blessed face,\n" +
                "Where rivers of delight shall ever roll, Hallelujah!\n" +
                "He’s the Lily of the Valley, the Bright and Morning Star,\n" +
                "He’s the fairest of ten thousand to my soul.\n" ),

        new TenMajor( "8. MUST JESUS BEAR THE CROSS ALONE\n","8. MUST JESUS BEAR THE CROSS ALONE\n" + "\n" +
                "Must Jesus bear the cross alone, and all the world go free?\n" +
                "No, there’s a cross for everyone, and there’s a cross for me.\n" +
                "\n" +

                "The consecrated cross I’ll bear, till death shall set me free,\n" +
                "And then go home my crown to wear, for there’s a crown for me.\n" +
                "\n" +

                "Upon the crystal pavement down, at Jesus’s pierced feet,\n" +
                "With Joy I’ll cast my golden crown, and His dear name repeat.\n" +
                "\n" +

                "O precious cross! O glorious crown! O resurrection day!\n" +
                "Ye angels from the stars come down, and bear my soul away.\n" ),

        new TenMajor( "9. THE ROYAL TELEPHONE\n","9. THE ROYAL TELEPHONE\n" + "\n" +
                "Central’s never busy, always on the line,\n" +
                "You may hear from Heaven, almost any time,\n" +
                "Tis a royal service, free for one and all,\n" +
                "When you get in trouble, give this royal line a call.\n" +
                "\n" +

                "\tCHORUS: " + "\n" +
                "\tTelephone to glory, O what Joy divine!\n" +
                "\tI can feel the current moving on the line,\n" +
                "\tBuilt by God the Father, for His loved and own,\n" +
                "\tWe may talk to Jesus, thro’ this royal telephone.\n" +
                "\n" +

                "There will be no charges, telephone is free,\n" +
                "It was built for service, just for you and me,\n" +
                "There will be no waiting, on this royal line\n" +
                "Telephone to glory always answers just in time.\n" +
                "\n" +

                "Fail to get the answer,satan’s crossed the wire,\n" +
                "By a strong delution, or some base desire,\n" +
                "Take away obstruction, God is on the throne,\n" +
                "And you’ll get the answer, thro’ this royal telephone.\n" +
                "\n" +

                "If your line is grounded, and connection true,\n" +
                "Has been lost with Jesus, tell you what to do,\n" +
                "Prayer and faith and promise, mend the broken wire,\n" +
                "Till your soul is burning with the Pentecostal fire.\n" +
                "\n" +

                "Carnal combinations, cannot get control,\n" +
                "Of this line to glory, anchored in the soul,\n" +
                "Storm and trials cannot disconnect the line,\n" +
                "Held in constant keeping by the Father’s hand divine." ),

        new TenMajor( "10. HOLD TO GOD’S UNCHANGING HAND\n","10. HOLD TO GOD’S UNCHANGING HAND\n" + "\n" +
                "Time is filled with swift transition,\n" +
                "Naught of earth unmoved can stand,\n" +
                "Build your hopes on things eternal,\n" +
                "Hold to God’s unchanging hand!\n" +
                "\n" +

                "\tCHORUS: " + "\n" +
                "\tHold to God’s unchanging hand!\n" +
                "\tHold to God’s unchanging hand!\n" +
                "\tBuild your hopes on things eternal,\n" +
                "\tHold to God’s unchanging hand!\n" +
                "\n" +

                "Trust in Him who will not leave you,\n" +
                "Whatsoever years may bring,\n" +
                "If by earthly friends forsaken,\n" +
                "Still more closely to Him cling!\n" +
                "\n" +

                "Covet not this world vain riches,\n" +
                "That so rapidly decay,\n" +
                "Seek to gain the heavenly treasures,\n" +
                "They will never pass away!\n" +
                "\n" +

                "When your journey is completed,\n" +
                "If to God you have been true,\n" +
                "Fair and bright the home in glory,\n" +
                "Your enraptured soul will view!\n" )

    };

    //each TenMajorsongs has a title, and lyrics

    public TenMajor(String title, String lyrics) {
        this.title = title;
        this.lyrics = lyrics;
    }


   public String getTitle() {
        return title;
    }

    public String getLyrics() {
        return lyrics;
    }
    public String toString(){
        return this.title;
    }
}
